# Document Retriever - Two-Stage RAG for PPT/PDF References

This tool answers user questions by selecting the right document from a catalogue
and, when available, selecting the most relevant slides inside that document.

It supports:

- PPT/PPTX and PDF catalogue items
- OpenAI and Azure OpenAI backends
- Optional embeddings for smarter document/slide candidate narrowing
- Chat-style Streamlit UI and CLI

---

## High-Level Architecture

The retriever uses a two-stage pipeline to control token usage and improve relevance.

1. **Document selection stage (LLM):**
   - Input: document-level metadata only (`title`, `summary`, `type`, `tags`)
   - Output: top matching document IDs with score and reasoning

2. **Slide selection stage (LLM + candidate pruning):**
   - Runs only for selected docs that contain slide metadata
   - Candidate slides are pruned first:
     - embedding similarity (if enabled), otherwise
     - keyword overlap fallback
   - LLM sees only top slide candidates and returns selected slides with concise notes

This keeps prompts compact even for large decks and avoids sending all slides at once.

---

## Data Flow

1. Load `my_docs.json` into `DocumentStore` (default behavior).
2. Build compact doc catalogue text.
3. LLM chooses best document(s).
4. For each chosen document with slides:
   - Rank slide candidates (embedding or keyword)
   - Send only candidate subset to second LLM call
   - Parse returned slide references (`number`, `title`, `note`)
5. UI formats answer:
   - bold slide titles + concise summary
   - file name + URL as reference

---

## Example Workflow: Input -> Processing -> Output

This example shows exactly how a user query moves through the system.

### Input query

```text
Where are underwriting concentration limits explained?
```

### Step-by-step processing

1. **User input received**
   - CLI: `python main.py "Where are underwriting concentration limits explained?"`
   - Streamlit: query typed into chat input.

2. **Catalogue is loaded**
   - Active domain type is resolved (`underwriting` or `digital`).
   - Matching catalogue file is loaded into `DocumentStore`.

3. **Stage 1 (document selection)**
   - System builds a compact catalogue prompt using only document-level metadata:
     - `id`, `title`, `doc_type`, `summary`, `tags`, sampled slide titles.
   - LLM returns structured JSON:
     - top document IDs
     - relevance score
     - short reasoning
     - interpreted intent (`query_understood_as`)

4. **Candidate narrowing (optional embeddings)**
   - If embedding shortlist is enabled, only top semantically similar documents/slides are sent to the LLM.
   - Otherwise, keyword overlap fallback is used for slide candidates.

5. **Stage 2 (slide selection for matched PPT/PPTX docs)**
   - For each selected document that has slide metadata:
     - top candidate slides are prepared
     - second LLM call selects most relevant slides
     - output includes slide `number`, `title`, and concise `note`

6. **Result assembly**
   - Retriever returns ranked matches and optional matched slides.
   - UI/CLI formats final response with:
     - concise answer text
     - slide-level details when available
     - source file/URL reference

### Example generated output (shape)

```text
Query interpreted as: Find where underwriting concentration limits are defined.

Top match:
- Document: Underwriting Risk Policy Deck
- Score: 0.89
- Reason: Covers underwriting guardrails and concentration thresholds.
- Slides:
  - Slide 14 (Concentration Limits): Defines single-name and sector exposure caps.
  - Slide 15 (Exceptions): Approval workflow for limit overrides.
- Source:
  - File: underwriting_policy_deck.pptx
  - URL: https://.../underwriting_policy_deck.pptx
```

---

## Project Layout

```text
doc_retriever/
|- .env.example
|- requirements.txt
|- config.py           # provider and app config
|- document_store.py   # catalogue schema + loaders
|- retriever.py        # two-stage retrieval pipeline
|- main.py             # CLI
|- streamlit_app.py    # chat UI
|- example_usage.py
`- my_docs.json        # default catalogue
```

---

## Quick Start

```bash
pip install -r requirements.txt
cp .env.example .env
# Fill provider credentials in .env

# CLI
python main.py "Where is onboarding IT setup explained?"

# Streamlit chatbot
streamlit run streamlit_app.py
```

---

## Environment Configuration (`.env`)

### Azure OpenAI

| Variable | Default | Description |
| --- | --- | --- |
| `AZURE_OPENAI_API_KEY` | *(required for Azure)* | Azure API key |
| `AZURE_OPENAI_ENDPOINT` | *(required for Azure)* | Example: `https://my-resource.openai.azure.com/` |
| `AZURE_OPENAI_API_VERSION` | `2024-02-01` | Azure API version |
| `AZURE_OPENAI_DEPLOYMENT_NAME` | `gpt-4o` | Chat deployment |
| `AZURE_OPENAI_EMBEDDING_DEPLOYMENT` | `text-embedding-3-small` | Embedding deployment (for shortlist) |

### OpenAI

| Variable | Default | Description |
| --- | --- | --- |
| `OPENAI_API_KEY` | *(required for OpenAI)* | OpenAI API key |
| `OPENAI_MODEL_NAME` | `gpt-4o-mini` | Chat model |
| `OPENAI_EMBEDDING_MODEL_NAME` | `text-embedding-3-small` | Embedding model (for shortlist) |

### Retrieval behavior

| Variable | Default | Description |
| --- | --- | --- |
| `LLM_PROVIDER` | `openai` | Default provider (`openai` or `azure`) |
| `LLM_TEMPERATURE` | `0.0` | Determinism control |
| `LLM_MAX_TOKENS` | `1024` | Max generation tokens |
| `TOP_K` | `1` | Number of documents returned |
| `RETURN_REASONING` | `true` | Include reasoning text in output |

---

## Default Catalogue Behavior

- `my_docs.json` is the default catalogue for both CLI and Streamlit.
- CLI `--docs` can override this with another JSON file.
- Streamlit upload is intentionally disabled (fixed project catalogue).
- If `my_docs.json` is missing, fallback is built-in sample documents.

---

## JSON Schema

```json
[
  {
    "id": "doc_id",
    "title": "Document title",
    "url": "https://.../file.pptx",
    "doc_type": "pptx",
    "summary": "Document-level summary",
    "tags": ["optional", "tags"],
    "slides": [
      { "number": 1, "title": "Slide title", "summary": "Slide summary" }
    ]
  }
]
```

Notes:

- `slides` is optional.
- Slide numbers should be 1-based and stable.
- Better slide summaries improve slide-level answer quality.

---

## What This Can Handle Well

- Q&A over curated document metadata (summary-based retrieval)
- Large catalogues with optional embedding shortlist
- Large slide decks via two-stage retrieval + candidate pruning
- Slide-aware references for PPT/PPTX when slide metadata exists
- Provider switching between OpenAI and Azure OpenAI

---

## What This Does Not Handle

- Direct parsing of raw PDF/PPT files at query time
- OCR on images/scanned content
- Guaranteed factual extraction beyond metadata provided in catalogue
- Multi-document synthesis with citation-grade traceability
- Access control / signed URL refresh / file permission enforcement

If you need raw-file extraction, add a preprocessing pipeline that reads source files
and writes high-quality summaries + slide metadata into `my_docs.json`.

---

## Token and Scale Considerations

- Stage-1 prompt includes doc-level metadata only.
- Stage-2 prompt includes only top candidate slides (not full deck).
- This design reduces token pressure for 100+ slide decks.
- Embeddings improve candidate pruning and are recommended at scale.

---

## CLI Usage

```bash
python main.py [OPTIONS] [QUERY]

QUERY            Natural-language query (omit for interactive REPL)
--docs PATH      Override default catalogue JSON
--top-k N        Number of docs to return
--no-reasoning   Hide reasoning in table output
--verbose        Debug logs
```

---

## Streamlit UI Behavior

- Chatbot-style interaction
- No catalogue upload option (project default catalogue only)
- Answer formatting:
  - summarized content for selected slides
  - slide title in bold
  - file name + URL reference block
