# Document Assistant - Feature-Routed Retrieval and Web RAG

This project is a multi-feature assistant with a shared UI/CLI and pluggable runtime modes:

- `underwriting` (local catalogue retrieval with channel awareness)
- `digital` (local catalogue retrieval over digital journey transcripts)
- `internet` (live Tavily-backed internet research over allowed websites)
- `web_rag` (recursive crawl + Postgres/pgvector indexing + retrieval QA)

The app supports `OpenAI`, `Azure OpenAI`, and `Ollama`.

---

## What You Get

- Feature routing from one app: switch by `ACTIVE_TYPE` (CLI) or sidebar (Streamlit)
- Two-stage retrieval for catalogue features (document selection, then segment/slide selection)
- Full catalogue passed to the LLM for document selection (use embedding shortlist in the UI to shrink large decks)
- Optional embedding shortlist for catalogue modes
- Internet research agent with references
- Web RAG ingestion pipeline with incremental updates (checksum-aware)
- Source preview in Streamlit for traceability

---

## High-Level Architecture

1. Entry points:
   - `main.py` (interactive launcher: CLI, Streamlit, Ollama test app)
   - `src/app/cli.py` (feature-routed CLI)
   - `src/app/streamlit_app.py` -> `src/app/feature_streamlit.py`
2. Runtime picks a feature from `src/features/registry.py`.
3. Feature handler executes the feature-specific flow:
   - Catalogue features: local `.txt` retrieval (`underwriting`, `digital`)
   - Internet feature: Tavily + LangGraph search workflow
   - Web RAG feature: crawl, index in pgvector, then similarity search
4. Response is normalized as `FeatureAnswer` for both CLI and Streamlit.

---

## Feature Details

### 1) Underwriting (`ACTIVE_TYPE=underwriting`)

- Loads local catalogue from `catelogue/underwriting` and `output/` (slide `.txt`) as configured
- Injects channel slice JSON from `catelogue/catalogue_*.json` into prompts
- Uses LLM retriever with domain prompts and underwriting channel context
- Supports channel filtering (`Agency`, `Axis`, `DSF`)
- Returns concise answer + deterministic source links + retrieved context preview

### 2) Digital (`ACTIVE_TYPE=digital`)

- Loads local catalogue from `catelogue/digital` recursively
- Optional embedding shortlist in UI to reduce prompt size
- Answers using selected transcript segment(s)
- Includes source URL/path and transcript evidence

### 3) Internet (`ACTIVE_TYPE=internet`)

- Uses `TavilySearch` with allowed domains
- LangGraph flow: plan search -> fetch results -> synthesize answer
- Returns summarized answer plus clickable references

### 4) Web RAG (`ACTIVE_TYPE=web_rag`)

- Crawls configured roots recursively (same-domain, filtered assets/paths)
- Writes extracted dump into `docs/web/*_crawl.txt`
- Upserts content into Postgres tables:
  - `web_rag_pages`
  - `web_rag_chunks`
- Stores vectors in `pgvector` via LangChain `PGVector`
- Answers queries using similarity search over indexed chunks and cites URLs
- In Streamlit, use **Re-ingest web content** to refresh the index

---

## End-to-End Walkthrough (How System Works)

This walkthrough uses `web_rag`, because it shows ingestion + retrieval together.

### Step 0 - Configure environment

1. Copy env file:
   - Windows PowerShell: `Copy-Item .env.example .env`
2. Set at minimum:
   - `LLM_PROVIDER=openai` (or `azure` / `ollama`)
   - `ACTIVE_TYPE=web_rag`
   - Provider credentials (for example `OPENAI_API_KEY`)
   - `WEB_RAG_WEBSITES=hdfclife.com`
   - Postgres values (`WEB_RAG_PG_HOST`, `WEB_RAG_PG_PORT`, `WEB_RAG_PG_DB`, `WEB_RAG_PG_USER`, `WEB_RAG_PG_PASSWORD`)

### Step 1 - Install dependencies

```bash
pip install -r requirements.txt
```

### Step 2 - Launch app

Option A (interactive launcher):

```bash
python main.py
```

Choose **Streamlit app**, then in sidebar select **web_rag**.

Option B (direct Streamlit):

```bash
streamlit run src/app/streamlit_app.py
```

### Step 3 - Re-ingest websites

In Streamlit sidebar:

1. Keep/select domains (for example `hdfclife.com`)
2. Click **Re-ingest web content**

What happens internally:

- URLs are crawled recursively
- Text is extracted and cleaned
- Content checksum is compared with existing rows
- Unchanged pages are skipped
- New/updated chunks are embedded and indexed in pgvector

### Step 4 - Ask a query

Example:

```text
What documents are required for term insurance claim settlement?
```

Query flow:

1. Similarity search returns top-k chunks from pgvector.
2. LLM gets only retrieved snippets (RAG context).
3. LLM generates answer grounded in retrieved content.
4. UI renders answer + URL references + source context preview.

### Step 5 - Iterate safely

- Re-run ingestion when website content changes
- Tune `TOP_K`, `LLM_MAX_TOKENS`, and provider/model in sidebar
- Keep allowed domains narrow for better relevance

---

## Quick Start for Catalogue Modes

Use this when you want local `.txt` catalogue Q&A (not internet/web crawl).

1. Set `.env`:
   - `ACTIVE_TYPE=underwriting` or `ACTIVE_TYPE=digital`
2. Run:

```bash
python src/app/cli.py "What are non-medical eligibility rules?"
```

or

```bash
streamlit run src/app/streamlit_app.py
```

In Streamlit:

- Select feature (`underwriting` / `digital`)
- Optionally enable embedding shortlist
- Ask your question

---

## CLI Usage

```bash
python src/app/cli.py [QUERY] [--top-k N]
```

- `QUERY` omitted -> interactive REPL mode
- `--top-k` overrides retrieval `TOP_K`

Feature routing is automatic based on `ACTIVE_TYPE`.

---

## Configuration Reference (`.env`)

### Provider and app routing

- `LLM_PROVIDER=openai|azure|ollama`
- `ACTIVE_TYPE=underwriting|digital|internet|web_rag`
- `LLM_TEMPERATURE=0.0`
- `LLM_MAX_TOKENS=1024`
- `TOP_K=1`
- `RETURN_REASONING=true`

### OpenAI

- `OPENAI_API_KEY`
- `OPENAI_MODEL_NAME` (default `gpt-4o-mini`)
- `OPENAI_EMBEDDING_MODEL_NAME` (default `text-embedding-3-small`)

### Azure OpenAI

- `AZURE_OPENAI_API_KEY`
- `AZURE_OPENAI_ENDPOINT`
- `AZURE_OPENAI_API_VERSION`
- `AZURE_OPENAI_DEPLOYMENT_NAME`
- `AZURE_OPENAI_EMBEDDING_DEPLOYMENT`

### Ollama

- `OLLAMA_BASE_URL` (default `http://localhost:11434`)
- `OLLAMA_MODEL_NAME` (default `llama3.1`)
- `OLLAMA_EMBEDDING_MODEL_NAME` (default `llama3`)
- `OLLAMA_STREAM=true|false`

### Internet feature

- `INTERNET_WEBSITES` (comma-separated domains)
- `TAVILY_API_KEY` (required for Tavily search)

### Web RAG feature

- `WEB_RAG_WEBSITES` (comma-separated domains/URLs)
- `WEB_RAG_MAX_DEPTH` (default `2`)
- `WEB_RAG_TIMEOUT_SEC` (default `15`)
- `WEB_RAG_PG_HOST` (default `localhost`)
- `WEB_RAG_PG_PORT` (default `5433`)
- `WEB_RAG_PG_DB` (default `postgres`)
- `WEB_RAG_PG_USER` (default `postgres`)
- `WEB_RAG_PG_PASSWORD` (default `root`)

---

## Project Layout

```text
.
|- main.py
|- .env.example
|- requirements.txt
|- catelogue/
|  |- underwriting/
|  `- digital/
|- docs/
|  `- web/                       # web_rag crawl dumps
`- src/
   |- app/
   |  |- cli.py
   |  |- streamlit_app.py
   |  `- feature_streamlit.py
   |- config/
   |  `- settings.py
   |- features/
   |  |- underwriting/
   |  |- digital/
   |  |- internet/
   |  `- web_rag/
   |- llm/
   |  |- retriever.py
   |  `- prompts.py
   `- services/
      `- document_store.py
```

---

## Operational Notes

- `catelogue/` folder name is intentionally used in code as-is.
- `web_rag` requires a reachable Postgres instance with `vector` extension enabled.
- If no catalogue files exist for a catalogue feature, retrieval results will be empty.
- Streamlit sidebar includes controls for provider/model and retrieval options.

---

## Troubleshooting

- **No internet results:** verify `TAVILY_API_KEY` and allowed websites.
- **Web RAG no answers:** run Re-ingest, then query again; verify Postgres connectivity.
- **OpenAI/Azure auth errors:** confirm API key and deployment/model names.
- **Ollama failures:** ensure Ollama server is running and model is installed locally.

---

## Tech Stack

- LangChain + LangGraph
- OpenAI / Azure OpenAI / Ollama
- Tavily Search API
- Postgres + pgvector (`langchain-postgres`, `psycopg`)
- Streamlit (UI), Rich (CLI output)
