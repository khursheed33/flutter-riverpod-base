# Realtime CLI Test Log

Date: 2026-04-16 11:11:18 +05:30
Environment: Local CMD/CLI execution (no unit test framework used)
Workspace: `c:\Users\gaddi\Downloads\files`

## Objective

Run each implemented feature tool one by one using realtime CLI commands:

- `underwriting`
- `digital`
- `internet`

## Pre-check and Setup

### Step 1: Initial underwriting run (failed)

Command:

```powershell
$env:ACTIVE_TYPE='underwriting'; python src/app/cli.py "What are key underwriting risk factors for policy issuance?"
```

Result: **Failed**

Error:

```text
ModuleNotFoundError: No module named 'rich'
```

Action taken:

- Installed dependencies with:

```powershell
python -m pip install -r requirements.txt
```

### Step 2: Initial direct script execution for all features (failed)

Commands:

```powershell
$env:ACTIVE_TYPE='underwriting'; python src/app/cli.py "What are the key underwriting checks before issuing a policy?"
$env:ACTIVE_TYPE='digital'; python src/app/cli.py "Summarize digital onboarding flow recommendations from available documents."
$env:ACTIVE_TYPE='internet'; python src/app/cli.py "Latest RBI digital lending guideline highlights"
```

Result: **Failed for all three**

Error:

```text
ModuleNotFoundError: No module named 'src'
```

Action taken:

- Switched to module execution mode: `python -m src.app.cli ...`

## Feature-wise Realtime CLI Tests

### 1) Underwriting Tool

Command:

```powershell
$env:ACTIVE_TYPE='underwriting'; python -m src.app.cli "What are the key underwriting checks before issuing a policy?"
```

Result: **PASS**

Observed output summary:

- Returned underwriting answer with source title.
- Included multiple extracted slide-level checks (gate criteria, FSA/MSA, income proof, housewives guideline, CIDR).
- Included source URL reference.

### 2) Digital Tool

Command:

```powershell
$env:ACTIVE_TYPE='digital'; python -m src.app.cli "Summarize digital onboarding flow recommendations from available documents."
```

Result: **PASS**

Observed output summary:

- Returned digital onboarding response.
- Included section-by-section flow from source transcript.
- Included source URL reference with anchor.

### 3) Internet Tool

Command (first attempt):

```powershell
$env:ACTIVE_TYPE='internet'; python -m src.app.cli "Latest RBI digital lending guideline highlights"
```

Result: **Failed initially**

Error:

```text
1 validation error for TavilySearchResults
include_domains
Input should be a valid list
```

Fix applied:

- Updated `src/features/internet/search_agent.py` to build Tavily tools without passing `include_domains=None`.
- Re-compiled file:

```powershell
python -m compileall src/features/internet/search_agent.py
```

Command (retest):

```powershell
$env:ACTIVE_TYPE='internet'; python -m src.app.cli "Latest RBI digital lending guideline highlights"
```

Result: **PASS (after fix)**

Observed output summary:

- Returned internet summary for RBI digital lending guidelines.
- Included key points (cooling-off period, compliance requirement, consumer protection).
- Included 3 web references in output.
- Non-blocking deprecation warning observed for `TavilySearchResults`.

## Final Status

- Underwriting CLI tool: **PASS**
- Digital CLI tool: **PASS**
- Internet CLI tool: **PASS** (after runtime fix)

All requested tools were tested in realtime via CLI commands (not via test cases).
