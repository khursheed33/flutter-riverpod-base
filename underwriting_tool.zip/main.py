"""Interactive launcher for CLI or Streamlit app."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def _clear_terminal() -> None:
    os.system("cls" if os.name == "nt" else "clear")


def _select_mode_with_arrows(options: list[str]) -> str:
    """Display an arrow-key menu and return selected option."""
    try:
        import msvcrt  # Windows-only
    except ImportError:
        # Fallback for non-Windows environments.
        print("Select app mode:")
        for i, option in enumerate(options, start=1):
            print(f"{i}. {option}")
        choice = input("Enter choice number: ").strip()
        idx = int(choice) - 1 if choice.isdigit() else 0
        idx = max(0, min(idx, len(options) - 1))
        return options[idx]

    selected = 0
    while True:
        _clear_terminal()
        print("Select app mode (use Up/Down arrow keys, Enter to confirm):\n")
        for i, option in enumerate(options):
            marker = ">" if i == selected else " "
            print(f"{marker} {option}")

        key = msvcrt.getwch()
        if key in ("\r", "\n"):
            return options[selected]
        if key in ("\x00", "\xe0"):
            arrow = msvcrt.getwch()
            if arrow == "H":  # Up
                selected = (selected - 1) % len(options)
            elif arrow == "P":  # Down
                selected = (selected + 1) % len(options)


def _run_cli() -> None:
    from src.app.cli import main as cli_main

    _clear_terminal()
    cli_main()


def _run_streamlit() -> None:
    _clear_terminal()
    root = Path(__file__).resolve().parent
    streamlit_app_path = root / "src" / "app" / "streamlit_app.py"
    subprocess.run(
        [sys.executable, "-m", "streamlit", "run", str(streamlit_app_path)],
        check=False,
    )


def _run_ollama_showcase() -> None:
    _clear_terminal()
    root = Path(__file__).resolve().parent
    showcase_app_path = root / "src" / "app" / "ollama_showcase_streamlit.py"
    subprocess.run(
        [sys.executable, "-m", "streamlit", "run", str(showcase_app_path)],
        check=False,
    )


def main() -> None:
    """Launch CLI or Streamlit app based on interactive selection."""
    mode = _select_mode_with_arrows(["CLI app", "Streamlit app", "Test Ollama"])
    if mode == "CLI app":
        _run_cli()
        return
    if mode == "Streamlit app":
        _run_streamlit()
        return
    _run_ollama_showcase()


if __name__ == "__main__":
    main()
