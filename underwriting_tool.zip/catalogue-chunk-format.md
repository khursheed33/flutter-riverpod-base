# Digital Tool Catalogue: One Best Approach (SQLite + Indexing)

This document defines one consistent approach for all source types (video transcript, PowerPoint, PDF, and future formats): **store normalized JSON chunks and index them in SQLite FTS5**.  
The system always searches **one domain at a time** (`digital`, `underwriting`, `finance`, etc.).

---

## Final architecture

1. Keep extracted content in JSON chunks using one shared schema.
2. Ingest chunks into SQLite tables.
3. Build an FTS5 index on searchable text.
4. At query time, filter by `domain`, run FTS search, rank by BM25, return chunk citations (`slide`, `page`, `timestamp`).

This is the default and recommended production path.

---

## Canonical JSON chunk format

Use this exact chunk shape for every content type.

```json
{
  "chunk_id": "uw-2024-001_c00014",
  "catalogue_item_id": "uw-2024-001",
  "domain": "underwriting",
  "ordinal": 14,
  "title_path": ["UW Deck", "Credit", "Slide 14 - Concentration"],
  "text": "Single-name concentration must not exceed ...",
  "source": {
    "kind": "slide",
    "ref": {
      "slide_number": 14,
      "slide_title": "Concentration Limits",
      "notes_included": true
    }
  },
  "metadata": {
    "language": "en",
    "extraction_version": "1.2.0",
    "content_hash": "sha256:..."
  }
}
```

### Required fields

| Field | Rule |
|------|------|
| `chunk_id` | Unique and stable. Suggested: `{catalogue_item_id}_c{zero-padded-ordinal}` |
| `catalogue_item_id` | Parent document/item id |
| `domain` | Search scope (`digital`, `underwriting`, `finance`, etc.) |
| `ordinal` | Sequence within parent item |
| `title_path` | Array for display + ranking context |
| `text` | Searchable body text |
| `source.kind` | One of `slide`, `pdf`, `transcript_segment` |
| `source.ref` | Type-specific citation payload |

### `source.ref` by type

- `slide`: `slide_number`, `slide_title`, `notes_included`
- `pdf`: `page_start`, `page_end`, optional `section_id`
- `transcript_segment`: `start_ms`, `end_ms`, optional `speaker`

All type-specific data must stay under `source.ref` (or `metadata`) so the top-level format stays consistent.

---

## Chunking rules

- **PowerPoint**: one chunk per slide; optionally include notes in same chunk.
- **PDF**: chunk by page or section boundaries; split oversized text by paragraph while preserving sentence boundaries.
- **Transcript**: chunk by 30–120 second windows and/or max character limit; always include `start_ms` and `end_ms`.

Keep chunks reasonably small and coherent so retrieval returns precise citations.

---

## SQLite schema (authoritative)

Use one SQLite database (for example: `catalogue.db`) with one metadata table and one FTS table.

```sql
CREATE TABLE IF NOT EXISTS chunks (
  chunk_id TEXT PRIMARY KEY,
  catalogue_item_id TEXT NOT NULL,
  domain TEXT NOT NULL,
  ordinal INTEGER NOT NULL,
  title_path_json TEXT NOT NULL,   -- JSON array serialized as text
  source_kind TEXT NOT NULL,
  source_ref_json TEXT NOT NULL,   -- JSON object serialized as text
  metadata_json TEXT,              -- JSON object serialized as text
  text TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_chunks_domain_item_ordinal
  ON chunks(domain, catalogue_item_id, ordinal);

CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts
USING fts5(
  chunk_id UNINDEXED,
  domain UNINDEXED,
  title_text,
  body_text,
  content='',
  tokenize='unicode61'
);
```

### Ingestion rule

For each JSON chunk:

- insert/update `chunks`
- upsert into `chunks_fts`:
  - `chunk_id` = chunk id
  - `domain` = domain
  - `title_text` = joined `title_path` (space-separated)
  - `body_text` = `text`

Use UPSERT semantics so re-indexing is idempotent.

---

## Search flow (authoritative)

Given user input:

1. Resolve target `domain` from user context (single domain only).
2. Run FTS query scoped to `domain`.
3. Rank by BM25 (`bm25(chunks_fts)`), with title boost by weighting `title_text` higher than `body_text`.
4. Join back to `chunks` by `chunk_id`.
5. Return top N with citation from `source.ref`.

### Example query template

```sql
SELECT
  c.chunk_id,
  c.catalogue_item_id,
  c.domain,
  c.ordinal,
  c.title_path_json,
  c.source_kind,
  c.source_ref_json,
  c.text,
  bm25(f, 5.0, 1.0) AS score
FROM chunks_fts f
JOIN chunks c ON c.chunk_id = f.chunk_id
WHERE f.domain = :domain
  AND f MATCH :query
ORDER BY score
LIMIT :limit;
```

This provides deterministic, fast retrieval without a vector database.

---

## File layout

Recommended input layout:

- `corpus/digital/*.json`
- `corpus/underwriting/*.json`
- `corpus/finance/*.json`

Each JSON file can contain either:

- one chunk object, or
- one item object with a `chunks[]` array

In both cases, ingestion normalizes into the same `chunks` table.

---

## Optional future extension (not part of baseline)

If lexical search quality becomes insufficient for paraphrased questions, add a semantic re-ranker after FTS candidate retrieval.  
Do not change the chunk schema; extend the retrieval layer only.

---

## Implementation checklist

- [ ] Use the canonical chunk JSON shape for every source type
- [ ] Store all chunks in SQLite `chunks`
- [ ] Build and maintain SQLite `chunks_fts` index
- [ ] Enforce domain-scoped search (single corpus per query)
- [ ] Return source-aware citations (`slide`, `page`, `timestamp`)
- [ ] Version extraction via `metadata.extraction_version`
