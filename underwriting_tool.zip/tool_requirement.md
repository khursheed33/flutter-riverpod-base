# Underwriting Use-case

## Underwriting: 
- policy issues are analysed based on risk, sum assured - payment : params: base, age, guidelines and grids, like house wife etc based on that there is different policies.
- agents queries based on the uw while selling the policy.
- this is tough for the agents to get all clearly.
- document = single slide , ppt

## Keywords:
- UW, underwriting, 

## Doc types:
- Protection
- Savings

## Channels:
- each channel has diff rules.
	
## While creating summary:
- doc type must be included in each summary (title or basic description).
- which makes it easy to analyse that this slide belongs to this document.

## Intent Classification
- 

## Answer: 
- short summary
- document -> ppt -> slides
- document url
- Follow-up for vague queries: ask for clarity then answer it.


I understand you're asking about <>, you can find the answer for your query below along with document.

