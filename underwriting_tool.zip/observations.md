Here’s the updated content with the new addition appended:

---

## Digital tools-

### 1.

Only first segment was required and url should be of the video-

**How to check my MTD performance snapshot in Mspace**

**Transcript Source 1: M Space DIY for ADM**

* **Segment 1 (Home screen and quick actions):** View ongoing contests, quick links, and MTD performance snapshot updated through the day.
* **Segment 4 (Activation and team performance tracking):** Track active status, qualifiers, FM/DS/training inputs, advisor search, non-starter views, and KPI visibility.
* **Segment 2 (Contacts and customers):** Manage leads/customers, share quotations, raise service requests, and use policy briefcase for document sharing.
* **Segment 3 (Team and sales navigator):** Review advisor portfolios, campaign status, promotion shortfalls, and consolidated sales/recruitment/activation metrics.
* **URL:** `/docs/Digital/digital_tools_transcription.txt.rtf#mspace`

---

### 2.

If not confident about the answer don’t provide transcript text answer, below none of the answers are relevant-

**Unable to login mspace**

**Transcript Source 1: M Space DIY for ADM**

* **Segment 1 (Home screen and quick actions):** View ongoing contests, quick links, and MTD performance snapshot updated through the day.
* **Segment 2 (Contacts and customers):** Manage leads/customers, share quotations, raise service requests, and use policy briefcase for document sharing.
* **Segment 3 (Team and sales navigator):** Review advisor portfolios, campaign status, promotion shortfalls, and consolidated sales/recruitment/activation metrics.
* **Segment 4 (Activation and team performance tracking):** Track active status, qualifiers, FM/DS/training inputs, advisor search, non-starter views, and KPI visibility.
* **URL:** `/docs/Digital/digital_tools_transcription.txt.rtf#mspace`

---

### 3.

Add fixed response line of
I understand you wish to know regarding the <> app. I have attached the video where you can refer to the <>

---

### 4.

Correct transcription it is **mPro not empro**-

**Mpro id- 95745U not working in mpro while login the case**

**Transcript Source 1: Empro Digital Policy Login Masterclass**

* **Segment 1 (Access and dashboard navigation):** Sign in at empro portal, review stage-wise dashboard counts, and search applications by email/mobile/policy/transaction identifiers.
* **Segment 2 (Start new application and customer details):** Choose new or existing customer, capture customer basics, consents, contact details, and policy context before proceeding.
* **Segment 3 (Aadhaar eKYC and personal details):** Complete Aadhaar/VID OTP-based eKYC, confirm fetched details, and fill identity/address/personal declaration fields.
* **Segment 4 (Suitability, product, and declarations):** Capture insurance purpose, life stage, income/occupation, configure product/riders, then complete proposer, nominee, and risk declarations.
* **Segment 5 (Verification, payment, medical, and submission):** Send pre-issuance verification link, complete payment setup, schedule medicals, upload mandatory documents, and submit proposal.
* **URL:** `/docs/Digital/digital_tools_transcription.txt.rtf#empro`

---

### 5.

In addition to showing only relevant segment can we tell the start end time of the relevant segment, and if relevant segment is not found then show entire video-

**Case push to verification to next step already payment is done but mpro shows only verification on**

**Transcript Source 1: Empro Digital Policy Login Masterclass**

* **Segment 5 (Verification, payment, medical, and submission):** Send pre-issuance verification link, complete payment setup, schedule medicals, upload mandatory documents, and submit proposal.
* **Segment 1 (Access and dashboard navigation):** Sign in at empro portal, review stage-wise dashboard counts, and search applications by email/mobile/policy/transaction identifiers.
* **Segment 2 (Start new application and customer details):** Choose new or existing customer, capture customer basics, consents, contact details, and policy context before proceeding.
* **Segment 3 (Aadhaar eKYC and personal details):** Complete Aadhaar/VID OTP-based eKYC, confirm fetched details, and fill identity/address/personal declaration fields.
* **Segment 4 (Suitability, product, and declarations):** Capture insurance purpose, life stage, income/occupation, configure product/riders, then complete proposer, nominee, and risk declarations.
* **URL:** `/docs/Digital/digital_tools_transcription.txt.rtf#empro`


---

**UNDERWRITING-**

**1. url is still not referring to the individual slides, showing entire document-**

**Customer is 42 years old, salaried, income 18L, asking for 5 Cr term plan — what medicals will get triggered?**

**Underwriting Source 1: Axis Max Life Protection Underwriting Guidelines - Feb 2026**

- **Slide 5 (Financial gate criteria)**: Provides criteria based on occupation, education, income, and age, which are essential for assessing eligibility and medical requirements.
- **Slide 6 (MSA and FSA factors)**: Details on MSA/FSA computation factors across plan variants, which influence medical underwriting requirements.
- **Slide 8 (Video MER and VMER)**: Outlines Video MER eligibility and enhanced VMER limits, which may apply to the customer’s medical assessment.
- **Slide 11 (Sourcing relaxation)**: Additional sourcing relaxation for select salaried profiles in negative areas.
- **Slide 23 (EPFO waiver)**: EPFO-based financial waiver for salaried customers.
- **URL**: /docs/Underwriting/Axis Max Life protection Feb26 with High SA - UW All channels.pptx

---

**2. answer verbiage of I understand you wish to know regarding <> I have attached slide x which specifies <> and slide y which specifies <>**

**3. if not sure whether savings or protection then attach both documents slides-**

**For sum assured above 35 Cr, what special underwriting checks are required?**

**Underwriting Source 1: Axis Max Life Protection Underwriting Guidelines - Feb 2026**

- **Slide 3 (Special gate criteria)**: Details special gate criteria for underwriting cases with sum assured between 35-85 Cr.
- **Slide 7 (Medical grid)**: Medical grid by age and sum assured slabs.
- **Slide 14 (Indian housewife guidelines)**: Underwriting guidelines for Indian housewife customers.
- **Slide 15 (NRI housewife guidelines)**: Underwriting guidelines for NRI/OCI/PIO housewife customers.
- **Slide 8 (Video MER and VMER)**: Video MER eligibility and enhanced VMER limits for Indian and NRI customers.
- **URL**: /docs/Underwriting/Axis Max Life protection Feb26 with High SA - UW All channels.pptx

---

### Summary of Issues & Suggestions (from the image):

1. **Problem**: The URL is linking to the **entire document** instead of pointing to **specific individual slides**.
2. **Suggested Answer Verbiage**:
   - “I understand you wish to know regarding [topic]. I have attached **slide X** which specifies [details] and **slide Y** which specifies [details].”
3. **When unsure** whether the query is for Savings or Protection product → Attach slides from **both** documents.



**4. only relevant slide is required-**

**Customer Query:**  
For sum assured above 35 Cr, what special underwriting checks are required?

**Underwriting Source 1: Axis Max Life Protection Underwriting Guidelines - Feb 2026**

- **Slide 3 (Special gate criteria)**: Details special gate criteria for underwriting cases with sum assured between 35-85 Cr.
- **Slide 7 (Medical grid)**: Medical grid by age and sum assured slabs.
- **Slide 14 (Indian housewife guidelines)**: Underwriting guidelines for Indian housewife customers.
- **Slide 15 (NRI housewife guidelines)**: Underwriting guidelines for NRI/OCI/PIO housewife customers.
- **Slide 8 (Video MER and VMER)**: Video MER eligibility and enhanced VMER limits for Indian and NRI customers.
- **URL**: /docs/Underwriting/Axis Max Life protection Feb26 with High SA – UW All channels.pptx

---

**5. user will either be axis or agency there will never be case where savings agency and savings axis both are relevant documents, you can fix one in backend ie axis-**

**Customer Query:**  
What is the difference between Affluent 1 and Affluent 2 non/medical limits in savings?

**Response Generated:**  
I found relevant underwriting inputs across 3 PPT sources.

**Underwriting Source 1: Savings Agency Underwriting Guidelines - Mar 2026**

- **Slide 3 (Affluent-1 NML)**: Income >=15L with higher age-wise SA limits.
- **Slide 4 (Affluent-2 NML)**: Income >=10L with moderated SA limits.
- **Slide 2 (Enhanced non-medical limits)**: Enhanced non-medical limits approved for ALA advisors.
- **Slide 9 (Juvenile and student requirements)**: Juvenile and student medical requirements by SA limits.
- **Slide 8 (Housewife guidelines)**: Housewife guidelines for Indian and NRI savings customers.
- **URL**: /docs/Underwriting/Agency/Savings Agency Mar 26[29].pptx

**Underwriting Source 2: Savings Axis Underwriting Guidelines - Jan 2026**

*(Note: The image cuts off here, but it mentions a second source for Savings Axis guidelines.)*

---

### Key Points from this slide:

- **Point 4**: Always attach **only the relevant slide(s)** — do not share the entire document.
- **Point 5**: The user is either from **Axis** or **Agency** channel. There will never be a case where both "Savings Agency" and "Savings Axis" documents are relevant at the same time.  
  → Fix one (preferably **Axis**) in the backend to avoid showing irrelevant sources.



**6. only top two slides were relevant here-**

**Customer Query:**  
What is the difference between Affluent 1 and Affluent 2 non/medical limits in savings for Agency channel?

**Underwriting Source 1: Savings Agency Underwriting Guidelines - Mar 2026**

- **Slide 3 (Affluent-1 NML)**: Income >=15L with higher age-wise SA limits.
- **Slide 4 (Affluent-2 NML)**: Income >=10L with moderated SA limits.
- **Slide 2 (Enhanced non-medical limits)**: Enhanced non-medical limits approved for ALA advisors.
- **Slide 8 (Housewife guidelines)**: Housewife guidelines for Indian and NRI savings customers.
- **Slide 9 (Juvenile and student requirements)**: Juvenile and student medical requirements by SA limits.
- **URL**: /docs/Underwriting/Agency/Savings Agency Mar 26[29].pptx

---

### Key Instruction from this point:

- **Only the top two slides** (Slide 3 & Slide 4) were actually relevant to the query.
- The system should ideally show **only the most relevant slides** (in this case, just Slide 3 and Slide 4) instead of listing all five slides.

---

### Summary of All Points So Far (1 to 6):

1. **URL Issue** — Link should point to **specific individual slides**, not the entire document.
2. **Suggested Answer Verbiage** — Use: “I understand you wish to know regarding <> I have attached slide x which specifies <> and slide y which specifies <>”
3. **When unsure** (Savings vs Protection) → Attach slides from **both** documents.
4. **Only relevant slide(s)** should be provided — avoid dumping the whole document.
5. **Channel Fix** — User is either Axis or Agency. Never show both Savings Agency and Savings Axis documents together. Fix one (preferably Axis) in the backend.
6. **Limit to top relevant slides** — Show only the most relevant ones (e.g., only top 2 slides if others are not needed).
