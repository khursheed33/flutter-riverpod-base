# BM25 for Indexing and Search (vs Keyword Match)

## Why BM25
- Keyword match is exact and brittle (`"policy"` does not match `"policies"` well).
- BM25 ranks documents by relevance, not just term presence.
- It balances:
  - **Term frequency** (how often a term appears),
  - **Inverse document frequency** (how unique a term is),
  - **Length normalization** (avoids favoring very long docs).

## Minimal Workflow
1. **Prepare documents**: collect text + stable `doc_id`.
2. **Tokenize consistently**: lowercase, remove punctuation, split words.
3. **Build BM25 index** from tokenized docs.
4. **Search** by tokenizing query and scoring all docs.
5. **Return top-k** ranked results.

## Quick Python Example
```python
from rank_bm25 import BM25Okapi

documents = [
    {"id": "d1", "text": "Term insurance renewal reminder for April"},
    {"id": "d2", "text": "Customer service request for policy payment link"},
    {"id": "d3", "text": "Advisor dashboard and persistency report"},
]

tokenized_docs = [d["text"].lower().split() for d in documents]
bm25 = BM25Okapi(tokenized_docs)

query = "policy renewal payment"
tokenized_query = query.lower().split()

scores = bm25.get_scores(tokenized_query)
ranked = sorted(
    zip(documents, scores),
    key=lambda x: x[1],
    reverse=True
)

top_k = 3
for doc, score in ranked[:top_k]:
    print(doc["id"], round(float(score), 3), doc["text"])
```

## Practical Notes
- Keep tokenization identical for indexing and searching.
- Add stemming/lemmatization if recall is low (e.g., `renew`, `renewal`).
- Rebuild or update index when new documents are added.
- BM25 is lexical (fast + strong baseline); add vector search later if needed for semantic matching.
