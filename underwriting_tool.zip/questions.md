Customer is 42 years old, salaried, income 18L, asking for 5 Cr term plan — what medicals will get triggered?

What is the maximum term cover allowed for a 30?year?old with income 12L including other insurer covers?

Can a self?employed customer earning 4.8L apply for a 1 Cr term plan?

For sum assured above 35 Cr, what special underwriting checks are required?

Is video medical allowed for a 28?year?old salaried customer applying for 1.5 Cr?

Customer lives in a negative pincode but works in Axis Bank — can we source a protection policy?

What are the family accumulation limits for term policies across all insurers?

Is maternity rider allowed for a 39?year?old female customer?

What income proofs are required for a salaried customer applying for 3 Cr term cover?

Is smoker classification based only on declaration or urine cotinine test also applies?

Customer income is 9L and age is 35 — what is the maximum non?medical limit for savings plans?

What is the difference between Affluent 1 and Affluent 2 non?medical limits in savings?

Can a savings policy be issued on non?medical basis for a 45?year?old with high premium?

For a juvenile savings policy of 40L, are medical tests required?

What medical tests apply if non?medical limit conditions are not met in savings plans?

Is CIDR rider allowed with savings policy without income documents?

What is the financial multiplier applicable for savings plan for a 48?year?old customer?

Can credit bureau be used for financial underwriting of savings plans?

What financial waivers are allowed for retired customers in savings policies?

What surrogate income options are allowed for non?term savings plans?

Customer is an Axis Burgundy client — what additional non?medical limits are available?

Are Axis Burgundy NRI customers eligible for non?medical savings policies?

What is the maximum savings cover allowed using credit bureau for Axis customers?

Does Axis provide underwriting relaxations for immediate family members of Burgundy clients?

What underwriting rules apply for SWP joint life policies sourced through Axis channel?

Is Whole Life Income single pay allowed without medicals in Axis channel?

What financial waiver limits are higher for Axis Priority customers?

Can customers with GST income use turnover as surrogate income in Axis savings underwriting?

What CIDR limits apply for Axis savings policies?

Are FATF country NRI customers allowed savings policies through Axis channel?

What enhanced non?medical limits are available for ALA advisors?

Customer earning 16L through agency channel — can savings policy be issued without medicals?

What is the Sambhav program and who is eligible under agency channel?

Can an existing customer get 2 Cr savings cover without medicals under Sambhav program?

What are the exclusions under Sambhav underwriting program?

What financial documents can be waived for agency channel savings customers?

Is credit bureau allowed for savings underwriting in agency channel?

What special underwriting campaign limits are applicable till March 2026?

Can NRI customers get enhanced VMER limits under special UW campaign?

What CIDR limits apply for students and housewives in agency savings plans?