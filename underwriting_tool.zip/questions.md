# 🔹 1. Basic Understanding Questions

* What is the difference between **MSA and FSA** in underwriting?
* How is **financial eligibility calculated** for a customer?
* What is considered **earned income** for underwriting purposes?
* What are the **key eligibility criteria** for issuing a policy without medical tests?
* What is the **maximum sum assured allowed under single policy limits**?

---

# 🔹 2. Non-Medical & Medical Criteria

* What are the **non-medical limits for Affluent 1, Affluent 2, and General customers**?
* When does a case **move from non-medical to full medical underwriting**?
* What are the **medical requirements for customers aged 18–25**?
* What conditions make a case **ineligible for non-medical underwriting**?
* How does the **medical grid apply to joint life policies**?

---

# 🔹 3. Financial Eligibility & Income Proof

* What documents are required for **income proof for salaried customers**?
* What documents are required for **self-employed individuals**?
* What happens if **income proof is not available**?
* What is the **premium-to-income ratio limit**?
* How is **TSAR (Total Sum at Risk)** calculated?

---

# 🔹 4. Financial Waivers & Special Programs

* What are the **conditions for financial waiver without income documents**?
* Who qualifies under the **Sambhav program**?
* What are the **exclusions under Sambhav guidelines**?
* What is the **maximum sum assured allowed under financial waiver cases**?
* How does the **credit bureau score impact underwriting decisions**?

---

# 🔹 5. High Sum Assured & Risk Rules

* What are the **special gate criteria for sum assured above 35 Cr**?
* What are the **family accumulation limits across insurers**?
* How is **risk evaluated for high-value policies**?
* What is the **maximum allowable coverage across multiple insurers**?

---

# 🔹 6. Smoker, Lifestyle & Risk Evaluation

* How is a **smoker defined in underwriting guidelines**?
* What happens if a customer has used **tobacco in the last 24 months**?
* How are **substance abuse cases handled**?
* What are the **conditions that lead to policy decline**?

---

# 🔹 7. NRI / OCI / PIO Guidelines

* What are the **eligibility criteria for NRI customers**?
* What is the **maximum sum assured allowed for NRI applicants**?
* What are the **mandatory medical and video verification requirements for NRIs**?
* How does underwriting differ for **NRI vs Indian customers**?
* What happens if a case originates from a **non-eligible country**?

---

# 🔹 8. Housewife & Special Profiles

* How is underwriting handled for **housewives**?
* What are the **financial surrogate rules for housewives**?
* Are **students or pensioners eligible for financial waivers**?
* How is **dependency-based underwriting evaluated**?

---

# 🔹 9. Joint Life & Specialized Products

* How is **SUC calculated for joint life policies**?
* What are the **eligibility criteria for Whole Life Income (Joint Life Variant)**?
* What are the **special underwriting rules for SWP 6 Pay Regular Joint Life**?
* How are **previous policies considered in joint life calculations**?

---

# 🔹 10. CIDR (Critical Illness Rider)

* What are the **underwriting requirements for CIDR rider**?
* When is a **full medical assessment required for CIDR**?
* What are the **CIDR rules for NRI customers**?
* When will a **CIDR case be declined or not processed**?

---

# 🔹 11. Edge Case / Decision-Based Questions (Very Important for AI)

* Can a customer get a policy if **income proof is missing but credit score is high**?
* What happens if a customer's **premium exceeds their income capacity**?
* Can a **housewife apply for a high sum assured policy**?
* What if a customer has **existing policies across multiple insurers**?
* Can a **smoker be treated as non-smoker under any condition**?

---

# 🔹 12. Operational / Compliance Questions

* What checks are performed using **IIB data**?
* What is considered a **negative location or blocked pin code**?
* When is **video MER mandatory**?
* What are the **rules for sourcing business from restricted locations**?

---

# 🔹 13. Complex Multi-Condition Queries (Great for Testing AI)

* A 40-year-old salaried customer earning 12L wants 2Cr cover without income proof—**is it allowed?**
* An NRI customer with 20L income applies for 30Cr cover—**what rules apply?**
* A customer with multiple policies across insurers—**how is eligibility calculated?**
* A self-employed customer with 4.5L income—**what underwriting route applies?**
* A customer from a negative pin code—**can the policy be issued?**

---

# 🔹 14. Summary / Knowledge Questions

* What are the **most common reasons for policy rejection**?
* What are the **key underwriting principles across all guidelines**?
* How do **financial and medical underwriting interact**?
* What are the **main differences between protection and savings underwriting**?
