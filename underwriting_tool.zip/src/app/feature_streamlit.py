"""Feature-routed Streamlit application."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Callable, Literal

import streamlit as st
from dotenv import load_dotenv
from langchain_core.embeddings import Embeddings

from src.config.settings import (
    AppConfig,
    AzureOpenAIConfig,
    OllamaConfig,
    OpenAIConfig,
    RetrieverConfig,
)
from src.features.base import FeatureAnswer
from src.features.digital import streamlit_ui as digital_ui
from src.features.digital.handler import run_query as run_digital_query
from src.features.internet import streamlit_ui as internet_ui
from src.features.internet.handler import run_query as run_internet_query
from src.features.registry import feature_keys, get_feature
from src.features.underwriting import streamlit_ui as underwriting_ui
from src.features.underwriting.handler import run_query as run_underwriting_query
from src.features.web_rag import streamlit_ui as web_rag_ui
from src.features.web_rag.handler import run_query as run_web_rag_query
from src.services.document_store import DocumentStore
from src.llm.providers import build_embeddings

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

Provider = Literal["Azure OpenAI", "OpenAI", "Ollama"]
DomainType = Literal["underwriting", "digital", "internet", "web_rag"]
SOURCE_PREVIEW_HEIGHT_PX = 420
DEFAULT_MAX_OUTPUT_TOKENS = 1024
DEFAULT_EMBEDDING_SHORTLIST_SIZE = 8


def _open_local_file(local_path: Path) -> None:
    try:
        os.startfile(str(local_path))  # type: ignore[attr-defined]
    except AttributeError:
        import webbrowser

        webbrowser.open(local_path.as_uri())


def _render_source_section(*, source_path: str, used_context: str, key_suffix: str) -> None:
    """Render source actions with fixed-size, scrollable preview popovers."""
    path_str = source_path.strip()
    if not path_str:
        return

    open_col, chunks_col, _spacer = st.columns([1, 3, 8])
    with open_col:
        if st.button("📂", key=f"source-open-{key_suffix}", help="Open selected source"):
            _open_local_file(Path(path_str))
    with chunks_col:
        with st.popover("Preview", use_container_width=True):
            st.text_area(
                "Retrieved chunks/context",
                value=used_context.strip() if used_context.strip() else "No chunks/context available.",
                height=SOURCE_PREVIEW_HEIGHT_PX,
                disabled=True,
                key=f"chunks-preview-{key_suffix}",
            )


def _build_retriever_config(top_k: int, temperature: float, max_tokens: int) -> RetrieverConfig:
    cfg = RetrieverConfig()
    cfg.top_k = int(top_k)
    cfg.temperature = float(temperature)
    cfg.max_tokens = int(max_tokens)
    return cfg


def _build_azure_config(api_key: str, endpoint: str, api_version: str, deployment: str) -> AzureOpenAIConfig:
    cfg = AzureOpenAIConfig()
    cfg.api_key = api_key.strip()
    cfg.endpoint = endpoint.strip()
    cfg.api_version = api_version.strip()
    cfg.deployment_name = deployment.strip()
    return cfg


def _build_openai_config(api_key: str, model_name: str, embedding_model_name: str) -> OpenAIConfig:
    cfg = OpenAIConfig()
    cfg.api_key = api_key.strip()
    cfg.model_name = model_name.strip()
    cfg.embedding_model_name = embedding_model_name.strip()
    return cfg


def _build_ollama_config(base_url: str, model_name: str, embedding_model_name: str, stream: bool) -> OllamaConfig:
    cfg = OllamaConfig()
    cfg.base_url = base_url.strip()
    cfg.model_name = model_name.strip()
    cfg.embedding_model_name = embedding_model_name.strip()
    cfg.stream = bool(stream)
    return cfg


def _parse_websites(raw_value: str) -> list[str]:
    """Parse comma/newline separated website list from UI input."""
    websites: list[str] = []
    for part in raw_value.replace("\n", ",").split(","):
        site = part.strip().lower()
        if site:
            websites.append(site)
    return websites


def _env_int(key: str, default: int) -> int:
    """Read integer env var with safe fallback."""
    raw = os.environ.get(key, "").strip()
    if not raw:
        return default
    try:
        return int(raw)
    except ValueError:
        return default


def _build_embedder(
    provider_key: str,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
) -> Embeddings:
    return build_embeddings(
        provider=provider_key,
        azure_cfg=azure_cfg,
        openai_cfg=openai_cfg,
        ollama_cfg=ollama_cfg,
    )


def _feature_ui(feature_key: str) -> tuple[str, str]:
    if feature_key == "digital":
        return digital_ui.FEATURE_DESCRIPTION, digital_ui.CHAT_PLACEHOLDER
    if feature_key == "internet":
        return internet_ui.FEATURE_DESCRIPTION, internet_ui.CHAT_PLACEHOLDER
    if feature_key == "web_rag":
        return web_rag_ui.FEATURE_DESCRIPTION, web_rag_ui.CHAT_PLACEHOLDER
    return underwriting_ui.FEATURE_DESCRIPTION, underwriting_ui.CHAT_PLACEHOLDER


def _available_underwriting_channels(store: DocumentStore | None) -> list[str]:
    """Return distinct underwriting channels available in the loaded store."""
    if store is None:
        return []
    channels = {
        (doc.underwriting_channel or "").strip()
        for doc in store.all()
        if (doc.underwriting_channel or "").strip()
    }
    return sorted(channels)


def _run_feature_query(
    *,
    feature_key: str,
    provider_key: str,
    query: str,
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
    store: DocumentStore | None,
    embeddings: Embeddings | None,
    embedding_shortlist: int,
    websites: list[str],
    internet_max_results: int,
    underwriting_channel: str | None,
    web_rag_chunk_size: int | None = None,
    web_rag_chunk_overlap: int | None = None,
    stream_handler: Callable[[str], None] | None = None,
) -> FeatureAnswer:
    if feature_key == "digital":
        if store is None:
            raise ValueError("Digital catalogue is not configured.")
        retriever_cfg.top_k = max(1, min(int(retriever_cfg.top_k), len(store.all())))
        return run_digital_query(
            provider=provider_key,
            query=query,
            store=store,
            retriever_cfg=retriever_cfg,
            azure_cfg=azure_cfg,
            openai_cfg=openai_cfg,
            ollama_cfg=ollama_cfg,
            embeddings=embeddings,
            embedding_shortlist=embedding_shortlist,
            stream_handler=stream_handler,
        )
    if feature_key == "internet":
        return run_internet_query(
            provider=provider_key,
            query=query,
            websites=websites,
            retriever_cfg=retriever_cfg,
            azure_cfg=azure_cfg,
            openai_cfg=openai_cfg,
            ollama_cfg=ollama_cfg,
            max_results=max(1, int(internet_max_results)),
        )
    if feature_key == "web_rag":
        return run_web_rag_query(
            provider=provider_key,
            query=query,
            websites=websites,
            retriever_cfg=retriever_cfg,
            azure_cfg=azure_cfg,
            openai_cfg=openai_cfg,
            ollama_cfg=ollama_cfg,
            chunk_size=web_rag_chunk_size,
            chunk_overlap=web_rag_chunk_overlap,
        )
    return run_underwriting_query(
        provider=provider_key,
        query=query,
        store=store,
        retriever_cfg=retriever_cfg,
        azure_cfg=azure_cfg,
        openai_cfg=openai_cfg,
        ollama_cfg=ollama_cfg,
        embeddings=embeddings,
        embedding_shortlist=embedding_shortlist,
        selected_channel=(underwriting_channel or "Axis"),
        stream_handler=stream_handler,
    )


def main() -> None:
    app_cfg = AppConfig()
    st.set_page_config(page_title="Document Assistant", layout="wide")
    st.title("Document Assistant")

    feature_options = [key for key in feature_keys() if key in {"underwriting", "digital", "internet", "web_rag"}]
    default_feature = app_cfg.normalized_active_type()
    if default_feature not in feature_options:
        default_feature = "underwriting"

    with st.sidebar:
        selected_type: DomainType = st.selectbox(
            "Select domain",
            options=feature_options,
            index=feature_options.index(default_feature),
            format_func=lambda item: item.title(),
        )
        selected_underwriting_channel: str | None = None
        if selected_type == "underwriting":
            selected_underwriting_channel = st.selectbox(
                "Underwriting channel",
                options=["Axis", "Agency", "DSF", "All channels"],
                index=0,
                help=(
                    "Axis is the default. The matching catelogue/underwriting/catalogue_*.json slice is "
                    "injected into prompts; slide text is filtered to that channel plus "
                    "shared all-channel decks (for example protection UW)."
                ),
            )
        _prov_opts: list[Provider] = ["Azure OpenAI", "OpenAI", "Ollama"]
        _prov_default = app_cfg.normalized_provider()
        _prov_index = (
            2
            if _prov_default == "ollama"
            else 1
            if _prov_default == "openai"
            else 0
        )
        provider: Provider = st.radio(
            "Choose provider",
            options=_prov_opts,
            index=_prov_index,
            horizontal=True,
        )
        # Provider credentials/model details are sourced from environment variables,
        # not shown in the UI.
        if provider == "Azure OpenAI":
            api_key = os.environ.get("AZURE_OPENAI_API_KEY", "")
            endpoint = os.environ.get("AZURE_OPENAI_ENDPOINT", "")
            api_version = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-01")
            chat_model = os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
            embedding_model = os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", "")
            ollama_base_url = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
            ollama_stream = os.environ.get("OLLAMA_STREAM", "true").lower() == "true"
        elif provider == "OpenAI":
            api_key = os.environ.get("OPENAI_API_KEY", "")
            endpoint = ""
            api_version = ""
            chat_model = os.environ.get("OPENAI_MODEL_NAME", "gpt-4o-mini")
            embedding_model = os.environ.get("OPENAI_EMBEDDING_MODEL_NAME", "text-embedding-3-small")
            ollama_base_url = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
            ollama_stream = os.environ.get("OLLAMA_STREAM", "true").lower() == "true"
        else:
            api_key = ""
            endpoint = ""
            api_version = ""
            ollama_base_url = os.environ.get("OLLAMA_BASE_URL", "http://localhost:11434")
            chat_model = os.environ.get("OLLAMA_MODEL_NAME", "llama3.1")
            embedding_model = os.environ.get("OLLAMA_EMBEDDING_MODEL_NAME", "llama3")
            ollama_stream = os.environ.get("OLLAMA_STREAM", "true").lower() == "true"

        top_k = 5
        temperature = st.slider("Temperature", 0.0, 1.0, 0.0, 0.05)
        max_tokens = DEFAULT_MAX_OUTPUT_TOKENS
        use_embedding_shortlist = False
        shortlist_size = DEFAULT_EMBEDDING_SHORTLIST_SIZE

    feature = get_feature(selected_type)
    feature_desc, placeholder = _feature_ui(feature.key)
    st.caption(feature_desc)

    internet_websites = list(feature.websites)
    internet_max_results = int(top_k)
    web_rag_chunk_size = _env_int("WEB_RAG_CHUNK_SIZE", 1500)
    web_rag_chunk_overlap = _env_int("WEB_RAG_CHUNK_OVERLAP", 200)
    if feature.mode == "internet":
        st.sidebar.markdown("### Web Search Settings")
        websites_input = st.sidebar.text_area(
            "Allowed websites (comma or newline separated)",
            value=", ".join(feature.websites),
            help="Example: google.com, who.int, irda.gov.in",
        )
        parsed_sites = _parse_websites(websites_input)
        if parsed_sites:
            internet_websites = parsed_sites
        internet_max_results = int(
            st.sidebar.slider(
                "Web results to fetch",
                min_value=1,
                max_value=15,
                value=min(max(1, int(top_k)), 15),
            )
        )
        if feature.key == "web_rag":
            st.sidebar.markdown("### Web RAG Chunking")
            web_rag_chunk_size = int(
                st.sidebar.number_input(
                    "Chunk size",
                    min_value=200,
                    max_value=8000,
                    value=max(200, web_rag_chunk_size),
                    step=100,
                    help="Default comes from WEB_RAG_CHUNK_SIZE in .env.",
                )
            )
            web_rag_chunk_overlap = int(
                st.sidebar.number_input(
                    "Chunk overlap",
                    min_value=0,
                    max_value=max(0, web_rag_chunk_size - 1),
                    value=min(max(0, web_rag_chunk_overlap), max(0, web_rag_chunk_size - 1)),
                    step=25,
                    help="Default comes from WEB_RAG_CHUNK_OVERLAP in .env.",
                )
            )
            if st.sidebar.button("Re-ingest web page"):
                with st.spinner("Re-ingesting configured websites into Postgres/pgvector..."):
                    # Reuse the web_rag handler ingestion by issuing a no-op query.
                    # The handler will perform ingestion based on configured websites.
                    reingest_provider = (
                        "azure"
                        if provider == "Azure OpenAI"
                        else "openai"
                        if provider == "OpenAI"
                        else "ollama"
                    )
                    _ = run_web_rag_query(
                        provider=reingest_provider,
                        query="",
                        websites=internet_websites,
                        retriever_cfg=_build_retriever_config(int(top_k), float(temperature), int(max_tokens)),
                        azure_cfg=_build_azure_config(api_key, endpoint, api_version, chat_model),
                        openai_cfg=_build_openai_config(
                            api_key,
                            chat_model if provider == "OpenAI" else os.environ.get("OPENAI_MODEL_NAME", "gpt-4o-mini"),
                            embedding_model
                            if provider == "OpenAI"
                            else os.environ.get("OPENAI_EMBEDDING_MODEL_NAME", "text-embedding-3-small"),
                        ),
                        ollama_cfg=_build_ollama_config(
                            ollama_base_url,
                            chat_model if provider == "Ollama" else os.environ.get("OLLAMA_MODEL_NAME", "llama3.1"),
                            embedding_model
                            if provider == "Ollama"
                            else os.environ.get("OLLAMA_EMBEDDING_MODEL_NAME", "llama3"),
                            ollama_stream,
                        ),
                        chunk_size=web_rag_chunk_size,
                        chunk_overlap=web_rag_chunk_overlap,
                    )
                status_path = Path(__file__).resolve().parents[2] / "docs" / "web" / "web_rag_ingestion_status.txt"
                st.success("Re-ingestion completed.")
                st.caption(f"Progress/status file: {status_path}")
                

    store: DocumentStore | None = None
    if feature.mode == "catalogue" and feature.catalogue_paths and feature.key != "underwriting":
        store = DocumentStore.from_default_catalogue_or_builtin(
            default_catalogue_paths=list(feature.catalogue_paths)
        )
    elif feature.key == "underwriting":
        st.markdown("Underwriting")
    else:
        st.markdown(f"**Web search scope:** {', '.join(internet_websites) or 'web'}")

    if "chat_messages" not in st.session_state:
        st.session_state.chat_messages = []

    for idx, message in enumerate(st.session_state.chat_messages):
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            if message.get("role") == "assistant":
                paths = message.get("source_paths")
                if isinstance(paths, list) and paths:
                    if selected_type == "underwriting":
                        underwriting_ui.render_sources_expander([str(p) for p in paths])
                    else:
                        with st.expander("References", expanded=False):
                            st.code("\n".join(str(p) for p in paths), language="text")
            source_path = str(message.get("source_local_path", "")).strip()
            used_context = str(message.get("used_context", "")).strip()
            if selected_type == "underwriting":
                underwriting_ui.render_preview_section(
                    source_path=source_path,
                    used_context=used_context,
                    key_suffix=f"history-{idx}",
                )
            else:
                _render_source_section(
                    source_path=source_path,
                    used_context=used_context,
                    key_suffix=f"history-{idx}",
                )

    query = st.chat_input(placeholder)
    if not query:
        return

    st.session_state.chat_messages.append({"role": "user", "content": query})
    with st.chat_message("user"):
        st.markdown(query)

    retriever_cfg = _build_retriever_config(int(top_k), float(temperature), int(max_tokens))
    azure_cfg = _build_azure_config(api_key, endpoint, api_version, chat_model)
    openai_cfg = _build_openai_config(api_key, chat_model, embedding_model)
    ollama_cfg = _build_ollama_config(ollama_base_url, chat_model, embedding_model, ollama_stream)
    provider_key = (
        "azure"
        if provider == "Azure OpenAI"
        else "openai"
        if provider == "OpenAI"
        else "ollama"
    )

    embeddings: Embeddings | None = None
    embedding_shortlist = 0
    if feature.mode == "catalogue" and use_embedding_shortlist and embedding_model.strip():
        embeddings = _build_embedder(provider_key, azure_cfg, openai_cfg, ollama_cfg)
        embedding_shortlist = int(shortlist_size)

    with st.chat_message("assistant"):
        response_placeholder = st.empty()
        stream_buffer: list[str] = []

        def _on_stream_chunk(chunk_text: str) -> None:
            if not chunk_text:
                return
            stream_buffer.append(chunk_text)
            response_placeholder.markdown("".join(stream_buffer))

        active_stream_handler = (
            _on_stream_chunk
            if provider_key == "ollama" and bool(ollama_cfg.stream) and feature.key in {"underwriting", "digital"}
            else None
        )
        with st.spinner("Processing..."):
            answer = _run_feature_query(
                feature_key=feature.key,
                provider_key=provider_key,
                query=query,
                retriever_cfg=retriever_cfg,
                azure_cfg=azure_cfg,
                openai_cfg=openai_cfg,
                ollama_cfg=ollama_cfg,
                store=store,
                embeddings=embeddings,
                embedding_shortlist=embedding_shortlist,
                websites=internet_websites,
                internet_max_results=internet_max_results,
                underwriting_channel=selected_underwriting_channel,
                web_rag_chunk_size=web_rag_chunk_size,
                web_rag_chunk_overlap=web_rag_chunk_overlap,
                stream_handler=active_stream_handler,
            )
        response_placeholder.markdown(answer.content)
        if answer.source_paths:
            if selected_type == "underwriting":
                underwriting_ui.render_sources_expander(list(answer.source_paths))
            else:
                with st.expander("References", expanded=False):
                    st.code("\n".join(answer.source_paths), language="text")
        if selected_type == "underwriting":
            underwriting_ui.render_preview_section(
                source_path=answer.source_local_path,
                used_context=answer.used_context,
                key_suffix=f"current-{len(st.session_state.chat_messages)}",
            )
        else:
            _render_source_section(
                source_path=answer.source_local_path,
                used_context=answer.used_context,
                key_suffix=f"current-{len(st.session_state.chat_messages)}",
            )

    msg: dict = {
        "role": "assistant",
        "content": answer.content,
        "source_local_path": answer.source_local_path,
        "used_context": answer.used_context,
    }
    if answer.confidence is not None:
        msg["confidence"] = answer.confidence
    if answer.source_paths:
        msg["source_paths"] = list(answer.source_paths)
    st.session_state.chat_messages.append(msg)

