"""Feature-routed Streamlit application."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Literal

import streamlit as st
from dotenv import load_dotenv
from langchain_core.embeddings import Embeddings
from langchain_openai import AzureOpenAIEmbeddings, OpenAIEmbeddings

from src.config.settings import AppConfig, AzureOpenAIConfig, OpenAIConfig, RetrieverConfig
from src.features.base import FeatureAnswer
from src.features.digital import streamlit_ui as digital_ui
from src.features.digital.handler import run_query as run_digital_query
from src.features.internet import streamlit_ui as internet_ui
from src.features.internet.handler import run_query as run_internet_query
from src.features.registry import feature_keys, get_feature
from src.features.underwriting import streamlit_ui as underwriting_ui
from src.features.underwriting.handler import run_query as run_underwriting_query
from src.services.document_store import DocumentStore

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

Provider = Literal["Azure OpenAI", "OpenAI"]
DomainType = Literal["underwriting", "digital", "internet"]


def _open_local_file(local_path: Path) -> None:
    try:
        os.startfile(str(local_path))  # type: ignore[attr-defined]
    except AttributeError:
        import webbrowser

        webbrowser.open(local_path.as_uri())


def _build_retriever_config(top_k: int, temperature: float, max_tokens: int) -> RetrieverConfig:
    cfg = RetrieverConfig()
    cfg.top_k = int(top_k)
    cfg.temperature = float(temperature)
    cfg.max_tokens = int(max_tokens)
    return cfg


def _build_azure_config(api_key: str, endpoint: str, api_version: str, deployment: str) -> AzureOpenAIConfig:
    cfg = AzureOpenAIConfig()
    cfg.api_key = api_key.strip()
    cfg.endpoint = endpoint.strip()
    cfg.api_version = api_version.strip()
    cfg.deployment_name = deployment.strip()
    return cfg


def _build_openai_config(api_key: str, model_name: str, embedding_model_name: str) -> OpenAIConfig:
    cfg = OpenAIConfig()
    cfg.api_key = api_key.strip()
    cfg.model_name = model_name.strip()
    cfg.embedding_model_name = embedding_model_name.strip()
    return cfg


def _parse_websites(raw_value: str) -> list[str]:
    """Parse comma/newline separated website list from UI input."""
    websites: list[str] = []
    for part in raw_value.replace("\n", ",").split(","):
        site = part.strip().lower()
        if site:
            websites.append(site)
    return websites


def _build_embedder(
    provider: Provider,
    api_key: str,
    endpoint: str,
    api_version: str,
    embedding_deployment_or_model: str,
) -> Embeddings:
    if provider == "Azure OpenAI":
        return AzureOpenAIEmbeddings(
            azure_endpoint=endpoint.strip().rstrip("/"),
            azure_deployment=embedding_deployment_or_model.strip(),
            openai_api_version=api_version.strip(),
            openai_api_key=api_key.strip(),
        )
    return OpenAIEmbeddings(api_key=api_key.strip(), model=embedding_deployment_or_model.strip())


def _feature_ui(feature_key: str) -> tuple[str, str]:
    if feature_key == "digital":
        return digital_ui.FEATURE_DESCRIPTION, digital_ui.CHAT_PLACEHOLDER
    if feature_key == "internet":
        return internet_ui.FEATURE_DESCRIPTION, internet_ui.CHAT_PLACEHOLDER
    return underwriting_ui.FEATURE_DESCRIPTION, underwriting_ui.CHAT_PLACEHOLDER


def _run_feature_query(
    *,
    feature_key: str,
    provider_key: str,
    query: str,
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    store: DocumentStore | None,
    embeddings: Embeddings | None,
    embedding_shortlist: int,
    websites: list[str],
    internet_max_results: int,
) -> FeatureAnswer:
    if feature_key == "digital":
        if store is None:
            raise ValueError("Digital catalogue is not configured.")
        retriever_cfg.top_k = max(1, len(store.all()))
        return run_digital_query(
            provider=provider_key,
            query=query,
            store=store,
            retriever_cfg=retriever_cfg,
            azure_cfg=azure_cfg,
            openai_cfg=openai_cfg,
            embeddings=embeddings,
            embedding_shortlist=embedding_shortlist,
        )
    if feature_key == "internet":
        return run_internet_query(
            provider=provider_key,
            query=query,
            websites=websites,
            retriever_cfg=retriever_cfg,
            azure_cfg=azure_cfg,
            openai_cfg=openai_cfg,
            max_results=max(1, int(internet_max_results)),
        )
    if store is None:
        raise ValueError("Underwriting catalogue is not configured.")
    retriever_cfg.top_k = max(1, len(store.all()))
    return run_underwriting_query(
        provider=provider_key,
        query=query,
        store=store,
        retriever_cfg=retriever_cfg,
        azure_cfg=azure_cfg,
        openai_cfg=openai_cfg,
        embeddings=embeddings,
        embedding_shortlist=embedding_shortlist,
    )


def main() -> None:
    app_cfg = AppConfig()
    st.set_page_config(page_title="Document Assistant", layout="wide")
    st.title("Document Assistant")

    feature_options = [key for key in feature_keys() if key in {"underwriting", "digital", "internet"}]
    default_feature = app_cfg.normalized_active_type()
    if default_feature not in feature_options:
        default_feature = "underwriting"

    with st.sidebar:
        selected_type: DomainType = st.selectbox(
            "Select domain",
            options=feature_options,
            index=feature_options.index(default_feature),
            format_func=lambda item: item.title(),
        )
        provider: Provider = st.radio("Choose provider", options=["Azure OpenAI", "OpenAI"], horizontal=True)
        if provider == "Azure OpenAI":
            api_key = st.text_input("API key", value=os.environ.get("AZURE_OPENAI_API_KEY", ""), type="password")
            endpoint = st.text_input("Endpoint", value=os.environ.get("AZURE_OPENAI_ENDPOINT", ""))
            api_version = st.text_input("API version", value=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-01"))
            chat_model = st.text_input("Chat deployment", value=os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"))
            embedding_model = st.text_input("Embedding deployment", value=os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", ""))
        else:
            api_key = st.text_input("API key", value=os.environ.get("OPENAI_API_KEY", ""), type="password")
            endpoint = ""
            api_version = ""
            chat_model = st.text_input("Chat model", value=os.environ.get("OPENAI_MODEL_NAME", "gpt-4o-mini"))
            embedding_model = st.text_input("Embedding model", value=os.environ.get("OPENAI_EMBEDDING_MODEL_NAME", "text-embedding-3-small"))

        top_k = 5
        temperature = st.slider("Temperature", 0.0, 1.0, 0.0, 0.05)
        max_tokens = st.number_input("Max output tokens", min_value=256, max_value=4096, value=1024, step=64)
        use_embedding_shortlist = st.checkbox("Shortlist catalogue with embeddings", value=False)
        shortlist_size = st.slider("Shortlist size", min_value=2, max_value=30, value=8, disabled=not use_embedding_shortlist)

    feature = get_feature(selected_type)
    feature_desc, placeholder = _feature_ui(feature.key)
    st.caption(feature_desc)

    internet_websites = list(feature.websites)
    internet_max_results = int(top_k)
    if feature.mode == "internet":
        st.sidebar.markdown("### Web Search Settings")
        websites_input = st.sidebar.text_area(
            "Allowed websites (comma or newline separated)",
            value=", ".join(feature.websites),
            help="Example: google.com, who.int, irda.gov.in",
        )
        parsed_sites = _parse_websites(websites_input)
        if parsed_sites:
            internet_websites = parsed_sites
        internet_max_results = int(
            st.sidebar.slider(
                "Web results to fetch",
                min_value=1,
                max_value=15,
                value=min(max(1, int(top_k)), 15),
            )
        )
    else:
        st.sidebar.info("For catalogue domains, search automatically runs across all documents in the selected domain.")

    store: DocumentStore | None = None
    if feature.mode == "catalogue" and feature.catalogue_paths:
        store = DocumentStore.from_default_json_or_builtin(
            default_json_paths=list(feature.catalogue_paths)
        )
        st.markdown(f"**Documents in catalogue:** {len(store.all())}")
    else:
        st.markdown(f"**Web search scope:** {', '.join(internet_websites) or 'web'}")

    if "chat_messages" not in st.session_state:
        st.session_state.chat_messages = []

    for idx, message in enumerate(st.session_state.chat_messages):
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            source_path = str(message.get("source_local_path", "")).strip()
            if source_path and st.button("📂", key=f"source-open-{idx}", help="Open source file"):
                _open_local_file(Path(source_path))

    query = st.chat_input(placeholder)
    if not query:
        return

    st.session_state.chat_messages.append({"role": "user", "content": query})
    with st.chat_message("user"):
        st.markdown(query)

    retriever_cfg = _build_retriever_config(int(top_k), float(temperature), int(max_tokens))
    azure_cfg = _build_azure_config(api_key, endpoint, api_version, chat_model)
    openai_cfg = _build_openai_config(api_key, chat_model, embedding_model)
    provider_key = "azure" if provider == "Azure OpenAI" else "openai"

    embeddings: Embeddings | None = None
    embedding_shortlist = 0
    if feature.mode == "catalogue" and use_embedding_shortlist and embedding_model.strip():
        embeddings = _build_embedder(provider, api_key, endpoint, api_version, embedding_model)
        embedding_shortlist = int(shortlist_size)

    with st.chat_message("assistant"):
        with st.spinner("Processing..."):
            answer = _run_feature_query(
                feature_key=feature.key,
                provider_key=provider_key,
                query=query,
                retriever_cfg=retriever_cfg,
                azure_cfg=azure_cfg,
                openai_cfg=openai_cfg,
                store=store,
                embeddings=embeddings,
                embedding_shortlist=embedding_shortlist,
                websites=internet_websites,
                internet_max_results=internet_max_results,
            )
        st.markdown(answer.content)
        if answer.source_local_path and st.button(
            "📂",
            key=f"source-open-current-{len(st.session_state.chat_messages)}",
            help="Open source file",
        ):
            _open_local_file(Path(answer.source_local_path))

    st.session_state.chat_messages.append(
        {
            "role": "assistant",
            "content": answer.content,
            "source_local_path": answer.source_local_path,
            "used_context": answer.used_context,
        }
    )

