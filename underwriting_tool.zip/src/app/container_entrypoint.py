"""Container entrypoint for Streamlit and CLI modes."""

from __future__ import annotations

import os
import subprocess
import sys
from typing import List


def _parse_port(raw_port: str) -> str:
    """Return a safe port value for Streamlit, defaulting to 8501."""
    port = raw_port.strip()
    if not port:
        return "8501"
    if not port.isdigit():
        return "8501"
    return port


def _streamlit_command() -> List[str]:
    """Build the Streamlit command used in container runtime."""
    port = _parse_port(os.environ.get("PORT", "8501"))
    return [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        "src/app/streamlit_app.py",
        "--server.address=0.0.0.0",
        f"--server.port={port}",
        "--server.headless=true",
    ]


def _cli_command() -> List[str]:
    """Build the CLI command for one-shot query mode in container runtime."""
    query = os.environ.get("CLI_QUERY", "").strip()
    if not query:
        raise ValueError(
            "CLI mode requires CLI_QUERY environment variable with a non-empty query."
        )
    return [sys.executable, "main.py", query]


def main() -> None:
    """Run the configured app mode inside the Docker container."""
    mode = os.environ.get("APP_MODE", "streamlit").strip().lower()
    if mode == "streamlit":
        cmd = _streamlit_command()
    elif mode == "cli":
        cmd = _cli_command()
    else:
        raise ValueError("APP_MODE must be either 'streamlit' or 'cli'.")

    subprocess.run(cmd, check=True)


if __name__ == "__main__":
    main()
