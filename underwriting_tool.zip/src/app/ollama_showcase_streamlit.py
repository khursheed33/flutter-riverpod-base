"""Redesigned Streamlit showcase for Ollama chat and embeddings."""

from __future__ import annotations

from pathlib import Path
from typing import Generator

import streamlit as st
from dotenv import load_dotenv
from langchain_core.messages import HumanMessage
from langchain_ollama import ChatOllama, OllamaEmbeddings

from src.config.settings import OllamaConfig

load_dotenv(Path(__file__).resolve().parents[2] / ".env")


def _stream_chat_response(llm: ChatOllama, prompt: str) -> Generator[str, None, None]:
    """Yield model output chunks for real-time UI streaming."""
    for chunk in llm.stream([HumanMessage(content=prompt)]):
        content = getattr(chunk, "content", "")
        if isinstance(content, str) and content:
            yield content
        elif isinstance(content, list):
            for item in content:
                if isinstance(item, dict):
                    text = str(item.get("text", ""))
                    if text:
                        yield text


def _render_chat_window(
    *,
    base_url: str,
    chat_model: str,
    temperature: float,
    max_tokens: int,
    stream_enabled: bool,
) -> None:
    """Render a stateless, always-fresh chat interface."""
    st.subheader("Chat")
    prompt = st.text_area("Message", height=180, placeholder="Type a message...")
    send = st.button("Send", type="primary", use_container_width=True)
    if not send:
        return
    if not prompt.strip():
        st.warning("Enter a message first.")
        return

    llm = ChatOllama(
        model=chat_model.strip(),
        base_url=base_url.strip(),
        temperature=temperature,
        num_predict=max_tokens,
        streaming=stream_enabled,
    )

    st.markdown("**Assistant**")
    if stream_enabled:
        st.write_stream(_stream_chat_response(llm, prompt.strip()))
        return
    reply = llm.invoke([HumanMessage(content=prompt.strip())])
    st.markdown(str(getattr(reply, "content", "")).strip())


def _render_embedding_window(*, base_url: str, embedding_model: str) -> None:
    """Render embedding test interface and return embedding vector data."""
    st.subheader("Embeddings")
    embed_text = st.text_area("Input text", height=180, placeholder="Text to embed...")
    generate = st.button("Generate Embedding", type="primary", use_container_width=True)
    if not generate:
        return
    if not embed_text.strip():
        st.warning("Enter text first.")
        return

    embedder = OllamaEmbeddings(
        model=embedding_model.strip(),
        base_url=base_url.strip(),
    )
    vector = embedder.embed_query(embed_text.strip())

    st.success(f"Embedding generated. Dimensions: {len(vector)}")
    st.markdown("**Vector preview (first 32 values)**")
    st.code(str(vector[:32]))
    with st.expander("Full embedding vector"):
        st.code(str(vector))


def main() -> None:
    """Run the redesigned Ollama showcase app."""
    cfg = OllamaConfig()
    st.set_page_config(page_title="Ollama Test UI", page_icon="🦙", layout="wide")
    st.title("Ollama Test UI")

    left_panel, right_panel = st.columns([1, 2], gap="large")

    with left_panel:
        st.subheader("Configuration")
        mode = st.radio("Mode", options=["Chat", "Embeddings"], index=0)
        base_url = st.text_input("Base URL", value=cfg.base_url)
        chat_model = st.text_input("Chat Model", value=cfg.model_name)
        embedding_model = st.text_input("Embedding Model", value=cfg.embedding_model_name)
        stream_enabled = st.checkbox("Stream response", value=cfg.stream)
        temperature = st.slider("Temperature", min_value=0.0, max_value=1.0, value=0.0, step=0.05)
        max_tokens = st.number_input(
            "Max Tokens",
            min_value=32,
            max_value=8192,
            value=1024,
            step=32,
        )

    with right_panel:
        if mode == "Chat":
            _render_chat_window(
                base_url=base_url,
                chat_model=chat_model,
                temperature=float(temperature),
                max_tokens=int(max_tokens),
                stream_enabled=stream_enabled,
            )
        else:
            _render_embedding_window(
                base_url=base_url,
                embedding_model=embedding_model,
            )


if __name__ == "__main__":
    main()
