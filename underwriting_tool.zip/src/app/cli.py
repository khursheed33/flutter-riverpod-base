"""Feature-routed CLI for underwriting, digital, and internet tools."""

from __future__ import annotations

import argparse
import sys

from rich.console import Console
from rich.panel import Panel

from src.config.settings import app_config, azure_config, openai_config, retriever_config
from src.features.digital.handler import run_query as run_digital_query
from src.features.internet.handler import run_query as run_internet_query
from src.features.registry import get_feature
from src.features.underwriting.handler import run_query as run_underwriting_query
from src.services.document_store import DocumentStore

console = Console()


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Feature-routed assistant CLI")
    parser.add_argument("query", nargs="?", help="Query text. Omit for interactive mode.")
    parser.add_argument("--top-k", type=int, default=None, help="Top matches to retrieve.")
    return parser


def _run_once(query: str) -> None:
    active_type = app_config.normalized_active_type()
    provider = app_config.normalized_provider()
    feature = get_feature(active_type)

    if feature.mode == "catalogue" and not feature.catalogue_paths:
        raise ValueError(f"Feature {feature.key} is missing catalogue path(s).")

    store = (
        DocumentStore.from_default_json_or_builtin(
            default_json_paths=list(feature.catalogue_paths)
        )
        if feature.mode == "catalogue"
        else None
    )

    if feature.key == "digital":
        if store is None:
            raise ValueError("Digital feature catalogue is not available.")
        answer = run_digital_query(
            provider=provider,
            query=query,
            store=store,
            retriever_cfg=retriever_config,
            azure_cfg=azure_config,
            openai_cfg=openai_config,
        )
    elif feature.key == "internet":
        answer = run_internet_query(
            provider=provider,
            query=query,
            websites=feature.websites,
            retriever_cfg=retriever_config,
            azure_cfg=azure_config,
            openai_cfg=openai_config,
            max_results=max(3, retriever_config.top_k),
        )
    else:
        if store is None:
            raise ValueError("Underwriting feature catalogue is not available.")
        answer = run_underwriting_query(
            provider=provider,
            query=query,
            store=store,
            retriever_cfg=retriever_config,
            azure_cfg=azure_config,
            openai_cfg=openai_config,
        )

    console.print(Panel(answer.content, title=f"[bold cyan]{feature.display_name}[/bold cyan]"))


def main() -> None:
    args = _build_parser().parse_args()
    if args.top_k is not None:
        retriever_config.top_k = int(args.top_k)

    if args.query:
        try:
            _run_once(args.query.strip())
        except Exception as exc:  # noqa: BLE001
            console.print(f"[bold red]Error:[/bold red] {exc}")
            sys.exit(1)
        return

    console.print("[dim]Interactive mode (type 'quit' to exit)[/dim]")
    while True:
        query = console.input("[bold green]Query > [/bold green]").strip()
        if query.lower() in {"quit", "exit", "q"}:
            break
        if not query:
            continue
        try:
            _run_once(query)
        except Exception as exc:  # noqa: BLE001
            console.print(f"[bold red]Error:[/bold red] {exc}")


if __name__ == "__main__":
    main()

