"""
main.py – Interactive CLI for the document retriever.

Usage
─────
  # Single query
  python main.py "What document covers our ML infrastructure?"

  # Interactive REPL
  python main.py

  # Use a custom document catalogue from a JSON file
  python main.py --docs my_documents.json "onboarding steps for new engineers"

  # Return top-3 documents
  python main.py --top-k 3 "security compliance"
"""
from __future__ import annotations

import argparse
import logging
import sys

from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich import box

from src.config.settings import app_config, azure_config, openai_config, retriever_config
from src.services.document_store import DocumentStore
from src.llm.retriever import (
    DocumentRetriever,
    OpenAIDocumentRetriever,
    RetrievalMatch,
    RetrievalResult,
)

console = Console()
logging.basicConfig(level=logging.WARNING)


# ─── Display helpers ──────────────────────────────────────────────────────────


def _format_slides_cell(m: RetrievalMatch) -> str:
    if not m.matched_slides:
        return "—"
    lines = []
    for s in m.matched_slides:
        bits = [f"Slide {s.number}"]
        if s.title:
            bits.append(s.title)
        head = ": ".join(bits) if len(bits) > 1 else bits[0]
        if s.note:
            lines.append(f"{head} — {s.note}")
        else:
            lines.append(head)
    return "\n".join(lines)


def _print_result(result: RetrievalResult) -> None:
    console.print()

    if result.query_understood_as:
        console.print(
            Panel(
                f"[dim]{result.query_understood_as}[/dim]",
                title="[bold cyan]Query interpreted as[/bold cyan]",
                border_style="cyan",
            )
        )

    if not result.matches:
        console.print(
            Panel(
                "[yellow]No matching document found.[/yellow]",
                border_style="yellow",
            )
        )
        return

    table = Table(box=box.ROUNDED, show_lines=True, expand=True)
    table.add_column("Rank", style="bold", justify="center", width=6)
    table.add_column("Title", style="bold white")
    table.add_column("Type", justify="center", width=6)
    table.add_column("Score", justify="center", width=7)
    table.add_column("Reasoning", style="dim")
    table.add_column("Slides", style="magenta", width=36)
    table.add_column("URL", style="blue underline")

    for m in result.matches:
        score_color = (
            "green" if m.relevance_score >= 0.75
            else "yellow" if m.relevance_score >= 0.4
            else "red"
        )
        reasoning = m.reasoning if retriever_config.return_reasoning else "—"
        table.add_row(
            str(m.rank),
            m.document.title,
            m.document.doc_type.upper(),
            f"[{score_color}]{m.relevance_score:.2f}[/{score_color}]",
            reasoning,
            _format_slides_cell(m),
            m.document.url,
        )

    console.print(table)
    console.print()


# ─── CLI ──────────────────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="LLM-powered document retriever (Azure OpenAI + LangChain)"
    )
    p.add_argument(
        "query",
        nargs="?",
        help="Query to run (omit to enter interactive mode)",
    )
    p.add_argument(
        "--docs",
        metavar="PATH",
        help="Path to a JSON file with custom documents (overrides built-in catalogue)",
    )
    p.add_argument(
        "--top-k",
        type=int,
        default=None,
        help=f"Number of documents to return (default: {retriever_config.top_k})",
    )
    p.add_argument(
        "--no-reasoning",
        action="store_true",
        help="Hide the LLM reasoning column",
    )
    p.add_argument(
        "--verbose",
        action="store_true",
        help="Enable debug logging",
    )
    return p


def main() -> None:
    args = build_parser().parse_args()

    if args.verbose:
        logging.basicConfig(level=logging.DEBUG, force=True)

    # ── Apply CLI overrides to config ─────────────────────────────────────────
    if args.top_k is not None:
        retriever_config.top_k = args.top_k
    if args.no_reasoning:
        retriever_config.return_reasoning = False

    # ── Load document store ───────────────────────────────────────────────────
    store = (
        DocumentStore.from_json_file(args.docs)
        if args.docs
        else DocumentStore.from_default_json_or_builtin()
    )

    # ── Build retriever ───────────────────────────────────────────────────────
    try:
        provider = app_config.normalized_provider()
        if provider == "openai":
            openai_config.validate()
            retriever = OpenAIDocumentRetriever(
                model_name=openai_config.model_name,
                api_key=openai_config.api_key,
                store=store,
                ret_cfg=retriever_config,
                active_type=app_config.normalized_active_type(),
            )
        else:
            azure_config.validate()
            retriever = DocumentRetriever(
                store=store,
                azure_cfg=azure_config,
                ret_cfg=retriever_config,
                active_type=app_config.normalized_active_type(),
            )
    except EnvironmentError as exc:
        console.print(f"[bold red]Configuration error:[/bold red] {exc}")
        sys.exit(1)

    console.print(
        Panel(
            "[bold green]Document Retriever[/bold green]  "
            f"[dim]({len(store.all())} documents · top-{retriever_config.top_k} · "
            f"provider={provider} · active={app_config.normalized_active_type()})[/dim]",
            border_style="green",
        )
    )

    # ── Single query mode ─────────────────────────────────────────────────────
    if args.query:
        try:
            result = retriever.retrieve(args.query)
            _print_result(result)
        except Exception as exc:
            console.print(f"[bold red]Error:[/bold red] {exc}")
            sys.exit(1)
        return

    # ── Interactive REPL mode ─────────────────────────────────────────────────
    console.print("[dim]Type your query and press Enter. Type 'quit' or Ctrl-C to exit.[/dim]\n")
    while True:
        try:
            query = console.input("[bold cyan]Query >[/bold cyan] ").strip()
        except (KeyboardInterrupt, EOFError):
            console.print("\n[dim]Goodbye.[/dim]")
            break

        if query.lower() in {"quit", "exit", "q"}:
            console.print("[dim]Goodbye.[/dim]")
            break
        if not query:
            continue

        try:
            result = retriever.retrieve(query)
            _print_result(result)
        except Exception as exc:
            console.print(f"[bold red]Error:[/bold red] {exc}")


if __name__ == "__main__":
    main()
