"""Streamlit entrypoint routed to feature-based UI implementation."""

from __future__ import annotations

from src.app.feature_streamlit import main


if __name__ == "__main__":
    main()
