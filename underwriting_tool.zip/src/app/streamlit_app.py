"""
Streamlit UI for the LLM document retriever.

Run from the project directory:
    streamlit run streamlit_app.py
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import List, Literal, Optional
from urllib.parse import urlparse

import streamlit as st
from dotenv import load_dotenv
from langchain_core.embeddings import Embeddings
from langchain_openai import AzureOpenAIEmbeddings, OpenAIEmbeddings

from src.config.settings import AppConfig, AzureOpenAIConfig, OpenAIConfig, RetrieverConfig
from src.services.document_store import DocumentStore
from src.llm.retriever import DocumentRetriever, OpenAIDocumentRetriever, RetrievalResult

load_dotenv(Path(__file__).resolve().parents[2] / ".env")

Provider = Literal["Azure OpenAI", "OpenAI"]


def _default_ui_provider() -> Provider:
    app_cfg = AppConfig()
    return "Azure OpenAI" if app_cfg.normalized_provider() == "azure" else "OpenAI"


def _build_azure_config(
    api_key: str,
    endpoint: str,
    api_version: str,
    chat_deployment: str,
) -> AzureOpenAIConfig:
    cfg = AzureOpenAIConfig()
    cfg.api_key = api_key.strip()
    cfg.endpoint = endpoint.strip()
    cfg.api_version = api_version.strip()
    cfg.deployment_name = chat_deployment.strip()
    return cfg


def _build_openai_config(
    api_key: str,
    model_name: str,
    embedding_model_name: str,
) -> OpenAIConfig:
    cfg = OpenAIConfig()
    cfg.api_key = api_key.strip()
    cfg.model_name = model_name.strip()
    cfg.embedding_model_name = embedding_model_name.strip()
    return cfg


def _build_retriever_config(
    top_k: int,
    temperature: float,
    max_tokens: int,
    return_reasoning: bool,
) -> RetrieverConfig:
    cfg = RetrieverConfig()
    cfg.top_k = int(top_k)
    cfg.temperature = float(temperature)
    cfg.max_tokens = int(max_tokens)
    cfg.return_reasoning = bool(return_reasoning)
    return cfg


def _build_embedder(
    provider: Provider,
    api_key: str,
    endpoint: str,
    api_version: str,
    embedding_deployment_or_model: str,
) -> Embeddings:
    if provider == "Azure OpenAI":
        return AzureOpenAIEmbeddings(
            azure_endpoint=endpoint.strip().rstrip("/"),
            azure_deployment=embedding_deployment_or_model.strip(),
            openai_api_version=api_version.strip(),
            openai_api_key=api_key.strip(),
        )
    return OpenAIEmbeddings(
        api_key=api_key.strip(),
        model=embedding_deployment_or_model.strip(),
    )


def _filename_from_url(url: str) -> str:
    parsed = urlparse(url)
    name = Path(parsed.path).name.strip()
    return name or "unknown-file"


def _render_source_url(url: str) -> str:
    parsed = urlparse(url.strip())
    if parsed.scheme in {"http", "https"}:
        return f"[{url}]({url})"

    return f"`{url}`"


def _resolve_local_source_path(url: str) -> Optional[Path]:
    parsed = urlparse(url.strip())
    if parsed.scheme in {"http", "https"}:
        return None

    project_root = Path(__file__).resolve().parents[2]
    relative_path = parsed.path.strip().lstrip("/\\")
    if not relative_path:
        return None

    candidate = (project_root / relative_path).resolve()
    try:
        candidate.relative_to(project_root)
    except ValueError:
        # Guard against path traversal.
        return None

    if candidate.exists() and candidate.is_file():
        return candidate
    return None


def _open_local_file(local_path: Path) -> None:
    try:
        os.startfile(str(local_path))  # type: ignore[attr-defined]
    except AttributeError:
        import webbrowser

        webbrowser.open(local_path.as_uri())


def _short_query_intent(query: str) -> str:
    trimmed = " ".join(query.strip().split())
    return trimmed if len(trimmed) <= 120 else trimmed[:117] + "..."


def _is_greeting(query: str) -> bool:
    q = query.strip().lower()
    greetings = {"hi", "hello", "hey", "good morning", "good afternoon", "good evening"}
    return q in greetings


def _is_catalog_explainer_query(query: str) -> bool:
    q = query.strip().lower()
    keys = ("catalog", "catalogue", "what docs", "which docs", "documents do you have")
    return any(k in q for k in keys)


def _catalog_overview(store: DocumentStore, max_docs: int = 8) -> str:
    docs = store.all()
    lines = ["### Documents currently in this catalogue"]
    for d in docs[:max_docs]:
        lines.append(f"- **{d.title}** ({d.doc_type.upper()})")
        lines.append(f"  - Focus: {d.summary}")
    if len(docs) > max_docs:
        lines.append(f"- ...and {len(docs) - max_docs} more documents.")
    return "\n".join(lines)


def _compose_assistant_reply(_query: str, result: RetrievalResult, store: DocumentStore) -> str:
    if not result.matches:
        return (
            "I could not find a strong direct match, but here is what this catalogue contains "
            "so you can quickly pick the right source document:\n\n"
            f"{_catalog_overview(store, max_docs=6)}"
        )

    best = result.best
    if best is None:
        return (
            "I could not find a strong direct match, but here is the available catalogue:\n\n"
            f"{_catalog_overview(store, max_docs=6)}"
        )

    lines: List[str] = [""]

    if best.matched_slides:
        for slide in best.matched_slides:
            detail = slide.note.strip()
            if not detail:
                # fallback to catalogue slide summary when LLM note is absent
                mapped = next(
                    (s.summary for s in best.document.slides if s.number == slide.number),
                    "",
                )
                detail = mapped.strip() or "Relevant content for your query."
            title = slide.title.strip() or "Untitled"
            lines.append(f"- **Slide {slide.number} ({title}):** {detail}")
    else:
        lines.append(best.reasoning.strip() or best.document.summary.strip())

    lines.append("")
    lines.append("**Source**")
    lines.append(f"- **File:** `{_filename_from_url(best.document.url)}`")
    lines.append(f"- **URL:** {_render_source_url(best.document.url)}")
    return "\n".join(lines)


def main() -> None:
    active_type = AppConfig().normalized_active_type()
    assistant_title = f"{active_type.title()} Document Assistant"
    st.set_page_config(page_title=assistant_title, layout="wide")
    st.title(assistant_title)
    st.caption(
        "Ask questions across your underwriting documents and get clear, context-aware answers with source references. "
        "Supports PPT/PPTX and PDF catalogues via Azure OpenAI or OpenAI."
    )
    st.markdown(
        """
        <style>
        [data-testid="stMainBlockContainer"] {
            max-width: 80%;
            width: 80%;
            margin-left: auto;
            margin-right: auto;
        }
        [data-testid="stChatInput"],
        [data-testid="stChatInputContainer"] {
            max-width: 80%;
            width: 80%;
            margin-left: auto;
            margin-right: auto;
        }
        </style>
        """,
        unsafe_allow_html=True,
    )

    with st.sidebar:
        st.header("LLM provider")
        default_provider = _default_ui_provider()
        provider: Provider = st.radio(
            "Choose provider",
            options=["Azure OpenAI", "OpenAI"],
            horizontal=True,
            index=0 if default_provider == "Azure OpenAI" else 1,
        )

        if provider == "Azure OpenAI":
            st.subheader("Azure OpenAI")
            api_key = st.text_input(
                "API key",
                value=os.environ.get("AZURE_OPENAI_API_KEY", ""),
                type="password",
            )
            endpoint = st.text_input(
                "Endpoint",
                value=os.environ.get("AZURE_OPENAI_ENDPOINT", ""),
                placeholder="https://your-resource.openai.azure.com/",
            )
            api_version = st.text_input(
                "API version",
                value=os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-01"),
            )
            chat_model = st.text_input(
                "Chat deployment",
                value=os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o"),
            )
            embedding_model = st.text_input(
                "Embedding deployment",
                value=os.environ.get("AZURE_OPENAI_EMBEDDING_DEPLOYMENT", ""),
                help="Optional unless embedding shortlist is enabled.",
            )
        else:
            st.subheader("OpenAI")
            api_key = st.text_input(
                "API key",
                value=os.environ.get("OPENAI_API_KEY", ""),
                type="password",
            )
            endpoint = ""
            api_version = ""
            chat_model = st.text_input(
                "Chat model",
                value=os.environ.get("OPENAI_MODEL_NAME", "gpt-4o-mini"),
            )
            embedding_model = st.text_input(
                "Embedding model",
                value=os.environ.get("OPENAI_EMBEDDING_MODEL_NAME", "text-embedding-3-small"),
                help="Optional unless embedding shortlist is enabled.",
            )

        st.subheader("Embeddings")
        use_embedding_shortlist = st.checkbox(
            "Shortlist catalogue with embeddings",
            value=False,
            help="Rank documents by similarity, then send only top N to the chat model.",
        )
        shortlist_size = st.slider(
            "Shortlist size (N)",
            min_value=2,
            max_value=30,
            value=8,
            disabled=not use_embedding_shortlist,
        )

        st.subheader("Retrieval")
        top_k = st.number_input("Documents to return (LLM)", min_value=1, max_value=10, value=1)
        temperature = st.slider("Temperature", 0.0, 1.0, 0.0, 0.05)
        max_tokens = st.number_input(
            "Max output tokens (chat)",
            min_value=256,
            max_value=4096,
            value=1024,
            step=64,
        )
        show_reasoning = st.checkbox("Show reasoning", value=True)

    # Catalogue upload intentionally disabled; app always uses project default JSON.
    store = DocumentStore.from_default_json_or_builtin()

    st.markdown(f"**Documents in catalogue:** {len(store.all())}")
    if "chat_messages" not in st.session_state:
        st.session_state.chat_messages = []

    for idx, message in enumerate(st.session_state.chat_messages):
        with st.chat_message(message["role"]):
            st.markdown(message["content"])
            source_local_path = message.get("source_local_path")
            if message["role"] == "assistant" and source_local_path:
                if st.button("Open source file", key=f"open-source-{idx}"):
                    try:
                        _open_local_file(Path(source_local_path))
                    except Exception as exc:  # noqa: BLE001
                        st.error(f"Could not open file: {exc}")

    query = st.chat_input("Ask about your documents...")
    if not query:
        return

    st.session_state.chat_messages.append({"role": "user", "content": query})
    with st.chat_message("user"):
        st.markdown(query)

    if _is_greeting(query):
        greeting_reply = (
            "Hello! I can help you find answers from your PPT/PPTX and PDF catalogue.\n\n"
            "Ask me a question (for example, onboarding steps, policy details, roadmap topics), "
            "and I will return a concise summary plus document reference."
        )
        with st.chat_message("assistant"):
            st.markdown(greeting_reply)
        st.session_state.chat_messages.append(
            {"role": "assistant", "content": greeting_reply}
        )
        return

    if _is_catalog_explainer_query(query):
        overview = (
            f"I understand you're asking about **{_short_query_intent(query)}**.\n\n"
            f"{_catalog_overview(store)}"
        )
        with st.chat_message("assistant"):
            st.markdown(overview)
        st.session_state.chat_messages.append({"role": "assistant", "content": overview})
        return

    retriever_cfg = _build_retriever_config(
        top_k, temperature, max_tokens, show_reasoning
    )

    try:
        if provider == "Azure OpenAI":
            azure_cfg = _build_azure_config(api_key, endpoint, api_version, chat_model)
            azure_cfg.validate()
            retriever = DocumentRetriever(
                store=store,
                azure_cfg=azure_cfg,
                ret_cfg=retriever_cfg,
                active_type=active_type,
            )
        else:
            openai_cfg = _build_openai_config(api_key, chat_model, embedding_model)
            openai_cfg.validate()
            retriever = OpenAIDocumentRetriever(
                model_name=openai_cfg.model_name,
                api_key=openai_cfg.api_key,
                store=store,
                ret_cfg=retriever_cfg,
                active_type=active_type,
            )
    except Exception as exc:  # noqa: BLE001
        with st.chat_message("assistant"):
            st.error(f"Could not create retriever: {exc}")
        return

    embedder: Embeddings | None = None
    embed_shortlist = 0
    if use_embedding_shortlist:
        if not embedding_model.strip():
            with st.chat_message("assistant"):
                st.error("Set an embedding deployment/model to use shortlisting.")
            return
        try:
            embedder = _build_embedder(
                provider=provider,
                api_key=api_key,
                endpoint=endpoint,
                api_version=api_version,
                embedding_deployment_or_model=embedding_model,
            )
            embed_shortlist = int(shortlist_size)
        except Exception as exc:  # noqa: BLE001
            with st.chat_message("assistant"):
                st.error(f"Could not create embeddings client: {exc}")
            return

    with st.chat_message("assistant"):
        with st.spinner(f"Calling {provider}..."):
            try:
                result = retriever.retrieve(
                    query.strip(),
                    embeddings=embedder,
                    embedding_shortlist=embed_shortlist,
                )
            except Exception as exc:  # noqa: BLE001
                st.error(f"Retrieval failed: {exc}")
                return
        reply = _compose_assistant_reply(query, result, store)
        st.markdown(reply)
        source_path = ""
        if result.best is not None:
            local_source = _resolve_local_source_path(result.best.document.url)
            if local_source:
                source_path = str(local_source)
                if st.button("Open source file", key="open-source-current"):
                    try:
                        _open_local_file(local_source)
                    except Exception as exc:  # noqa: BLE001
                        st.error(f"Could not open file: {exc}")

    st.session_state.chat_messages.append(
        {
            "role": "assistant",
            "content": reply,
            "source_local_path": source_path,
        }
    )


if __name__ == "__main__":
    main()
