"""
example_usage.py – Shows how to embed the retriever in your own code.

Run after copying .env.example → .env and filling in your Azure credentials.
"""
from src.services.document_store import Document, DocumentStore
from src.llm.retriever import DocumentRetriever


def example_simple() -> None:
    """Use the built-in document catalogue with a single query."""
    retriever = DocumentRetriever()

    result = retriever.retrieve("How do I onboard a new employee?")

    print(f"Query understood as: {result.query_understood_as}\n")
    for m in result.matches:
        print(f"  [{m.rank}] {m.document.title}")
        print(f"       Score   : {m.relevance_score:.2f}")
        print(f"       Reason  : {m.reasoning}")
        if m.matched_slides:
            for s in m.matched_slides:
                line = f"       Slide {s.number}: {s.title}" if s.title else f"       Slide {s.number}"
                if s.note:
                    line = f"{line} — {s.note}"
                print(line)
        print(f"       URL     : {m.document.url}\n")


def example_top_k() -> None:
    """Return top-3 documents for a broad query."""
    from src.config.settings import retriever_config
    retriever_config.top_k = 3

    retriever = DocumentRetriever()
    result = retriever.retrieve("engineering and technical documentation")

    for m in result.matches:
        print(f"{m.rank}. {m.document.title}  →  {m.document.url}")


def example_custom_store() -> None:
    """Plug in your own documents at runtime."""
    store = DocumentStore(
        documents=[
            Document(
                id="brand_guidelines",
                title="Brand Guidelines 2025",
                url="https://storage.mycompany.com/brand/guidelines_2025.pdf",
                doc_type="pdf",
                summary=(
                    "Official brand guidelines covering logo usage, colour palette, "
                    "typography rules, tone of voice, and approved photography styles."
                ),
                tags=["design", "brand", "marketing"],
            ),
            Document(
                id="investor_deck_q2",
                title="Investor Deck Q2 2025",
                url="https://storage.mycompany.com/investor/q2_2025_deck.pptx",
                doc_type="pptx",
                summary=(
                    "Q2 2025 investor presentation: financial highlights, ARR growth, "
                    "key customer wins, competitive positioning, and 12-month outlook."
                ),
                tags=["finance", "investors", "growth"],
            ),
        ]
    )

    retriever = DocumentRetriever(store=store)
    url = retriever.retrieve_url("I need our investor pitch slides")
    print(f"Best match URL: {url}")


def example_load_from_json() -> None:
    """Load a catalogue from an external JSON file."""
    # catelogue/underwriting.json should be an array of document objects:
    # [{"id": "...", "title": "...", "url": "...", "summary": "...", ...}, ...]
    store = DocumentStore.from_json_file("catelogue/underwriting.json")
    retriever = DocumentRetriever(store=store)
    result = retriever.retrieve("find the security compliance document")
    if result.best:
        print(result.best.document.url)


if __name__ == "__main__":
    print("=== Simple example ===")
    example_simple()

    print("\n=== Top-K example ===")
    example_top_k()

    print("\n=== Custom store example ===")
    example_custom_store()
