"""Centralized, environment-driven configuration."""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv
from src.features.registry import get_feature

# Load .env from the project root.
_env_path = Path(__file__).resolve().parents[2] / ".env"
load_dotenv(dotenv_path=_env_path, override=False)


def _clean_env_value(name: str, default: str = "") -> str:
    """Read and sanitize environment values loaded from .env."""
    raw_value = os.environ.get(name, default)
    cleaned = str(raw_value).strip().strip("'").strip('"').strip()
    return cleaned


class AzureOpenAIConfig:
    """Azure OpenAI connection settings."""

    api_key: str = os.environ.get("AZURE_OPENAI_API_KEY", "")
    endpoint: str = os.environ.get("AZURE_OPENAI_ENDPOINT", "")
    api_version: str = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-01")
    deployment_name: str = os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
    embedding_deployment_name: str = os.environ.get(
        "AZURE_OPENAI_EMBEDDING_DEPLOYMENT", ""
    )

    def validate(self) -> None:
        missing = [
            name
            for name, val in {
                "AZURE_OPENAI_API_KEY": self.api_key,
                "AZURE_OPENAI_ENDPOINT": self.endpoint,
                "AZURE_OPENAI_DEPLOYMENT_NAME": self.deployment_name,
            }.items()
            if not val
        ]
        if missing:
            raise EnvironmentError(
                f"Missing required environment variables: {', '.join(missing)}. "
                "Copy .env.example → .env and fill in your values."
            )


class OpenAIConfig:
    """OpenAI connection settings."""

    api_key: str = _clean_env_value("OPENAI_API_KEY", "")
    model_name: str = _clean_env_value("OPENAI_MODEL_NAME", "gpt-4o-mini")
    embedding_model_name: str = _clean_env_value(
        "OPENAI_EMBEDDING_MODEL_NAME", "text-embedding-3-small"
    )

    def validate(self) -> None:
        if not self.api_key:
            raise EnvironmentError(
                "Missing required environment variable: OPENAI_API_KEY. "
                "Copy .env.example → .env and fill in your values."
            )
        if len(self.api_key) < 20:
            raise EnvironmentError(
                "OPENAI_API_KEY appears malformed (too short). "
                "Set a valid OpenAI key and restart the app."
            )


class OllamaConfig:
    """Ollama connection settings."""

    base_url: str = _clean_env_value("OLLAMA_BASE_URL", "http://localhost:11434")
    model_name: str = _clean_env_value("OLLAMA_MODEL_NAME", "llama3.1")
    embedding_model_name: str = _clean_env_value("OLLAMA_EMBEDDING_MODEL_NAME", "llama3")
    stream: bool = _clean_env_value("OLLAMA_STREAM", "true").lower() == "true"

    def validate(self) -> None:
        if not self.model_name:
            raise EnvironmentError(
                "Missing required environment variable: OLLAMA_MODEL_NAME."
            )
        if not self.embedding_model_name:
            raise EnvironmentError(
                "Missing required environment variable: OLLAMA_EMBEDDING_MODEL_NAME."
            )


class RetrieverConfig:
    """Retrieval behaviour settings."""

    temperature: float = float(os.environ.get("LLM_TEMPERATURE", "0.0"))
    max_tokens: int = int(os.environ.get("LLM_MAX_TOKENS", "1024"))
    top_k: int = int(os.environ.get("TOP_K", "1"))
    return_reasoning: bool = os.environ.get("RETURN_REASONING", "true").lower() == "true"
    # When true, prints and logs full rendered LLM prompts (document + slide selection).
    trace_llm_prompts: bool = os.environ.get("TRACE_LLM_PROMPTS", "").strip().lower() in (
        "1",
        "true",
        "yes",
        "on",
    )


class AppConfig:
    """Top-level app behavior toggles."""

    llm_provider: str = os.environ.get("LLM_PROVIDER", "ollama").strip().lower()
    active_type: str = os.environ.get("ACTIVE_TYPE", "underwriting").strip().lower()

    def normalized_provider(self) -> str:
        provider = self.llm_provider
        if provider in {"azure", "azure_openai", "azure-openai"}:
            return "azure"
        if provider == "ollama":
            return "ollama"
        if provider in {"openai", ""}:
            return "openai"
        raise EnvironmentError(
            "Invalid LLM_PROVIDER. Use 'ollama' (default), 'openai', or 'azure'."
        )

    def normalized_active_type(self) -> str:
        """Return a supported active domain type."""
        return get_feature(self.active_type).key

    def active_catalogue_paths(self) -> tuple[Path, ...]:
        """Resolve catalogue paths (directories of ``*.txt`` and/or JSON files) for the active domain."""
        feature = get_feature(self.normalized_active_type())
        if not feature.catalogue_paths:
            raise EnvironmentError(
                f"ACTIVE_TYPE '{feature.key}' does not use a local catalogue."
            )
        return feature.catalogue_paths


# Singletons – import these everywhere
azure_config = AzureOpenAIConfig()
openai_config = OpenAIConfig()
ollama_config = OllamaConfig()
retriever_config = RetrieverConfig()
app_config = AppConfig()
