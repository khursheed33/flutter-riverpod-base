"""Centralized, environment-driven configuration."""
from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

# Load .env from the project root.
_env_path = Path(__file__).resolve().parents[2] / ".env"
load_dotenv(dotenv_path=_env_path, override=False)


class AzureOpenAIConfig:
    """Azure OpenAI connection settings."""

    api_key: str = os.environ.get("AZURE_OPENAI_API_KEY", "")
    endpoint: str = os.environ.get("AZURE_OPENAI_ENDPOINT", "")
    api_version: str = os.environ.get("AZURE_OPENAI_API_VERSION", "2024-02-01")
    deployment_name: str = os.environ.get("AZURE_OPENAI_DEPLOYMENT_NAME", "gpt-4o")
    embedding_deployment_name: str = os.environ.get(
        "AZURE_OPENAI_EMBEDDING_DEPLOYMENT", ""
    )

    def validate(self) -> None:
        missing = [
            name
            for name, val in {
                "AZURE_OPENAI_API_KEY": self.api_key,
                "AZURE_OPENAI_ENDPOINT": self.endpoint,
                "AZURE_OPENAI_DEPLOYMENT_NAME": self.deployment_name,
            }.items()
            if not val
        ]
        if missing:
            raise EnvironmentError(
                f"Missing required environment variables: {', '.join(missing)}. "
                "Copy .env.example → .env and fill in your values."
            )


class OpenAIConfig:
    """OpenAI connection settings."""

    api_key: str = os.environ.get("OPENAI_API_KEY", "")
    model_name: str = os.environ.get("OPENAI_MODEL_NAME", "gpt-4o-mini")
    embedding_model_name: str = os.environ.get(
        "OPENAI_EMBEDDING_MODEL_NAME", "text-embedding-3-small"
    )

    def validate(self) -> None:
        if not self.api_key:
            raise EnvironmentError(
                "Missing required environment variable: OPENAI_API_KEY. "
                "Copy .env.example → .env and fill in your values."
            )


class RetrieverConfig:
    """Retrieval behaviour settings."""

    temperature: float = float(os.environ.get("LLM_TEMPERATURE", "0.0"))
    max_tokens: int = int(os.environ.get("LLM_MAX_TOKENS", "1024"))
    top_k: int = int(os.environ.get("TOP_K", "1"))
    return_reasoning: bool = os.environ.get("RETURN_REASONING", "true").lower() == "true"


class AppConfig:
    """Top-level app behavior toggles."""

    llm_provider: str = os.environ.get("LLM_PROVIDER", "openai").strip().lower()
    active_type: str = os.environ.get("ACTIVE_TYPE", "underwriting").strip().lower()

    def normalized_provider(self) -> str:
        provider = self.llm_provider
        if provider in {"azure", "azure_openai", "azure-openai"}:
            return "azure"
        if provider in {"openai", ""}:
            return "openai"
        raise EnvironmentError(
            "Invalid LLM_PROVIDER. Use 'openai' (default) or 'azure'."
        )

    def normalized_active_type(self) -> str:
        """Return a supported active domain type."""
        active_type = self.active_type
        if active_type in {"underwriting", "digital"}:
            return active_type
        raise EnvironmentError(
            "Invalid ACTIVE_TYPE. Use 'underwriting' or 'digital'."
        )

    def active_catalogue_path(self) -> Path:
        """Resolve catalogue JSON path for the active domain."""
        return Path("catelogue") / f"{self.normalized_active_type()}.json"


# Singletons – import these everywhere
azure_config = AzureOpenAIConfig()
openai_config = OpenAIConfig()
retriever_config = RetrieverConfig()
app_config = AppConfig()
