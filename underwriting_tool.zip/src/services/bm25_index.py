"""Persistent BM25 index for document and slide retrieval."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple

from rank_bm25 import BM25Okapi

from src.services.document_store import Document, DocumentStore

_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_CACHE_DIR = _PROJECT_ROOT / ".cache" / "bm25"
_TOKEN_RE = re.compile(r"[a-z0-9]+")
_INDEX_SCHEMA_VERSION = "2"


def _token_variants(token: str) -> List[str]:
    """Return light lexical variants to improve BM25 recall."""
    variants: list[str] = [token]
    if token.endswith("ies") and len(token) > 4:
        variants.append(token[:-3] + "y")
    if token.endswith("es") and len(token) > 4:
        variants.append(token[:-2])
    if token.endswith("s") and len(token) > 3:
        variants.append(token[:-1])
    if token.endswith("ing") and len(token) > 5:
        variants.append(token[:-3])
    if token.endswith("ed") and len(token) > 4:
        variants.append(token[:-2])
    return variants


def _tokenize(text: str) -> List[str]:
    """Tokenize text for BM25 with simple normalized alphanumeric terms."""
    out: list[str] = []
    seen: set[str] = set()
    for raw in _TOKEN_RE.findall((text or "").lower()):
        if len(raw) <= 1:
            continue
        for variant in _token_variants(raw):
            if len(variant) <= 1 or variant in seen:
                continue
            seen.add(variant)
            out.append(variant)
    return out


class BM25CatalogueIndex:
    """Build/load a persistent BM25 index over catalogue documents and slides."""

    def __init__(self, *, store: DocumentStore, active_type: str) -> None:
        self._store = store
        self._active_type = active_type
        self._cache_path = _CACHE_DIR / f"{active_type}_bm25_index.json"
        self._fingerprint = self._compute_fingerprint()
        self._doc_ids: List[str] = []
        self._doc_tokenized_corpus: List[List[str]] = []
        self._slide_tokenized_by_doc_id: Dict[str, List[List[str]]] = {}
        self._slide_payload_by_doc_id: Dict[str, List[Dict[str, Any]]] = {}
        self._doc_bm25: BM25Okapi | None = None
        self._slide_bm25_by_doc_id: Dict[str, BM25Okapi] = {}

    @property
    def cache_path(self) -> Path:
        """Return on-disk cache file path for this index."""
        return self._cache_path

    def ensure_ready(self) -> None:
        """Load an existing index or create one if missing/stale."""
        if self._cache_path.exists() and self._load_from_disk():
            return
        self._build_from_store()
        self._persist_to_disk()

    def shortlist_documents(self, query: str, top_k: int) -> List[Tuple[str, float]]:
        """Return ranked document ids with BM25 scores."""
        if not self._doc_bm25 or not self._doc_ids or top_k <= 0:
            return []
        q_tokens = _tokenize(query)
        if not q_tokens:
            return []
        scores = self._doc_bm25.get_scores(q_tokens)
        scored = sorted(
            [(self._doc_ids[i], float(scores[i])) for i in range(len(self._doc_ids))],
            key=lambda item: item[1],
            reverse=True,
        )
        return scored[: min(top_k, len(scored))]

    def shortlist_slides(
        self, *, doc: Document, query: str, top_k: int
    ) -> List[Dict[str, Any]]:
        """Return ranked slide payloads for a given document."""
        doc_id = doc.id
        bm25 = self._slide_bm25_by_doc_id.get(doc_id)
        payload = self._slide_payload_by_doc_id.get(doc_id, [])
        if not bm25 or not payload or top_k <= 0:
            return payload[:top_k]
        q_tokens = _tokenize(query)
        if not q_tokens:
            return payload[:top_k]
        scores = bm25.get_scores(q_tokens)
        order = sorted(
            range(len(payload)),
            key=lambda idx: float(scores[idx]),
            reverse=True,
        )
        return [payload[idx] for idx in order[: min(top_k, len(order))]]

    def _compute_fingerprint(self) -> str:
        joined: List[str] = [self._active_type, _INDEX_SCHEMA_VERSION]
        for doc in self._store.all():
            joined.extend(
                [
                    doc.id,
                    doc.title,
                    doc.summary,
                    doc.doc_type,
                    "|".join(doc.tags),
                    doc.catalogue_domain,
                    doc.underwriting_channel,
                ]
            )
            for slide in doc.slides:
                joined.extend([str(slide.number), slide.title, slide.summary])
        payload = "\n".join(joined)
        return hashlib.sha256(payload.encode("utf-8")).hexdigest()

    def _build_from_store(self) -> None:
        docs = self._store.all()
        self._doc_ids = [doc.id for doc in docs]
        self._doc_tokenized_corpus = [_tokenize(doc.embedding_source_text()) for doc in docs]
        self._doc_bm25 = BM25Okapi(self._doc_tokenized_corpus) if self._doc_tokenized_corpus else None
        self._slide_tokenized_by_doc_id = {}
        self._slide_payload_by_doc_id = {}
        self._slide_bm25_by_doc_id = {}
        for doc in docs:
            payload = [
                {
                    "number": slide.number,
                    "title": slide.title,
                    "summary": slide.summary,
                }
                for slide in doc.slides
            ]
            tokens = [
                _tokenize(f"Slide {slide.number} {slide.title} {slide.summary}")
                for slide in doc.slides
            ]
            self._slide_payload_by_doc_id[doc.id] = payload
            self._slide_tokenized_by_doc_id[doc.id] = tokens
            if tokens:
                self._slide_bm25_by_doc_id[doc.id] = BM25Okapi(tokens)

    def _persist_to_disk(self) -> None:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        data = {
            "fingerprint": self._fingerprint,
            "doc_ids": self._doc_ids,
            "doc_tokenized_corpus": self._doc_tokenized_corpus,
            "slide_tokenized_by_doc_id": self._slide_tokenized_by_doc_id,
            "slide_payload_by_doc_id": self._slide_payload_by_doc_id,
        }
        self._cache_path.write_text(json.dumps(data, ensure_ascii=True), encoding="utf-8")

    def _load_from_disk(self) -> bool:
        try:
            raw = json.loads(self._cache_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            return False
        if raw.get("fingerprint") != self._fingerprint:
            return False
        self._doc_ids = list(raw.get("doc_ids", []))
        self._doc_tokenized_corpus = list(raw.get("doc_tokenized_corpus", []))
        self._slide_tokenized_by_doc_id = dict(raw.get("slide_tokenized_by_doc_id", {}))
        self._slide_payload_by_doc_id = dict(raw.get("slide_payload_by_doc_id", {}))
        self._doc_bm25 = BM25Okapi(self._doc_tokenized_corpus) if self._doc_tokenized_corpus else None
        self._slide_bm25_by_doc_id = {}
        for doc_id, tokenized in self._slide_tokenized_by_doc_id.items():
            if tokenized:
                self._slide_bm25_by_doc_id[doc_id] = BM25Okapi(tokenized)
        return True


def ensure_bm25_index(
    *,
    store: DocumentStore,
    active_type: str,
    force_rebuild: bool = False,
) -> BM25CatalogueIndex:
    """Create/load BM25 index at startup and return ready index instance."""
    index = BM25CatalogueIndex(store=store, active_type=active_type)
    if force_rebuild and index.cache_path.exists():
        try:
            index.cache_path.unlink()
        except OSError:
            pass
    index.ensure_ready()
    return index
