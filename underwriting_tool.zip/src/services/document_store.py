"""
document_store.py – Document registry.

Each document has:
  - id          : unique slug used internally
  - title       : human-readable name shown in results
  - url         : cloud URL (PDF, PPTX, …)
  - doc_type    : "pdf" | "pptx" | …  (informational)
  - summary     : plain-English description used by the LLM to decide relevance
  - slides      : optional per-slide outline for decks (number, title, short summary)
  - tags        : optional list of keywords for display / filtering

────────────────────────────────────────────────────────────────────────────────
HOW TO ADD YOUR OWN DOCUMENTS
────────────────────────────────────────────────────────────────────────────────
Option A – edit the DOCUMENTS list below.
Option B – call DocumentStore.from_list() / DocumentStore.from_json_file()
           at runtime to load documents dynamically.
"""
from __future__ import annotations

import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, List, Optional

from src.config.settings import app_config


@dataclass
class SlideInfo:
    """Optional per-slide synopsis for presentation catalog entries."""

    number: int
    title: str
    summary: str = ""


@dataclass
class Document:
    id: str
    title: str
    url: str
    summary: str
    doc_type: str = "pdf"          # "pdf" | "pptx" | "docx" | …
    slides: List[SlideInfo] = field(default_factory=list)
    tags: List[str] = field(default_factory=list)

    def formatted_entry(self, index: int) -> str:
        """Return a numbered, LLM-readable description of this document."""
        tag_str = f"  Tags: {', '.join(self.tags)}" if self.tags else ""
        slide_block = ""
        if self.slides:
            lines = [
                "  Slides (1-based slide index; cite these when the answer is on "
                "specific slides):"
            ]
            for s in self.slides:
                sm = f" — {s.summary}" if s.summary else ""
                lines.append(f"    Slide {s.number}: {s.title}{sm}")
            slide_block = "\n" + "\n".join(lines)
        return (
            f"[{index}] ID: {self.id}\n"
            f"  Title: {self.title}\n"
            f"  Type: {self.doc_type.upper()}\n"
            f"  Summary: {self.summary}"
            + slide_block
            + (f"\n{tag_str}" if tag_str else "")
        )

    def embedding_source_text(self) -> str:
        """Dense text used for embedding similarity (title, summary, slides, tags)."""
        lines = [
            f"Title: {self.title}",
            f"Type: {self.doc_type}",
            f"Summary: {self.summary}",
        ]
        for slide in self.slides:
            extra = f" ({slide.summary})" if slide.summary else ""
            lines.append(f"Slide {slide.number}: {slide.title}{extra}")
        if self.tags:
            lines.append("Tags: " + ", ".join(self.tags))
        return "\n".join(lines)


def _slide_infos_from_raw(raw: Optional[List[Any]]) -> List[SlideInfo]:
    if not raw:
        return []
    out: List[SlideInfo] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        try:
            num = int(item["number"])
        except (KeyError, TypeError, ValueError):
            continue
        title = str(item.get("title", "")).strip()
        summary = str(item.get("summary", "")).strip()
        out.append(SlideInfo(number=num, title=title, summary=summary))
    return out


def document_from_dict(data: dict) -> Document:
    """Build a Document from a plain dict (e.g. JSON row), including optional slides."""
    row = dict(data)
    slides_raw = row.pop("slides", None)
    return Document(**row, slides=_slide_infos_from_raw(slides_raw))


# ─── Default document catalogue ───────────────────────────────────────────────
# Replace / extend these with your real documents.
DOCUMENTS: List[Document] = [
    Document(
        id="q3_sales_report",
        title="Q3 2024 Sales Performance Report",
        url="https://cloud.example.com/docs/q3_sales_report.pdf",
        doc_type="pdf",
        summary=(
            "Quarterly sales analysis covering revenue breakdown by region, "
            "top-performing SKUs, year-over-year growth (18 %), pipeline forecast "
            "for Q4, and recommended upsell strategies for enterprise accounts."
        ),
        tags=["sales", "revenue", "Q3", "forecast"],
    ),
    Document(
        id="onboarding_deck",
        title="Employee Onboarding Presentation",
        url="https://cloud.example.com/docs/onboarding_deck.pptx",
        doc_type="pptx",
        summary=(
            "Step-by-step onboarding guide for new hires: company culture, IT setup "
            "checklist, HR policies, benefits overview, first-week schedule, and "
            "introductions to key teams."
        ),
        slides=[
            SlideInfo(1, "Welcome", "Purpose of the deck and first-day expectations."),
            SlideInfo(2, "Culture & values", "Mission, values, and how teams collaborate."),
            SlideInfo(3, "IT setup checklist", "Laptop, accounts, VPN, MFA, and core tools."),
            SlideInfo(4, "HR policies", "Code of conduct, PTO, and reporting structure."),
            SlideInfo(5, "Benefits overview", "Health, retirement, stipends, and enrollment deadlines."),
            SlideInfo(6, "First-week schedule", "Meetings, trainings, and key contacts."),
        ],
        tags=["HR", "onboarding", "new hire"],
    ),
    Document(
        id="product_roadmap_2025",
        title="Product Roadmap 2025",
        url="https://cloud.example.com/docs/product_roadmap_2025.pptx",
        doc_type="pptx",
        summary=(
            "Strategic product vision for 2025: planned feature releases by quarter, "
            "technology investments (AI/ML integrations), deprecation schedule for "
            "legacy APIs, and success KPIs for each milestone."
        ),
        slides=[
            SlideInfo(1, "Executive summary", "Themes and headline goals for 2025."),
            SlideInfo(2, "Q1–Q2 releases", "Shipping priorities and major feature bets."),
            SlideInfo(3, "AI / ML investments", "Model serving, eval harness, and safety."),
            SlideInfo(4, "Legacy API deprecation", "Timelines, migration paths, and support."),
            SlideInfo(5, "KPIs & success metrics", "North-star metrics by milestone."),
        ],
        tags=["product", "roadmap", "engineering", "strategy"],
    ),
    Document(
        id="security_policy",
        title="Information Security Policy v3.1",
        url="https://cloud.example.com/docs/security_policy_v3.1.pdf",
        doc_type="pdf",
        summary=(
            "Corporate information-security policy covering data classification, "
            "access-control requirements, incident-response procedures, acceptable-use "
            "guidelines, audit schedule, and compliance obligations (ISO 27001, SOC 2)."
        ),
        tags=["security", "compliance", "policy", "ISO 27001"],
    ),
    Document(
        id="ml_architecture_overview",
        title="ML Platform Architecture Overview",
        url="https://cloud.example.com/docs/ml_architecture.pdf",
        doc_type="pdf",
        summary=(
            "Technical deep-dive into the company's machine-learning platform: "
            "data-ingestion pipelines, feature store design, model training and "
            "serving infrastructure, experiment-tracking setup, and MLOps best practices."
        ),
        tags=["machine learning", "MLOps", "infrastructure", "engineering"],
    ),
]


class DocumentStore:
    """In-memory document registry with helpers for the retriever."""

    def __init__(self, documents: Optional[List[Document]] = None) -> None:
        self._docs: List[Document] = documents or list(DOCUMENTS)

    # ── factories ──────────────────────────────────────────────────────────────

    @classmethod
    def from_list(cls, raw: List[dict]) -> "DocumentStore":
        """Create a store from a list of plain dicts (e.g. loaded from an API)."""
        docs = [document_from_dict(item) for item in raw]
        return cls(docs)

    @classmethod
    def from_json_file(cls, path: str | Path) -> "DocumentStore":
        """Load documents from a JSON file (array of document objects)."""
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_list(data)

    @classmethod
    def from_default_json_or_builtin(
        cls,
        default_json_path: str | Path | None = None,
    ) -> "DocumentStore":
        """
        Prefer a project JSON catalogue if present; otherwise use built-in sample docs.
        """
        path = (
            Path(default_json_path)
            if default_json_path is not None
            else app_config.active_catalogue_path()
        )
        if path.exists():
            return cls.from_json_file(path)
        return cls()

    # ── accessors ──────────────────────────────────────────────────────────────

    def all(self) -> List[Document]:
        return list(self._docs)

    def get_by_id(self, doc_id: str) -> Optional[Document]:
        return next((d for d in self._docs if d.id == doc_id), None)

    def add(self, doc: Document) -> None:
        self._docs.append(doc)

    def catalogue_text(self) -> str:
        """Return the full catalogue as numbered text for the LLM prompt."""
        return "\n\n".join(doc.formatted_entry(i + 1) for i, doc in enumerate(self._docs))

    def ids(self) -> List[str]:
        return [d.id for d in self._docs]
