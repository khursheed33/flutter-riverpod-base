"""
document_store.py – Document registry.

Each document has:
  - id          : unique slug used internally
  - title       : human-readable name shown in results
  - url         : cloud URL (PDF, PPTX, …)
  - doc_type    : "pdf" | "pptx" | …  (informational)
  - summary     : plain-English description used by the LLM to decide relevance
  - slides      : optional per-slide outline for decks (number, title, short summary)
  - tags        : optional list of keywords for display / filtering

────────────────────────────────────────────────────────────────────────────────
HOW TO ADD YOUR OWN DOCUMENTS
────────────────────────────────────────────────────────────────────────────────
Option A – edit the DOCUMENTS list below.
Option B – call DocumentStore.from_list(), from_json_file(), or
           DocumentStore.from_default_catalogue_or_builtin() to load documents at runtime
           (including recursive ``*.txt`` under configured catalogue directories).
"""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, List, Optional

from src.config.settings import app_config

_PROJECT_ROOT = Path(__file__).resolve().parents[2]
_SUMMARY_MAX = 480


def _resolve_under_project(path: str | Path) -> Path:
    """Resolve catalogue paths relative to the project root when not absolute."""
    p = Path(path)
    if p.is_absolute():
        return p.resolve()
    return (_PROJECT_ROOT / p).resolve()


def _tags_from_relative_path(rel: Path) -> List[str]:
    """Derive coarse tags from folder names under the catalogue root."""
    parts = [part.lower() for part in rel.parts[:-1] if part and part not in {".", ".."}]
    out: List[str] = []
    for part in parts:
        cleaned = re.sub(r"[^a-z0-9]+", " ", part).strip()
        if cleaned and cleaned not in out:
            out.append(cleaned)
    return out[:12]


def _catalogue_domain_from_rel(rel: Path) -> str:
    """Return ``digital`` or ``underwriting`` when path is under that catalogue tree."""
    parts_lower = [p.lower() for p in rel.parts]
    try:
        idx = parts_lower.index("catelogue")
    except ValueError:
        return ""
    if idx + 1 >= len(parts_lower):
        return ""
    nxt = parts_lower[idx + 1]
    if nxt == "digital":
        return "digital"
    if nxt == "underwriting":
        return "underwriting"
    return ""


def _underwriting_channel_from_rel(rel: Path) -> str:
    """
    Infer Axis / Agency / DSF from folder names under the underwriting catalogue.

    Matches whole path segments (e.g. ``Axis``, ``agency_ca``, ``DSF``).
    """
    if _catalogue_domain_from_rel(rel) != "underwriting":
        return ""
    for part in rel.parts:
        tokens = re.sub(r"[^a-z0-9]+", " ", part.lower()).split()
        if "agency" in tokens:
            return "Agency"
        if "dsf" in tokens:
            return "DSF"
        if "axis" in tokens:
            return "Axis"
    return ""


def _compact_summary_from_txt_body(body: str) -> str:
    """Build a short catalogue summary from raw .txt file contents."""
    text = _clean_txt_body(body)
    if not text:
        return "[Empty text file.]"
    if len(text) <= _SUMMARY_MAX:
        return text.replace("\n", " ")
    return text[:_SUMMARY_MAX].replace("\n", " ") + "…"


def _clean_txt_body(raw_text: str) -> str:
    """Return user-facing text after removing splitter metadata headers."""
    lines = [line.rstrip() for line in raw_text.splitlines()]
    out: list[str] = []
    for line in lines:
        stripped = line.strip()
        if (
            stripped.startswith("Deck:")
            or stripped.startswith("Slide:")
            or stripped.startswith("Title Hint:")
        ):
            continue
        out.append(line)
    cleaned = "\n".join(out).strip()
    return cleaned or raw_text.strip()


def _document_from_txt_path(abs_path: Path) -> Document:
    """Map one catalogue .txt file to a single-slide Document."""
    abs_resolved = abs_path.resolve()
    try:
        rel = abs_resolved.relative_to(_PROJECT_ROOT)
    except ValueError as exc:
        raise ValueError(
            f"Catalogue text file must live under project root {_PROJECT_ROOT}: {abs_resolved}"
        ) from exc
    rel_path = Path(rel)
    rel_posix = rel_path.as_posix()
    doc_id = rel_posix.replace("/", "__")
    raw = abs_resolved.read_text(encoding="utf-8", errors="replace")
    body = raw.strip()
    answer_body = _clean_txt_body(body)
    title = abs_path.stem.replace("__", " / ")[:200]
    summary = _compact_summary_from_txt_body(body)
    slide_title = title
    if "\n" in body:
        first = body.splitlines()[0].strip()
        if len(first) <= 120:
            slide_title = first
    slides = [SlideInfo(1, slide_title or title, answer_body)]
    catalogue_domain = _catalogue_domain_from_rel(rel_path)
    underwriting_channel = (
        _underwriting_channel_from_rel(rel_path) if catalogue_domain == "underwriting" else ""
    )
    tags = _tags_from_relative_path(rel_path)
    if catalogue_domain:
        tag_key = f"catalogue:{catalogue_domain}"
        if tag_key not in tags:
            tags = [tag_key] + tags
    if underwriting_channel:
        ch_tag = f"channel:{underwriting_channel.lower()}"
        if ch_tag not in tags:
            tags = [ch_tag] + tags
    return Document(
        id=doc_id,
        title=title,
        url=f"/{rel_posix}",
        summary=summary,
        doc_type="txt",
        slides=slides,
        tags=tags,
        catalogue_domain=catalogue_domain,
        underwriting_channel=underwriting_channel,
    )


def _iter_txt_files(root: Path) -> List[Path]:
    """Return sorted .txt paths under root (recursive)."""
    if not root.is_dir():
        return []
    return sorted(p for p in root.rglob("*.txt") if p.is_file())


def documents_from_txt_catalogue_roots(roots: List[Path]) -> List[Document]:
    """Load all .txt documents from one or more catalogue directory roots."""
    docs: List[Document] = []
    seen: set[str] = set()
    for root in roots:
        resolved = _resolve_under_project(root)
        for path in _iter_txt_files(resolved):
            doc = _document_from_txt_path(path)
            if doc.id in seen:
                continue
            seen.add(doc.id)
            docs.append(doc)
    return docs


@dataclass
class SlideInfo:
    """Optional per-slide synopsis for presentation catalog entries."""

    number: int
    title: str
    summary: str = ""


@dataclass
class Document:
    id: str
    title: str
    url: str
    summary: str
    doc_type: str = "pdf"          # "pdf" | "pptx" | "docx" | …
    slides: List[SlideInfo] = field(default_factory=list)
    # Backward-compatible field: some catalogue loaders may still pass `sections`.
    # We normalize sections into slides in `document_from_dict`, but keeping this
    # field avoids runtime TypeError in long-lived processes with mixed code paths.
    sections: List[Any] = field(default_factory=list, repr=False)
    tags: List[str] = field(default_factory=list)
    catalogue_domain: str = ""  # "digital" | "underwriting" | "" for non-catalogue sources
    underwriting_channel: str = ""  # "Axis" | "Agency" | "DSF" | ""

    def formatted_entry(self, index: int) -> str:
        """Return a numbered, LLM-readable description of this document."""
        tag_str = f"  Tags: {', '.join(self.tags)}" if self.tags else ""
        domain_line = (
            f"\n  Catalogue type: {self.catalogue_domain.title()}"
            if self.catalogue_domain
            else ""
        )
        channel_line = (
            f"\n  Underwriting channel: {self.underwriting_channel}"
            if self.underwriting_channel
            else ""
        )
        slide_block = ""
        if self.slides:
            lines = [
                "  Slides (1-based slide index; cite these when the answer is on "
                "specific slides):"
            ]
            for s in self.slides:
                sm = f" — {s.summary}" if s.summary else ""
                lines.append(f"    Slide {s.number}: {s.title}{sm}")
            slide_block = "\n" + "\n".join(lines)
        return (
            f"[{index}] ID: {self.id}\n"
            f"  Title: {self.title}\n"
            f"  Type: {self.doc_type.upper()}\n"
            f"  Summary: {self.summary}"
            + domain_line
            + channel_line
            + slide_block
            + (f"\n{tag_str}" if tag_str else "")
        )

    def embedding_source_text(self) -> str:
        """Dense text used for embedding similarity (title, summary, slides, tags)."""
        lines = [
            f"Title: {self.title}",
            f"Type: {self.doc_type}",
            f"Summary: {self.summary}",
        ]
        for slide in self.slides:
            extra = f" ({slide.summary})" if slide.summary else ""
            lines.append(f"Slide {slide.number}: {slide.title}{extra}")
        if self.tags:
            lines.append("Tags: " + ", ".join(self.tags))
        if self.catalogue_domain:
            lines.append(f"Catalogue type: {self.catalogue_domain}")
        if self.underwriting_channel:
            lines.append(f"Underwriting channel: {self.underwriting_channel}")
        return "\n".join(lines)


def _slide_infos_from_raw(raw: Optional[List[Any]]) -> List[SlideInfo]:
    if not raw:
        return []
    out: List[SlideInfo] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        try:
            num = int(item["number"])
        except (KeyError, TypeError, ValueError):
            continue
        title = str(item.get("title", "")).strip()
        summary = str(item.get("summary", "")).strip()
        out.append(SlideInfo(number=num, title=title, summary=summary))
    return out


def _section_infos_from_raw(raw: Optional[List[Any]]) -> List[SlideInfo]:
    """
    Parse plain-text section metadata and map it to internal slide-like units.

    This keeps retrieval logic shared: underwriting can use `slides`, while other
    catalogues can provide `sections` without changing retriever internals.
    """
    if not raw:
        return []
    out: List[SlideInfo] = []
    for idx, item in enumerate(raw, start=1):
        if not isinstance(item, dict):
            continue
        try:
            num = int(item.get("number", idx))
        except (TypeError, ValueError):
            num = idx
        title = str(item.get("title", "")).strip()
        summary = str(item.get("summary", "")).strip()
        if not title and not summary:
            continue
        out.append(SlideInfo(number=num, title=title or f"Section {num}", summary=summary))
    return out


def document_from_dict(data: dict) -> Document:
    """Build a Document from a plain dict, supporting `slides` or plain `sections`."""
    row = dict(data or {})
    slides_raw = row.pop("slides", None)
    sections_raw = row.pop("sections", None)
    slides = _slide_infos_from_raw(slides_raw)
    if not slides:
        slides = _section_infos_from_raw(sections_raw)

    tags_raw = row.get("tags", [])
    tags = tags_raw if isinstance(tags_raw, list) else []
    tags = [str(t).strip() for t in tags if str(t).strip()]
    catalogue_domain = str(row.get("catalogue_domain", "")).strip().lower()
    if catalogue_domain not in {"", "digital", "underwriting"}:
        catalogue_domain = ""
    raw_ch = str(row.get("underwriting_channel", "")).strip()
    _ch_map = {"axis": "Axis", "agency": "Agency", "dsf": "DSF"}
    underwriting_channel = _ch_map.get(raw_ch.lower(), raw_ch)

    # Construct explicitly so unknown keys can never leak into Document(...)
    return Document(
        id=str(row.get("id", "")).strip(),
        title=str(row.get("title", "")).strip(),
        url=str(row.get("url", "")).strip(),
        summary=str(row.get("summary", "")).strip(),
        doc_type=str(row.get("doc_type", "pdf")).strip() or "pdf",
        slides=slides,
        tags=tags,
        catalogue_domain=catalogue_domain,
        underwriting_channel=underwriting_channel,
    )


# ─── Default document catalogue ───────────────────────────────────────────────
# Replace / extend these with your real documents.
DOCUMENTS: List[Document] = [
]


class DocumentStore:
    """In-memory document registry with helpers for the retriever."""

    def __init__(self, documents: Optional[List[Document]] = None) -> None:
        if documents is None:
            self._docs = list(DOCUMENTS)
        else:
            self._docs = list(documents)

    # ── factories ──────────────────────────────────────────────────────────────

    @classmethod
    def from_list(cls, raw: List[dict]) -> "DocumentStore":
        """Create a store from a list of plain dicts (e.g. loaded from an API)."""
        docs = [document_from_dict(item) for item in raw]
        return cls(docs)

    @classmethod
    def from_json_file(cls, path: str | Path) -> "DocumentStore":
        """Load documents from a JSON file (array of document objects)."""
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_list(data)

    @classmethod
    def from_json_files(cls, paths: List[str | Path]) -> "DocumentStore":
        """Load and merge documents from multiple JSON files."""
        merged: List[dict] = []
        for raw_path in paths:
            data = json.loads(Path(raw_path).read_text(encoding="utf-8"))
            if isinstance(data, list):
                merged.extend(data)
        return cls.from_list(merged)

    @classmethod
    def from_default_catalogue_or_builtin(
        cls,
        default_catalogue_paths: List[str | Path] | None = None,
    ) -> "DocumentStore":
        """
        Load catalogue documents from configured paths.

        Each path may be a directory (all ``*.txt`` files loaded recursively) or a
        JSON file (legacy array-of-documents format). When the caller passes explicit
        paths (normal for feature catalogues), a missing directory yields an empty
        store—not built-in samples. Built-in samples are used only when this method
        is invoked with ``default_catalogue_paths=None`` and nothing resolves on disk.
        """
        paths = (
            [Path(path) for path in default_catalogue_paths]
            if default_catalogue_paths is not None
            else [Path(path) for path in app_config.active_catalogue_paths()]
        )
        resolved = [_resolve_under_project(path) for path in paths]
        existing = [p for p in resolved if p.exists()]
        caller_supplied_paths = default_catalogue_paths is not None
        if not existing:
            # Feature code always passes explicit paths; do not substitute sample docs.
            return cls([]) if caller_supplied_paths else cls()

        txt_roots: List[Path] = []
        txt_files: List[Path] = []
        json_files: List[Path] = []
        for path in existing:
            if path.is_dir():
                txt_roots.append(path)
            elif path.is_file() and path.suffix.lower() == ".txt":
                txt_files.append(path)
            elif path.suffix.lower() == ".json":
                json_files.append(path)

        docs: List[Document] = []
        if txt_roots:
            docs.extend(documents_from_txt_catalogue_roots(txt_roots))
        for single in txt_files:
            docs.append(_document_from_txt_path(single))
        if json_files:
            docs.extend(cls.from_json_files(json_files).all())

        if docs:
            by_id: dict[str, Document] = {}
            for item in docs:
                by_id[item.id] = item
            return cls(list(by_id.values()))
        if txt_roots or txt_files or json_files:
            return cls([])
        return cls()

    # ── accessors ──────────────────────────────────────────────────────────────

    def all(self) -> List[Document]:
        return list(self._docs)

    def get_by_id(self, doc_id: str) -> Optional[Document]:
        return next((d for d in self._docs if d.id == doc_id), None)

    def add(self, doc: Document) -> None:
        self._docs.append(doc)

    def catalogue_text(self) -> str:
        """Return the full catalogue as numbered text for the LLM prompt."""
        return "\n\n".join(doc.formatted_entry(i + 1) for i, doc in enumerate(self._docs))

    def ids(self) -> List[str]:
        return [d.id for d in self._docs]
