"""Regenerate underwriting channel catalogues from output/."""
from __future__ import annotations

import json
import re
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "output"
OUT_DIR = Path(__file__).resolve().parent / "underwriting"


def _clean_body(raw: str) -> str:
    lines = [line.rstrip() for line in raw.splitlines()]
    out: list[str] = []
    for line in lines:
        s = line.strip()
        if s.startswith(("Deck:", "Slide:", "Title Hint:")):
            continue
        out.append(line)
    return "\n".join(out).strip()


def _snippet(text: str, limit: int = 400) -> str:
    t = re.sub(r"\s+", " ", text).strip()
    if len(t) <= limit:
        return t
    return t[: limit - 1] + "…"


def _slide_title_from_body(body: str, slide_num: int) -> str:
    for line in body.splitlines():
        ls = line.strip()
        if ls.upper().startswith("TITLE:"):
            return ls.split(":", 1)[-1].strip()[:200]
    in_content = False
    for line in body.splitlines():
        ls = line.strip()
        if ls == "CONTENT:":
            in_content = True
            continue
        if not in_content:
            continue
        if not ls:
            continue
        if re.fullmatch(r"\[[^\]]+\]", ls):
            continue
        if ls.startswith("[") and "]" in ls[:60]:
            continue
        return ls[:200]
    return f"Slide {slide_num}"


def _deck_groups() -> dict[tuple[str, str], list[tuple[int, Path]]]:
    groups: dict[tuple[str, str], list[tuple[int, Path]]] = defaultdict(list)
    for p in sorted(OUTPUT.rglob("*.txt")):
        if not p.is_file():
            continue
        rel_parent = p.parent.relative_to(OUTPUT).as_posix() if p.parent != OUTPUT else ""
        m = re.match(r"^(.*)_slide_(\d+)\.txt$", p.name, re.I)
        if not m:
            continue
        stem, num = m.group(1), int(m.group(2))
        groups[(rel_parent, stem)].append((num, p))
    for key in groups:
        groups[key].sort(key=lambda x: x[0])
    return groups


def _classify(rel_parent: str, stem: str) -> tuple[str, str, str | None]:
    lower = f"{rel_parent}/{stem}".lower()
    if "protection" in lower:
        return "underwriting", "protection", None
    if "savings" in lower or "saving" in lower:
        ch: str | None = None
        if "axis" in lower:
            ch = "Axis"
        elif "agency" in lower:
            ch = "Agency"
        elif "dsf" in lower:
            ch = "DSF"
        return "underwriting", "saving", ch
    return "underwriting", "saving", None


def _canonical_product(stem: str, uw_line: str, channel: str | None) -> str:
    if uw_line == "protection":
        return "Axis Max Life Protection UW (High SA, All Channels) — Feb 2026"
    stem_clean = re.sub(r"\s+", " ", stem).strip()
    if channel:
        return f"{stem_clean} — {channel} channel"
    return stem_clean


def _aliases(stem: str, uw_line: str, channel: str | None, rel_parent: str) -> list[str]:
    stem_clean = re.sub(r"\s+", " ", stem).strip()
    if uw_line == "protection":
        return list(
            dict.fromkeys(
                [
                    "Protection UW",
                    "High SA protection",
                    "Axis Max Life protection UW",
                    "Protection underwriting Feb 2026",
                    stem_clean,
                ]
            )
        )
    base = [stem, stem_clean]
    if channel:
        base += [
            f"{channel} savings UW",
            f"Savings {channel}",
            rel_parent or channel,
        ]
    return list(dict.fromkeys([b for b in base if b]))


def _deck_period(stem: str, uw_line: str) -> str:
    if uw_line == "protection":
        return "Feb 2026"
    m = re.search(
        r"(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+20\d{2}",
        stem,
        re.I,
    )
    if m:
        return m.group(0).strip()
    m2 = re.search(r"20\d{2}", stem)
    return m2.group(0) if m2 else ""


def _deck_theme_line(slides: list[dict]) -> str:
    hints = [s.get("slide_title_hint", "").strip() for s in slides if s.get("slide_title_hint")]
    if not hints:
        return ""
    uniq: list[str] = []
    for h in hints:
        if h in {"CONTENT:", "Slide"}:
            continue
        if h not in uniq:
            uniq.append(h)
    shown = uniq[:16]
    tail = f" (+{len(uniq) - len(shown)} more slide topics)" if len(uniq) > len(shown) else ""
    return "Slide topics (deduped order): " + "; ".join(shown) + tail


def build_slide_entries(paths: list[tuple[int, Path]]) -> list[dict]:
    slides: list[dict] = []
    for num, path in paths:
        raw = path.read_text(encoding="utf-8", errors="replace")
        body = _clean_body(raw)
        hint = _slide_title_from_body(body, num)
        rel = path.relative_to(ROOT).as_posix()
        slides.append(
            {
                "slide_number": num,
                "doc_name": rel.replace("/", "__"),
                "source_path": rel,
                "slide_title_hint": hint,
                "summary": _snippet(body, 400),
            }
        )
    return slides


def build_deck_product(rel_parent: str, stem: str, paths: list[tuple[int, Path]]) -> dict:
    domain, uw_line, ch = _classify(rel_parent, stem)
    slides = build_slide_entries(paths)
    rel_prefix = Path(rel_parent) / stem if rel_parent else Path(stem)
    deck_doc_name = f"{rel_prefix.as_posix()}.pptx"
    theme_line = _deck_theme_line(slides)
    master_summary = (
        f"Catalogue type: {domain}. "
        f"Underwriting line: {uw_line}. "
        + (f"Underwriting channel: {ch}. " if ch else "Underwriting channels: Axis, Agency, and DSF (UW all channels deck). ")
        + f"Deck has {len(slides)} slides; each slide is one .txt under output/ mirroring the source PPTX. "
        + theme_line
    )
    canonical = _canonical_product(stem, uw_line, ch)
    return {
        "canonical_name": canonical,
        "product": {
            "aliases": _aliases(stem, uw_line, ch, rel_parent),
            "catalogue_domain": domain,
            "underwriting_line": uw_line,
            "underwriting_channel": (ch or "Axis, Agency, DSF"),
            "deck_period": _deck_period(stem, uw_line),
            "documents": [
                {
                    "doc_name": deck_doc_name,
                    "summary": master_summary,
                    "slide_count": len(slides),
                    "slides": slides,
                }
            ],
        },
    }


def channel_filter(channel: str, rel_parent: str, uw_line: str) -> bool:
    c = channel.lower()
    parent_l = rel_parent.lower()
    if uw_line == "protection":
        return True
    if uw_line != "saving":
        return False
    if c == "axis":
        return "axis" in parent_l
    if c == "agency":
        return "agency" in parent_l
    if c == "dsf":
        return "dsf" in parent_l
    return False


def build_for_channel(channel: str) -> dict:
    groups = _deck_groups()
    products: dict[str, dict] = {}
    digital_products: dict[str, dict] = {}
    uw_saving: dict[str, dict] = {}
    uw_protection: dict[str, dict] = {}

    for (rel_parent, stem), path_list in sorted(groups.items()):
        built = build_deck_product(rel_parent, stem, path_list)
        name = built["canonical_name"]
        prod = built["product"]
        domain = prod["catalogue_domain"]
        uw_line = prod["underwriting_line"]

        if domain == "digital":
            digital_products[name] = prod
            continue

        if not channel_filter(channel, rel_parent, uw_line):
            continue

        products[name] = prod
        if uw_line == "saving":
            uw_saving[name] = prod
        elif uw_line == "protection":
            uw_protection[name] = prod

    return {
        "schema": "axis_max_life_catalogue_v1",
        "channel_filter": channel,
        "usage_notes": (
            "Keys under products are canonical catalogue names for routing (same shape as test.json: "
            "aliases + documents with doc_name and summary). Each documents[] entry may include slides[] "
            "listing every output .txt slide with source_path for verbatim retrieval. "
            "catalogue_domain is digital|underwriting; underwriting_line is saving|protection."
        ),
        "digital": {
            "catalogue_domain": "digital",
            "products": digital_products,
            "note": (
                "No digital journey transcript .txt files are present under output/ "
                "for this repository snapshot; this block is reserved for future digital segments."
            ),
        },
        "underwriting": {
            "catalogue_domain": "underwriting",
            "underwriting_channels_covered": ["Axis", "Agency", "DSF"],
            "lines": {
                "saving": {"underwriting_line": "saving", "products": uw_saving},
                "protection": {"underwriting_line": "protection", "products": uw_protection},
            },
            "products": products,
        },
        "products": products,
    }


def main() -> None:
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    for ch in ("axis", "agency", "dsf"):
        data = build_for_channel(ch)
        out_path = OUT_DIR / f"catalogue_{ch}.json"
        out_path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        print("wrote", out_path, "products", len(data["products"]))


if __name__ == "__main__":
    main()
