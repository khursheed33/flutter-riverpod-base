#!/usr/bin/env python3
"""
pptx_to_txt.py
--------------
Recursively scan a folder (and all sub-folders) for .pptx files.
For every slide in each presentation, write one .txt file named:
    <original_file_name>_slide_<number>.txt

The output folder mirrors the input folder structure so files from
different sub-folders never collide.

Usage:
    python pptx_to_txt.py <input_folder> [--output-dir <dir>]

Examples:
    python pptx_to_txt.py ./presentations
    python pptx_to_txt.py ./presentations --output-dir ./slides_output
"""

import argparse
import os
import sys
from pathlib import Path

try:
    from pptx import Presentation
except ImportError:
    print("ERROR: python-pptx is not installed.")
    print("Install it with:  pip install python-pptx")
    sys.exit(1)


# ──────────────────────────────────────────────
# Text extraction helpers
# ──────────────────────────────────────────────

def extract_text_from_shape(shape) -> list:
    """Return non-empty text lines from a single shape."""
    lines = []

    if shape.has_text_frame:
        for para in shape.text_frame.paragraphs:
            text = para.text.strip()
            if text:
                lines.append(text)

    # Table (shape_type 19 = TABLE)
    if shape.shape_type == 19:
        try:
            for row in shape.table.rows:
                row_text = " | ".join(
                    cell.text.strip() for cell in row.cells if cell.text.strip()
                )
                if row_text:
                    lines.append(row_text)
        except Exception:
            pass

    return lines


def extract_slide_content(slide, slide_number: int) -> str:
    """Build a readable text block for one slide."""
    parts = [f"SLIDE {slide_number}", "=" * 40]

    # Title
    title_text = ""
    if slide.shapes.title:
        title_text = slide.shapes.title.text.strip()
    if title_text:
        parts += [f"TITLE: {title_text}", ""]

    # All other shapes
    content_lines = []
    for shape in slide.shapes:
        if shape == slide.shapes.title:
            continue
        shape_lines = extract_text_from_shape(shape)
        if shape_lines:
            label = shape.name.strip() or f"Shape {shape.shape_id}"
            content_lines.append(f"[{label}]")
            content_lines.extend(shape_lines)
            content_lines.append("")

    if content_lines:
        parts.append("CONTENT:")
        parts.extend(content_lines)

    # Speaker notes
    if slide.has_notes_slide:
        notes_text = slide.notes_slide.notes_text_frame.text.strip()
        if notes_text:
            parts += ["SPEAKER NOTES:", notes_text, ""]

    return "\n".join(parts)


# ──────────────────────────────────────────────
# Per-file processing
# ──────────────────────────────────────────────

def process_pptx(pptx_path: Path, output_dir: Path, input_root: Path):
    """
    Parse one .pptx file and write one .txt per slide.

    Output path mirrors the input sub-folder structure:
        <output_dir>/<relative_sub_path>/<stem>_slide_<n>.txt

    Returns (slide_count, list_of_errors).
    """
    errors = []
    try:
        prs = Presentation(str(pptx_path))
    except Exception as exc:
        return 0, [f"Could not open {pptx_path}: {exc}"]

    # Preserve sub-folder hierarchy inside the output dir
    rel_folder = pptx_path.parent.relative_to(input_root)
    slide_output_dir = output_dir / rel_folder
    slide_output_dir.mkdir(parents=True, exist_ok=True)

    stem = pptx_path.stem
    total = len(prs.slides)

    for idx, slide in enumerate(prs.slides, start=1):
        try:
            content = extract_slide_content(slide, idx)
            out_file = slide_output_dir / f"{stem}_slide_{idx}.txt"
            out_file.write_text(content, encoding="utf-8")
        except Exception as exc:
            errors.append(f"Slide {idx} of {pptx_path.name}: {exc}")

    return total, errors


# ──────────────────────────────────────────────
# Folder scanner
# ──────────────────────────────────────────────

def scan_and_convert(input_folder: str, output_dir: str) -> None:
    input_root = Path(input_folder).resolve()

    if not input_root.exists():
        print(f"ERROR: Folder not found - {input_root}")
        sys.exit(1)
    if not input_root.is_dir():
        print(f"ERROR: Not a directory - {input_root}")
        sys.exit(1)

    out_root = Path(output_dir).resolve()
    out_root.mkdir(parents=True, exist_ok=True)

    # Recursively collect all .pptx files (case-insensitive on any OS)
    pptx_files = sorted(
        p for p in input_root.rglob("*")
        if p.suffix.lower() == ".pptx" and p.is_file()
    )

    if not pptx_files:
        print(f"No .pptx files found under: {input_root}")
        sys.exit(0)

    print(f"Input folder  : {input_root}")
    print(f"Output folder : {out_root}")
    print(f"Found {len(pptx_files)} .pptx file(s)\n")
    print("-" * 60)

    total_files = 0
    total_slides = 0
    all_errors = []

    for pptx_path in pptx_files:
        rel = pptx_path.relative_to(input_root)
        print(f"\n[FILE] {rel}")

        slide_count, errors = process_pptx(pptx_path, out_root, input_root)

        if errors:
            for e in errors:
                print(f"  [WARN] {e}")
            all_errors.extend(errors)
        else:
            print(f"  [OK] {slide_count} slide(s) exported")

        total_files += 1
        total_slides += slide_count

    # ── Summary ──────────────────────────────────────────────
    print("\n" + "=" * 60)
    print(f"Processed : {total_files} file(s)  |  {total_slides} slide(s) total")
    print(f"Output    : {out_root}")
    if all_errors:
        print(f"Errors    : {len(all_errors)} (see above)")
    print("=" * 60)


# ──────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description=(
            "Recursively convert every .pptx in a folder tree "
            "to per-slide .txt files."
        )
    )
    parser.add_argument(
        "input_folder",
        help="Root folder to scan (sub-folders are included automatically).",
    )
    parser.add_argument(
        "--output-dir", "-o",
        default=None,
        help=(
            "Where to write the .txt files. "
            "Sub-folder structure of the input is mirrored here. "
            "Defaults to '<input_folder>_slides_output'."
        ),
    )
    args = parser.parse_args()

    output_dir = args.output_dir or f"{args.input_folder.rstrip('/\\')}__slides_output"
    scan_and_convert(args.input_folder, output_dir)


if __name__ == "__main__":
    main()