"""Delete old log files from the project logs directory."""

from __future__ import annotations

import argparse
import sys
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_LOGS_DIR = PROJECT_ROOT / "logs"
DEFAULT_RETENTION_HOURS = 24


@dataclass(frozen=True)
class CleanupStats:
    """Track cleanup results for reporting."""

    scanned_files: int
    deleted_files: int
    kept_files: int
    bytes_freed: int


def _parse_args() -> argparse.Namespace:
    """Parse command-line arguments for log cleanup."""
    parser = argparse.ArgumentParser(
        description="Delete log files older than the configured retention period."
    )
    parser.add_argument(
        "--logs-dir",
        type=Path,
        default=DEFAULT_LOGS_DIR,
        help=f"Logs directory to scan (default: {DEFAULT_LOGS_DIR}).",
    )
    parser.add_argument(
        "--retention-hours",
        type=int,
        default=DEFAULT_RETENTION_HOURS,
        help=f"Delete files older than this many hours (default: {DEFAULT_RETENTION_HOURS}).",
    )
    parser.add_argument(
        "--glob",
        type=str,
        default="*.log",
        help="File pattern to match inside the logs directory (default: *.log).",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Show what would be deleted without deleting files.",
    )
    return parser.parse_args()


def _iter_candidate_files(logs_dir: Path, pattern: str) -> list[Path]:
    """Collect files under logs_dir matching pattern recursively."""
    if not logs_dir.exists() or not logs_dir.is_dir():
        return []
    return [path for path in logs_dir.rglob(pattern) if path.is_file()]


def cleanup_old_logs(
    logs_dir: Path,
    retention_hours: int,
    pattern: str = "*.log",
    dry_run: bool = False,
) -> CleanupStats:
    """Delete files older than retention_hours and return stats."""
    if retention_hours < 1:
        raise ValueError("retention_hours must be >= 1.")

    now = datetime.now(timezone.utc)
    cutoff = now - timedelta(hours=retention_hours)
    scanned = 0
    deleted = 0
    kept = 0
    bytes_freed = 0

    candidates = _iter_candidate_files(logs_dir, pattern)
    for file_path in candidates:
        scanned += 1
        modified = datetime.fromtimestamp(file_path.stat().st_mtime, tz=timezone.utc)
        if modified >= cutoff:
            kept += 1
            continue

        file_size = file_path.stat().st_size
        if dry_run:
            print(f"[DRY-RUN] delete: {file_path}")
            deleted += 1
            bytes_freed += file_size
            continue

        try:
            file_path.unlink()
            print(f"deleted: {file_path}")
            deleted += 1
            bytes_freed += file_size
        except OSError as exc:
            kept += 1
            print(f"skip (error): {file_path} ({exc})")

    return CleanupStats(
        scanned_files=scanned,
        deleted_files=deleted,
        kept_files=kept,
        bytes_freed=bytes_freed,
    )


def main() -> int:
    """Run cleanup using command-line arguments."""
    args = _parse_args()
    logs_dir = args.logs_dir.resolve()

    try:
        stats = cleanup_old_logs(
            logs_dir=logs_dir,
            retention_hours=int(args.retention_hours),
            pattern=str(args.glob),
            dry_run=bool(args.dry_run),
        )
    except ValueError as exc:
        print(f"invalid arguments: {exc}")
        return 2

    print(
        "cleanup complete | "
        f"scanned={stats.scanned_files} "
        f"deleted={stats.deleted_files} "
        f"kept={stats.kept_files} "
        f"bytes_freed={stats.bytes_freed}"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
