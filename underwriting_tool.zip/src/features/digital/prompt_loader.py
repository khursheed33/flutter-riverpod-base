"""Load digital feature LLM prompt from ``digital_prompt.d``."""

from __future__ import annotations

from pathlib import Path

_PROMPT_DIR = Path(__file__).resolve().parent / "digital_prompt.d"


def _read_prompt_file(name: str) -> str:
    path = _PROMPT_DIR / name
    if not path.is_file():
        raise FileNotFoundError(f"Missing digital prompt file: {path}")
    return path.read_text(encoding="utf-8")


def load_digital_rag_markdown_prompt() -> str:
    """Return the single-pass digital markdown prompt template."""
    return _read_prompt_file("digital_prompt.txt")
