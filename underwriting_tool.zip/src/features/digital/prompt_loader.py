"""Load digital feature LLM prompts (document + segment selection) from ``digital_prompt.d``."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from src.features.digital.config import DIGITAL_FEATURE

_PROMPT_DIR = Path(__file__).resolve().parent / "digital_prompt.d"


@dataclass(frozen=True)
class DigitalPromptBundle:
    """Prompts used only by ``digital.retriever``."""

    domain_context: str
    doc_selection_system_prompt: str
    slide_selection_system_prompt: str
    human_prompt: str


def _read_prompt_file(name: str) -> str:
    path = _PROMPT_DIR / name
    if not path.is_file():
        raise FileNotFoundError(f"Missing digital prompt file: {path}")
    return path.read_text(encoding="utf-8")


def load_digital_prompt_bundle() -> DigitalPromptBundle:
    """
    Return prompts for digital catalogue retrieval.

    Templates expose placeholders consumed by ``DigitalDocumentRetriever``:
    ``domain_context``, ``selected_channel``, ``abbreviation_guide``,
    ``catalogue_summary_json``, ``catalogue``, ``top_k``, ``query`` for document
    selection; plus ``doc_*`` and ``slides_catalogue``, ``top_slides`` for segment
    selection.
    """
    return DigitalPromptBundle(
        domain_context=DIGITAL_FEATURE.prompt_context,
        doc_selection_system_prompt=_read_prompt_file("doc_selection_system.txt"),
        slide_selection_system_prompt=_read_prompt_file("segment_selection_system.txt"),
        human_prompt=_read_prompt_file("human_turn.txt").strip(),
    )
