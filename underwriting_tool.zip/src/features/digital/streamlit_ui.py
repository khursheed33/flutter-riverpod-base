"""Digital-specific Streamlit UI helpers."""

from __future__ import annotations

CHAT_PLACEHOLDER = "Ask digital tools and journey questions..."
FEATURE_DESCRIPTION = (
    "Ask about digital tools and operational journeys with section-level references."
)

