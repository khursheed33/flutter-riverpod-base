"""JSON-backed digital catalogue helpers."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

_PROJECT_ROOT = Path(__file__).resolve().parents[3]
_DIGITAL_CATALOGUE_PATH = _PROJECT_ROOT / "catelogue" / "digital" / "catalogue_digital.json"

_PREVIEW_SECTION_CHARS = 320
_MAX_PREVIEW_DOCS = 10


def _read_json(path: Path) -> dict[str, Any]:
    """Safely read JSON file as dictionary."""
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}


def load_digital_catalogue_payload() -> dict[str, Any]:
    """Return digital catalogue payload."""
    data = _read_json(_DIGITAL_CATALOGUE_PATH)
    return data if data else {}


def load_digital_catalogue_json_text(*, max_chars: int = 120_000) -> str:
    """Return compact digital catalogue JSON text for prompt injection."""
    payload = load_digital_catalogue_payload()
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 80] + "\n...\n[truncated for prompt size]"


def iter_catalogue_documents(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Collect unique transcript-like document objects from catalogue payload."""
    results: list[dict[str, Any]] = []
    seen: set[str] = set()

    tools = payload.get("tools")
    if isinstance(tools, list):
        for tool in tools:
            if not isinstance(tool, dict):
                continue
            doc_name = str(tool.get("tool_name", "")).strip()
            source_path = str(tool.get("source_path", "")).strip()
            if not doc_name or not source_path:
                continue
            dedupe_key = f"{doc_name}::{source_path}"
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            results.append(
                {
                    "doc_name": doc_name,
                    "summary": str(tool.get("transcript_summary", "")).strip(),
                    "source_path": source_path.replace("\\", "/"),
                    "transcript_text": str(tool.get("transcript_text", "")).strip(),
                    "aliases": tool.get("aliases") if isinstance(tool.get("aliases"), list) else [],
                }
            )
        if results:
            return results

    # Backward compatibility for legacy documents/slides schema.
    def walk(node: Any) -> None:
        if isinstance(node, dict):
            documents = node.get("documents")
            if isinstance(documents, list):
                for doc in documents:
                    if not isinstance(doc, dict):
                        continue
                    doc_name = str(doc.get("doc_name", "")).strip()
                    dedupe_key = doc_name or str(id(doc))
                    if dedupe_key in seen:
                        continue
                    seen.add(dedupe_key)
                    source_path = ""
                    slides = doc.get("slides")
                    if isinstance(slides, list) and slides and isinstance(slides[0], dict):
                        source_path = str(slides[0].get("source_path", "")).strip()
                    results.append(
                        {
                            "doc_name": doc_name,
                            "summary": str(doc.get("summary", "")).strip(),
                            "source_path": source_path.replace("\\", "/"),
                            "transcript_text": "",
                            "aliases": [],
                        }
                    )
            for key, value in node.items():
                if key != "documents":
                    walk(value)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(payload)
    return results


def _query_terms(query: str) -> set[str]:
    """Tokenize query into lowercase terms (length >= 3)."""
    tokens = re.split(r"[^a-z0-9]+", query.lower().replace("-", " "))
    return {token for token in tokens if len(token) >= 3}


def rank_source_paths_for_query(*, query: str, payload: dict[str, Any], max_paths: int = 8) -> list[str]:
    """Rank and return digital source paths likely relevant to the query."""
    terms = _query_terms(query)
    scored_paths: list[tuple[float, str]] = []
    seen_paths: set[str] = set()

    for doc in iter_catalogue_documents(payload):
        doc_name = str(doc.get("doc_name", "")).strip()
        source_path = str(doc.get("source_path", "")).strip().replace("\\", "/")
        if not source_path or source_path in seen_paths:
            continue
        aliases = doc.get("aliases")
        alias_text = " ".join(str(item).strip() for item in aliases if isinstance(item, str)) if isinstance(aliases, list) else ""
        summary = str(doc.get("summary", "")).strip()
        transcript_text = str(doc.get("transcript_text", "")).strip()[:4000]
        hay = f"{doc_name} {alias_text} {summary} {transcript_text}".lower().replace("-", " ")
        score = float(sum(1 for term in terms if term in hay)) if terms else 0.0
        scored_paths.append((score, source_path))
        seen_paths.add(source_path)

    scored_paths.sort(key=lambda row: (-row[0], row[1]))
    if not scored_paths:
        return []
    if terms:
        positive = [path for score, path in scored_paths if score > 0]
        return positive[:max_paths] if positive else [path for _, path in scored_paths[:max_paths]]
    return [path for _, path in scored_paths[:max_paths]]


def _truncate(text: str, max_chars: int) -> str:
    value = text.strip()
    if len(value) <= max_chars:
        return value
    if max_chars <= 1:
        return "..."
    return value[: max_chars - 1].rstrip() + "..."


def build_catalogue_sources_preview_text(payload: dict[str, Any], *, max_chars: int = 12_000) -> str:
    """Build readable digital source preview text for UI context popover."""
    docs = iter_catalogue_documents(payload)
    if not docs:
        return ""
    lines: list[str] = [
        "Digital catalogue - source preview (indexed transcripts).",
        "",
    ]
    used = 0
    for doc in docs[:_MAX_PREVIEW_DOCS]:
        if used >= max_chars:
            break
        doc_name = str(doc.get("doc_name", "")).strip() or "(unnamed transcript)"
        doc_summary = _truncate(str(doc.get("summary", "")), _PREVIEW_SECTION_CHARS)
        source_path = str(doc.get("source_path", "")).strip()
        block = [f"Transcript: {doc_name}"]
        if doc_summary:
            block.append(f"  Summary: {doc_summary}")
        if source_path:
            block.append(f"  Path: {source_path}")
        chunk = "\n".join(block) + "\n"
        if used + len(chunk) > max_chars:
            lines.append("... [preview truncated]")
            break
        lines.append(chunk)
        used += len(chunk)
    return "\n".join(lines).strip()
