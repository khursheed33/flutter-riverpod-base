"""Digital feature package.

Import concrete modules directly, e.g. ``from src.features.digital.handler import run_query``,
to avoid import cycles with ``src.config.settings`` during registry load.
"""
