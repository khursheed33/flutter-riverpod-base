"""Digital feature package.

Import concrete modules directly, e.g. ``from src.features.digital.handler import run_query``
or ``from src.features.digital.retriever import DigitalDocumentRetriever``, to avoid
import cycles with ``src.config.settings`` during registry load.
"""
