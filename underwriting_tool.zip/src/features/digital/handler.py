"""Digital feature: catalogue JSON + query -> structured Markdown (single LLM pass)."""

from __future__ import annotations

import json
import logging
import re
from pathlib import Path
from typing import Any, Callable

from langchain_core.embeddings import Embeddings
from langchain_ollama import ChatOllama
from langchain_openai import AzureChatOpenAI, ChatOpenAI

from src.config.settings import AzureOpenAIConfig, OllamaConfig, OpenAIConfig, RetrieverConfig
from src.features.base import FeatureAnswer
from src.features.digital.channel_catalogue import (
    build_catalogue_sources_preview_text,
    load_digital_catalogue_json_text,
    load_digital_catalogue_payload,
    rank_source_paths_for_query,
)
from src.features.digital.config import DIGITAL_FEATURE
from src.features.digital.prompt_loader import load_digital_rag_markdown_prompt

logger = logging.getLogger(__name__)
DIGITAL_ABBREVIATION_GUIDE = "FYP = First Year Premium"
_DIGITAL_MIN_MAX_TOKENS = 4096
_PROJECT_ROOT = Path(__file__).resolve().parents[3]

_LEGACY_SOURCES_FALLBACK = re.compile(
    r"\n##\s*Sources\s+used\s*\n+\*The model did not return an explicit source list\.[\s\S]*$",
    re.IGNORECASE,
)
_TRAILING_SOURCES_USED = re.compile(r"\n##\s*Sources\s+used\b[\s\S]*$", re.IGNORECASE)
_TRAILING_REFERENCES = re.compile(r"\n##\s*References\b[\s\S]*$", re.IGNORECASE)
_WHAT_I_UNDERSTOOD_HEADING = re.compile(r"(?m)^#{1,2}\s+what\s+i\s+understood\b")


def _strip_opening_meta_preamble(markdown: str) -> str:
    """If ``## What I understood`` is not first, drop text before that heading."""
    clean = markdown.replace("\r\n", "\n").replace("\r", "\n").lstrip()
    match = _WHAT_I_UNDERSTOOD_HEADING.search(clean)
    if match is not None and match.start() > 0:
        return clean[match.start() :].lstrip()
    return markdown


def _strip_json_code_fences(text: str) -> str:
    """Remove optional ```json ... ``` wrapper from model output."""
    clean = text.strip()
    if not clean.startswith("```"):
        return clean
    clean = re.sub(r"^```(?:json)?\s*", "", clean, count=1, flags=re.IGNORECASE)
    clean = re.sub(r"\s*```\s*$", "", clean, count=1)
    return clean.strip()


def _parse_llm_json(raw: str) -> tuple[str, float | None, list[str], bool]:
    """
    Parse model JSON envelope ``response`` / ``confidence`` / ``sources``.

    Returns ``(markdown_body, confidence, sources, parsed_envelope)``. If parse
    fails, returns ``(raw, None, [], False)``.
    """
    clean = _strip_json_code_fences(raw)
    if not clean:
        return raw, None, [], False
    data: dict[str, object] | None = None
    try:
        loaded = json.loads(clean)
        data = loaded if isinstance(loaded, dict) else None
    except json.JSONDecodeError:
        i = clean.find("{")
        j = clean.rfind("}")
        if i != -1 and j > i:
            try:
                loaded = json.loads(clean[i : j + 1])
                data = loaded if isinstance(loaded, dict) else None
            except json.JSONDecodeError:
                data = None
    if data is None:
        return raw, None, [], False
    response_val = data.get("response")
    if response_val is None:
        return raw, None, [], False
    text_out = str(response_val).strip()
    if not text_out:
        return raw, None, [], False

    confidence: float | None = None
    confidence_raw = data.get("confidence")
    try:
        if confidence_raw is not None and confidence_raw != "":
            confidence = max(0.0, min(1.0, float(confidence_raw)))
    except (TypeError, ValueError):
        confidence = None

    sources: list[str] = []
    source_raw = data.get("sources")
    if isinstance(source_raw, list):
        for item in source_raw:
            if isinstance(item, str) and item.strip():
                sources.append(item.strip())
    elif isinstance(source_raw, str) and source_raw.strip():
        sources.append(source_raw.strip())

    return text_out, confidence, sources, True


def _first_existing_source_local_path(paths: list[str]) -> str:
    """Return first path that resolves to a file under project root."""
    root = _PROJECT_ROOT.resolve()
    for rel in paths:
        rel_clean = rel.strip().replace("\\", "/").lstrip("/")
        if not rel_clean:
            continue
        candidate = (root / rel_clean).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            continue
        if candidate.is_file():
            return str(candidate)
    return ""


def _compose_used_context(*, confidence: float | None, sources: list[str], catalogue_preview: str) -> str:
    """Prefix confidence and source list ahead of catalogue preview."""
    lines = [
        "References:",
        "",
        f"confidence: {confidence:.4f}" if confidence is not None else "confidence:",
        "sources:",
    ]
    if sources:
        for path in sources:
            lines.append(f"  - {path}")
    else:
        lines.append("  - (none listed)")
    lines.extend(["", "---", ""])
    return "\n".join(lines) + (catalogue_preview.strip() or "(no catalogue preview)")


def _invoke_digital_markdown_llm(
    *,
    provider: str,
    query: str,
    catalogue_summary_json: str,
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
    stream_handler: Callable[[str], None] | None = None,
) -> str:
    """Single LLM call: digital JSON + question -> Markdown answer envelope."""
    template = load_digital_rag_markdown_prompt()
    system_prompt = template.format(
        domain_context=DIGITAL_FEATURE.prompt_context,
        selected_channel="Digital",
        abbreviation_guide=DIGITAL_ABBREVIATION_GUIDE,
        catalogue_summary_json=catalogue_summary_json,
    )
    digital_tokens = max(int(retriever_cfg.max_tokens), _DIGITAL_MIN_MAX_TOKENS)

    if provider == "azure":
        azure_cfg.validate()
        llm = AzureChatOpenAI(
            azure_endpoint=azure_cfg.endpoint,
            azure_deployment=azure_cfg.deployment_name,
            api_version=azure_cfg.api_version,
            api_key=azure_cfg.api_key,
            temperature=retriever_cfg.temperature,
            max_tokens=digital_tokens,
        )
    elif provider == "openai":
        openai_cfg.validate()
        llm = ChatOpenAI(
            model=openai_cfg.model_name,
            api_key=openai_cfg.api_key,
            temperature=retriever_cfg.temperature,
            max_tokens=digital_tokens,
        )
    else:
        ollama_cfg.validate()
        llm = ChatOllama(
            model=ollama_cfg.model_name,
            base_url=ollama_cfg.base_url,
            temperature=retriever_cfg.temperature,
            num_predict=digital_tokens,
            streaming=ollama_cfg.stream or True,
        )

    messages = [("system", system_prompt), ("user", query.strip())]
    text = ""
    try:
        if provider == "ollama" and bool(ollama_cfg.stream):
            chunks: list[str] = []
            for chunk in llm.stream(messages):
                piece = str(getattr(chunk, "content", "") or "")
                if not piece:
                    continue
                chunks.append(piece)
                if stream_handler is not None:
                    stream_handler(piece)
            text = "".join(chunks).strip()
            if not text:
                response = llm.invoke(messages)
                text = str(getattr(response, "content", "") or "").strip()
        else:
            response = llm.invoke(messages)
            text = str(getattr(response, "content", "") or "").strip()
    except Exception as exc:  # noqa: BLE001
        logger.exception("Digital Markdown LLM failed: %s", exc)
        return (
            "## Summary\n\n"
            "The assistant could not reach the language model. Check provider settings "
            "and try again.\n"
        )

    text = text.replace("\r\n", "\n").replace("\r", "\n")
    if not text:
        return (
            "## Summary\n\n"
            "## Not covered\n\n"
            "The model returned an empty response. Try rephrasing the question.\n"
        )
    return text


def run_query(
    *,
    provider: str,
    query: str,
    store: Any = None,
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
    embeddings: Embeddings | None = None,
    embedding_shortlist: int = 0,
    stream_handler: Callable[[str], None] | None = None,
) -> FeatureAnswer:
    """Run digital query using catalogue JSON-only grounding."""
    del embeddings, embedding_shortlist, store
    catalogue_summary_json = load_digital_catalogue_json_text()
    if not catalogue_summary_json.strip() or catalogue_summary_json.strip() in ("{}", "null"):
        return FeatureAnswer(
            content=(
                "## Summary\n\n## Not covered\n\n"
                "The digital catalogue JSON is missing or empty. "
                "Ensure `catelogue/digital/catalogue_digital.json` exists.\n"
            ),
            used_context="",
            source_local_path="",
        )

    raw_llm = _invoke_digital_markdown_llm(
        provider=provider,
        query=query,
        catalogue_summary_json=catalogue_summary_json,
        retriever_cfg=retriever_cfg,
        azure_cfg=azure_cfg,
        openai_cfg=openai_cfg,
        ollama_cfg=ollama_cfg,
        stream_handler=stream_handler,
    )
    content = raw_llm.replace("\r\n", "\n").replace("\r", "\n")
    body, confidence, sources_list, envelope_ok = _parse_llm_json(content)
    if envelope_ok:
        content = _strip_opening_meta_preamble(body)
    else:
        confidence = None
        sources_list = []

    content = _LEGACY_SOURCES_FALLBACK.sub("", content).rstrip()
    payload = load_digital_catalogue_payload()
    if not sources_list:
        sources_list = rank_source_paths_for_query(query=query, payload=payload, max_paths=8)
    content = _TRAILING_SOURCES_USED.sub("", content).rstrip()
    content = _TRAILING_REFERENCES.sub("", content).rstrip()

    catalogue_preview = build_catalogue_sources_preview_text(payload, max_chars=12_000)
    if not catalogue_preview.strip():
        catalogue_preview = (
            catalogue_summary_json
            if len(catalogue_summary_json) < 12_000
            else catalogue_summary_json[:11_500] + "\n\n... [truncated for UI context preview]"
        )
    used = _compose_used_context(
        confidence=confidence,
        sources=sources_list,
        catalogue_preview=catalogue_preview,
    )
    source_local = _first_existing_source_local_path(sources_list)
    return FeatureAnswer(
        content=content,
        used_context=used,
        source_local_path=source_local,
        confidence=confidence,
        source_paths=tuple(sources_list),
    )

