"""Digital feature-specific retrieval flow."""

from __future__ import annotations

from pathlib import Path
from urllib.parse import urlparse

from langchain_core.embeddings import Embeddings

from src.config.settings import AzureOpenAIConfig, OpenAIConfig, RetrieverConfig
from src.features.base import FeatureAnswer
from src.llm.retriever import DocumentRetriever, OpenAIDocumentRetriever, RetrievalResult
from src.services.document_store import DocumentStore


def _resolve_local_source_path(url: str) -> Path | None:
    parsed = urlparse(url.strip())
    if parsed.scheme in {"http", "https"}:
        return None
    project_root = Path(__file__).resolve().parents[3]
    relative_path = parsed.path.strip().lstrip("/\\")
    if not relative_path:
        return None
    candidate = (project_root / relative_path).resolve()
    try:
        candidate.relative_to(project_root)
    except ValueError:
        return None
    if candidate.exists() and candidate.is_file():
        return candidate
    return None


def _compose_reply(result: RetrievalResult, store: DocumentStore) -> str:
    if not result.matches:
        lines = ["I could not find a direct digital tools match. Available catalogue:"]
        for doc in store.all()[:6]:
            lines.append(f"- **{doc.title}**: {doc.summary}")
        return "\n".join(lines)

    lines: list[str] = []
    if len(result.matches) > 1:
        lines.append(f"I found relevant guidance across {len(result.matches)} transcript sources.")
        lines.append("")
    for idx, match in enumerate(result.matches, start=1):
        lines.append(f"**Transcript Source {idx}: {match.document.title}**")
        if match.matched_slides:
            for slide in match.matched_slides:
                lines.append(
                    f"- **Segment {slide.number} ({slide.title or 'Untitled'})**: "
                    f"{slide.note or 'Relevant digital workflow detail.'}"
                )
        else:
            lines.append(f"- {match.reasoning or match.document.summary}")
        lines.append(f"- URL: `{match.document.url}`")
        lines.append("")
    return "\n".join(lines).strip()


def _compose_context(result: RetrievalResult) -> str:
    blocks: list[str] = []
    for idx, match in enumerate(result.matches, start=1):
        blocks.append(f"Transcript source {idx}: {match.document.title}")
        for slide in match.matched_slides:
            blocks.append(f"- Segment {slide.number}: {slide.title} | {slide.note}")
    return "\n".join(blocks).strip()


def run_query(
    *,
    provider: str,
    query: str,
    store: DocumentStore,
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    embeddings: Embeddings | None = None,
    embedding_shortlist: int = 0,
) -> FeatureAnswer:
    """Run digital retrieval and return UI-ready response."""
    if provider == "azure":
        azure_cfg.validate()
        retriever = DocumentRetriever(
            store=store,
            azure_cfg=azure_cfg,
            ret_cfg=retriever_cfg,
            active_type="digital",
        )
    else:
        openai_cfg.validate()
        retriever = OpenAIDocumentRetriever(
            model_name=openai_cfg.model_name,
            api_key=openai_cfg.api_key,
            store=store,
            ret_cfg=retriever_cfg,
            active_type="digital",
        )

    result = retriever.retrieve(
        query.strip(),
        embeddings=embeddings,
        embedding_shortlist=embedding_shortlist,
    )
    source_path = ""
    if result.best is not None:
        local_source = _resolve_local_source_path(result.best.document.url)
        if local_source is not None:
            source_path = str(local_source)
    return FeatureAnswer(
        content=_compose_reply(result, store),
        used_context=_compose_context(result),
        source_local_path=source_path,
    )

