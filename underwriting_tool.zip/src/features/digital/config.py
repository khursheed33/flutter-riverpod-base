"""Configuration for digital feature."""

from __future__ import annotations

from pathlib import Path

from src.features.base import FeatureDefinition

DIGITAL_FEATURE = FeatureDefinition(
    key="digital",
    display_name="Digital",
    mode="catalogue",
    prompt_context=(
        "Domain focus: Digital channels and journeys. Prefer app/web flows, "
        "digital campaigns, customer experience, funnel metrics, and platform features."
    ),
    catalogue_paths=(Path("catelogue") / "digital.json",),
)

