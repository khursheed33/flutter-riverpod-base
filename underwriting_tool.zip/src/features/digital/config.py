"""Configuration for digital feature."""

from __future__ import annotations

from pathlib import Path

from src.features.base import FeatureDefinition

DIGITAL_FEATURE = FeatureDefinition(
    key="digital",
    display_name="Digital",
    mode="catalogue",
    prompt_context=(
        "Domain focus: Digital channels and journeys. Prefer app/web flows, "
        "digital campaigns, customer experience, funnel metrics, and platform features. "
        "Digital catalogue JSON lives at catelogue/digital/catalogue_digital.json and "
        "references local transcript .txt sources under catelogue/digital. "
        "User-facing answers must stay grounded in those transcript sources."
    ),
    catalogue_paths=(Path("catelogue") / "digital",),
)

