"""Feature registry for runtime type selection."""

from __future__ import annotations

from src.features.base import FeatureDefinition
from src.features.digital.config import DIGITAL_FEATURE
from src.features.internet.config import INTERNET_FEATURE
from src.features.underwriting.config import UNDERWRITING_FEATURE
from src.features.web_rag.config import WEB_RAG_FEATURE

FEATURE_REGISTRY: dict[str, FeatureDefinition] = {
    UNDERWRITING_FEATURE.key: UNDERWRITING_FEATURE,
    DIGITAL_FEATURE.key: DIGITAL_FEATURE,
    INTERNET_FEATURE.key: INTERNET_FEATURE,
    WEB_RAG_FEATURE.key: WEB_RAG_FEATURE,
}


def get_feature(feature_type: str) -> FeatureDefinition:
    """Resolve a feature definition or raise clear config error."""
    normalized = feature_type.strip().lower()
    if normalized not in FEATURE_REGISTRY:
        supported = ", ".join(sorted(FEATURE_REGISTRY.keys()))
        raise EnvironmentError(f"Invalid ACTIVE_TYPE. Use one of: {supported}.")
    return FEATURE_REGISTRY[normalized]


def feature_keys() -> list[str]:
    """List available feature keys in stable order."""
    return list(FEATURE_REGISTRY.keys())

