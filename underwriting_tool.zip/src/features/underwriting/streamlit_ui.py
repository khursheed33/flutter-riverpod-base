"""Underwriting-specific Streamlit UI helpers."""

from __future__ import annotations

from pathlib import Path

import streamlit as st

CHAT_PLACEHOLDER = "Ask underwriting questions..."
FEATURE_DESCRIPTION = (
    "Ask questions across underwriting guidelines and get policy-focused answers "
    "as structured Markdown grounded in the active channel catalogue."
)

SOURCE_PREVIEW_HEIGHT_PX = 420
SOURCES_EXPANDER_TITLE = "Sources"


def _open_local_file(local_path: Path) -> None:
    """Open local source file in the OS default handler."""
    import os

    try:
        os.startfile(str(local_path))  # type: ignore[attr-defined]
    except AttributeError:
        import webbrowser

        webbrowser.open(local_path.as_uri())


def render_sources_expander(paths: list[str]) -> None:
    """Render expandable source path list for underwriting answers."""
    clean = [p.strip() for p in paths if str(p).strip()]
    if not clean:
        return
    with st.expander(SOURCES_EXPANDER_TITLE, expanded=False):
        st.code("\n".join(clean), language="text")


def render_preview_section(*, source_path: str, used_context: str, key_suffix: str) -> None:
    """Render source open action and context preview popover consistently."""
    has_source = bool(source_path.strip())
    has_context = bool(used_context.strip())
    if not has_source and not has_context:
        return

    open_col, preview_col, _spacer = st.columns([1, 3, 8])
    with open_col:
        if has_source and st.button("📂", key=f"uw-source-open-{key_suffix}", help="Open selected source"):
            _open_local_file(Path(source_path.strip()))
    with preview_col:
        with st.popover("Preview", use_container_width=True):
            st.text_area(
                "Retrieved context",
                value=used_context.strip() if has_context else "No context available.",
                height=SOURCE_PREVIEW_HEIGHT_PX,
                disabled=True,
                key=f"uw-preview-{key_suffix}",
            )

