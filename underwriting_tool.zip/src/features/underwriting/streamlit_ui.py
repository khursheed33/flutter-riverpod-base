"""Underwriting-specific Streamlit UI helpers."""

from __future__ import annotations

CHAT_PLACEHOLDER = "Ask underwriting questions..."
FEATURE_DESCRIPTION = (
    "Ask questions across underwriting guidelines and get policy-focused answers "
    "with document references."
)

