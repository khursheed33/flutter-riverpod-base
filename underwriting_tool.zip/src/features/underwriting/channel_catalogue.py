"""Channel-scoped underwriting catalogue helpers."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

_PROJECT_ROOT = Path(__file__).resolve().parents[3]
_CATELOGUE_DIR = _PROJECT_ROOT / "catelogue" / "underwriting"

_PREVIEW_SLIDE_CHARS = 180
_PREVIEW_DOC_SUMMARY_CHARS = 320
_MAX_PREVIEW_DOCS = 8
_MAX_PREVIEW_SLIDES_PER_DOC = 5


def _read_json(path: Path) -> dict[str, Any]:
    """Safely read JSON file as dictionary."""
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8", errors="replace"))
    except json.JSONDecodeError:
        return {}
    return data if isinstance(data, dict) else {}


def merge_all_channel_catalogues() -> dict[str, Any]:
    """Merge products from axis/agency/dsf catalogue files (dedupe by key)."""
    merged_products: dict[str, Any] = {}
    for name in ("catalogue_axis.json", "catalogue_agency.json", "catalogue_dsf.json"):
        data = _read_json(_CATELOGUE_DIR / name)
        products = data.get("products")
        if isinstance(products, dict):
            merged_products.update(products)
    return {
        "schema": "axis_max_life_catalogue_v1_merged",
        "channel_filter": "all",
        "products": merged_products,
        "note": "Merged Axis, Agency, and DSF catalogue slices for broad retrieval.",
    }


def load_channel_catalogue_payload(channel_key: str) -> dict[str, Any]:
    """Return catalogue payload for ``axis`` / ``agency`` / ``dsf`` / ``all``."""
    key = (channel_key or "axis").strip().lower()
    if key == "all":
        return merge_all_channel_catalogues()
    if key not in {"axis", "agency", "dsf"}:
        key = "axis"
    data = _read_json(_CATELOGUE_DIR / f"catalogue_{key}.json")
    return data if data else {}


def load_channel_catalogue_json_text(channel_key: str, *, max_chars: int = 120_000) -> str:
    """Return compact JSON text for prompt injection."""
    payload = load_channel_catalogue_payload(channel_key)
    text = json.dumps(payload, ensure_ascii=False, indent=2)
    if len(text) <= max_chars:
        return text
    return text[: max_chars - 80] + "\n...\n[truncated for prompt size]"


def _truncate(text: str, max_chars: int) -> str:
    """Trim long preview text with ellipsis."""
    value = text.strip()
    if len(value) <= max_chars:
        return value
    if max_chars <= 1:
        return "..."
    return value[: max_chars - 1].rstrip() + "..."


def iter_catalogue_documents(payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Collect unique document objects from nested catalogue payload."""
    results: list[dict[str, Any]] = []
    seen: set[str] = set()

    def walk(node: Any) -> None:
        if isinstance(node, dict):
            documents = node.get("documents")
            if isinstance(documents, list):
                for doc in documents:
                    if not isinstance(doc, dict):
                        continue
                    doc_name = str(doc.get("doc_name", "")).strip()
                    dedupe_key = doc_name or str(id(doc))
                    if dedupe_key in seen:
                        continue
                    seen.add(dedupe_key)
                    results.append(doc)
            for key, value in node.items():
                if key != "documents":
                    walk(value)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(payload)
    return results


def _query_terms(query: str) -> set[str]:
    """Tokenize query into lowercase terms (length >= 3)."""
    tokens = re.split(r"[^a-z0-9]+", query.lower().replace("-", " "))
    return {token for token in tokens if len(token) >= 3}


def rank_source_paths_for_query(
    *,
    query: str,
    payload: dict[str, Any],
    max_paths: int = 12,
) -> list[str]:
    """Rank and return source paths likely relevant to the user query."""
    terms = _query_terms(query)
    scored_paths: list[tuple[float, str]] = []
    seen_paths: set[str] = set()

    for doc in iter_catalogue_documents(payload):
        doc_name = str(doc.get("doc_name", "")).strip()
        slides = doc.get("slides") or []
        if not isinstance(slides, list):
            continue
        for slide in slides:
            if not isinstance(slide, dict):
                continue
            source_path = str(slide.get("source_path", "")).strip().replace("\\", "/")
            if not source_path or source_path in seen_paths:
                continue
            hint = str(slide.get("slide_title_hint", "")).strip()
            summary = str(slide.get("summary", "")).strip()
            hay = f"{doc_name} {hint} {summary}".lower().replace("-", " ")
            score = float(sum(1 for term in terms if term in hay)) if terms else 0.0
            scored_paths.append((score, source_path))
            seen_paths.add(source_path)

    scored_paths.sort(key=lambda row: (-row[0], row[1]))
    if not scored_paths:
        return []
    if terms:
        positive = [path for score, path in scored_paths if score > 0]
        return positive[:max_paths] if positive else [path for _, path in scored_paths[:max_paths]]
    return [path for _, path in scored_paths[:max_paths]]


def build_catalogue_sources_preview_text(
    payload: dict[str, Any],
    *,
    max_chars: int = 12_000,
) -> str:
    """Build a readable preview of catalogue docs/slides for UI context popover."""
    docs = iter_catalogue_documents(payload)
    if not docs:
        return ""

    lines: list[str] = [
        "Channel catalogue - source preview (indexed documents and slide excerpts).",
        "",
    ]
    used = 0

    for doc in docs[:_MAX_PREVIEW_DOCS]:
        if used >= max_chars:
            break
        doc_name = str(doc.get("doc_name", "")).strip() or "(unnamed document)"
        doc_summary = _truncate(str(doc.get("summary", "")), _PREVIEW_DOC_SUMMARY_CHARS)
        block = [f"Document: {doc_name}"]
        if doc_summary:
            block.append(f"  Deck summary: {doc_summary}")

        slides = doc.get("slides") or []
        if isinstance(slides, list):
            for slide in slides[:_MAX_PREVIEW_SLIDES_PER_DOC]:
                if not isinstance(slide, dict):
                    continue
                try:
                    slide_number = int(slide.get("slide_number", 0))
                except (TypeError, ValueError):
                    slide_number = 0
                hint = str(slide.get("slide_title_hint", "")).strip()
                summary = _truncate(str(slide.get("summary", "")), _PREVIEW_SLIDE_CHARS)
                source_path = str(slide.get("source_path", "")).strip()
                line = f"    Slide {slide_number} - {hint}" if hint else f"    Slide {slide_number}"
                if summary:
                    line += f"\n      Preview: {summary}"
                if source_path:
                    line += f"\n      Path: {source_path}"
                block.append(line)

        chunk = "\n".join(block) + "\n"
        if used + len(chunk) > max_chars:
            lines.append("... [preview truncated]")
            break
        lines.append(chunk)
        used += len(chunk)

    return "\n".join(lines).strip()
