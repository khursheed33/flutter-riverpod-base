"""Load the underwriting RAG Markdown prompt from ``underwriting_prompt.d``."""

from __future__ import annotations

from pathlib import Path

_PROMPT_PATH = Path(__file__).resolve().parent / "underwriting_prompt.d" / "underwriting_prompt.txt"


def load_underwriting_rag_markdown_prompt() -> str:
    """
    Return the single-shot underwriting prompt (catalogue JSON + question → JSON envelope).

    The model must reply with one JSON object: ``response`` (markdown string),
    ``confidence`` (0-1), ``sources`` (path strings). Placeholders in the template:
    ``domain_context``, ``selected_channel``, ``abbreviation_guide``,
    ``catalogue_summary_json``. The user question is the separate human turn.
    """
    if not _PROMPT_PATH.is_file():
        raise FileNotFoundError(f"Missing underwriting prompt: {_PROMPT_PATH}")
    return _PROMPT_PATH.read_text(encoding="utf-8")
