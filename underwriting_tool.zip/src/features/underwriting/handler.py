"""Underwriting feature: channel JSON + query → structured Markdown (single LLM pass)."""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any, Callable
from urllib.parse import urlparse
from uuid import uuid4

from langchain_core.embeddings import Embeddings
from langchain_ollama import ChatOllama
from langchain_openai import AzureChatOpenAI, ChatOpenAI

from src.config.settings import AzureOpenAIConfig, OllamaConfig, OpenAIConfig, RetrieverConfig
from src.features.base import FeatureAnswer
from src.features.underwriting.channel_catalogue import (
    build_catalogue_sources_preview_text,
    load_channel_catalogue_json_text,
    load_channel_catalogue_payload,
    rank_source_paths_for_query,
)
from src.features.underwriting.config import UNDERWRITING_FEATURE
from src.features.underwriting.prompt_loader import load_underwriting_rag_markdown_prompt

logger = logging.getLogger(__name__)
UNDERWRITING_ABBREVIATION_GUIDE = "SA = Sum Assured"
# Underwriting answers include multiple sections plus References; small max_tokens truncates before headings.
_UNDERWRITING_MIN_MAX_TOKENS = 4096

_LEGACY_SOURCES_FALLBACK = re.compile(
    r"\n##\s*Sources\s+used\s*\n+\*The model did not return an explicit source list\.[\s\S]*$",
    re.IGNORECASE,
)
_TRAILING_SOURCES_USED = re.compile(r"\n##\s*Sources\s+used\b[\s\S]*$", re.IGNORECASE)
_TRAILING_REFERENCES = re.compile(r"\n##\s*References\b[\s\S]*$", re.IGNORECASE)
_PROJECT_ROOT = Path(__file__).resolve().parents[3]
_UNDERWRITING_LOG_DIR = _PROJECT_ROOT / "logs" / "underwriting"

# Strip LLM filler (e.g. "Based on the provided catalogue JSON...") before the
# required opening heading when the model still included it.
_WHAT_I_UNDERSTOOD_HEADING = re.compile(r"(?m)^#{1,2}\s+what\s+i\s+understood\b")


def _strip_uw_opening_meta_preamble(markdown: str) -> str:
    """If ``## What I understood`` is not first, drop text before that heading."""
    s = markdown.replace("\r\n", "\n").replace("\r", "\n").lstrip()
    m = _WHAT_I_UNDERSTOOD_HEADING.search(s)
    if m is not None and m.start() > 0:
        return s[m.start() :].lstrip()
    return markdown


def _make_request_logger() -> tuple[str, Path, Callable[[str, str], None]]:
    """Create per-request logger that writes to file and console."""
    _UNDERWRITING_LOG_DIR.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    request_id = f"{ts}-{uuid4().hex[:8]}"
    log_path = _UNDERWRITING_LOG_DIR / f"underwriting-{request_id}.log"

    def _log(step: str, content: str) -> None:
        stamp = datetime.now().isoformat(timespec="seconds")
        body = content.rstrip() if content else "(empty)"
        block = (
            f"[{stamp}] {step}\n"
            f"{'-' * 80}\n"
            f"{body}\n"
            f"{'=' * 80}\n"
        )
        try:
            with log_path.open("a", encoding="utf-8") as fh:
                fh.write(block + "\n")
        except OSError:
            logger.exception("Failed writing underwriting log file: %s", log_path)
        print(block, flush=True)

    _log("request_init", f"request_id={request_id}\nlog_file={log_path}")
    return request_id, log_path, _log


def _strip_json_code_fences(text: str) -> str:
    """Remove optional ```json ... ``` wrapper from model output."""
    s = text.strip()
    if not s.startswith("```"):
        return s
    s = re.sub(r"^```(?:json)?\s*", "", s, count=1, flags=re.IGNORECASE)
    s = re.sub(r"\s*```\s*$", "", s, count=1)
    return s.strip()


def _parse_underwriting_llm_json(raw: str) -> tuple[str, float | None, list[str], bool]:
    """
    Parse the model's JSON envelope ``response`` / ``confidence`` / ``sources``.

    Returns ``(markdown_body, confidence, sources, parsed_envelope)``. If the
    envelope cannot be parsed, returns ``(raw, None, [], False)``.
    """
    s = _strip_json_code_fences(raw)
    if not s:
        return raw, None, [], False
    data: dict[str, object] | None = None
    try:
        loaded = json.loads(s)
        data = loaded if isinstance(loaded, dict) else None
    except json.JSONDecodeError:
        i = s.find("{")
        j = s.rfind("}")
        if i != -1 and j > i:
            try:
                loaded = json.loads(s[i : j + 1])
                data = loaded if isinstance(loaded, dict) else None
            except json.JSONDecodeError:
                data = None
    if data is None:
        return raw, None, [], False
    response_val = data.get("response")
    if response_val is None:
        return raw, None, [], False
    text_out = str(response_val).strip()
    if not text_out:
        return raw, None, [], False

    conf: float | None = None
    conf_raw = data.get("confidence")
    try:
        if conf_raw is not None and conf_raw != "":
            conf = max(0.0, min(1.0, float(conf_raw)))
    except (TypeError, ValueError):
        conf = None

    sources: list[str] = []
    src = data.get("sources")
    if isinstance(src, list):
        for item in src:
            if isinstance(item, str) and item.strip():
                sources.append(item.strip())
    elif isinstance(src, str) and src.strip():
        sources.append(src.strip())

    return text_out, conf, sources, True


def _first_existing_source_local_path(paths: list[str]) -> str:
    """Return the first ``paths`` entry that resolves to a file under the project root."""
    root = _PROJECT_ROOT.resolve()
    for rel in paths:
        rel_clean = rel.strip().replace("\\", "/").lstrip("/")
        if not rel_clean:
            continue
        candidate = (root / rel_clean).resolve()
        try:
            candidate.relative_to(root)
        except ValueError:
            continue
        if candidate.is_file():
            return str(candidate)
    return ""


def _compose_underwriting_used_context(
    *,
    confidence: float | None,
    sources: list[str],
    catalogue_preview: str,
) -> str:
    """Prefix parsed JSON metadata ahead of the catalogue preview for the UI popover."""
    lines = [
        "References:",
        "",
        f"confidence: {confidence:.4f}" if confidence is not None else "confidence:",
        "sources:",
    ]
    if sources:
        for p in sources:
            lines.append(f"  - {p}")
    else:
        lines.append("  - (none listed)")
    lines.extend(["", "---", ""])
    return "\n".join(lines) + (catalogue_preview.strip() or "(no catalogue preview)")


def _normalize_channel_selection(selected_channel: str | None) -> tuple[str | None, str, str]:
    """
    Map UI / CLI channel to filter token, JSON file key, and display label.

    Default channel is **Axis** when selection is missing or unrecognised.
    """
    raw = (selected_channel or "Axis").strip()
    low = raw.lower()
    if low in ("all channels", "all"):
        return None, "all", "All channels"
    if low == "axis":
        return "axis", "axis", "Axis"
    if low == "agency":
        return "agency", "agency", "Agency"
    if low == "dsf":
        return "dsf", "dsf", "DSF"
    return "axis", "axis", "Axis"


def _resolve_local_source_path(url: str) -> Path | None:
    parsed = urlparse(url.strip())
    if parsed.scheme in {"http", "https"}:
        return None
    project_root = Path(__file__).resolve().parents[3]
    relative_path = parsed.path.strip().lstrip("/\\")
    if not relative_path:
        return None
    candidate = (project_root / relative_path).resolve()
    try:
        candidate.relative_to(project_root)
    except ValueError:
        return None
    if candidate.exists() and candidate.is_file():
        return candidate
    return None


def _invoke_underwriting_markdown_llm(
    *,
    provider: str,
    query: str,
    catalogue_summary_json: str,
    channel_display: str,
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
    log_step: Callable[[str, str], None] | None = None,
) -> str:
    """Single LLM call: channel JSON + question → Markdown answer."""
    domain_context = UNDERWRITING_FEATURE.prompt_context
    template = load_underwriting_rag_markdown_prompt()
    system_prompt = template.format(
        domain_context=domain_context,
        selected_channel=channel_display,
        abbreviation_guide=UNDERWRITING_ABBREVIATION_GUIDE,
        catalogue_summary_json=catalogue_summary_json,
    )
    if log_step is not None:
        log_step("llm_system_prompt", system_prompt)
        log_step("llm_user_query", query.strip())

    if retriever_cfg.trace_llm_prompts:
        trace = (
            f"\n{'=' * 80}\nLLM PROMPT TRACE [underwriting_markdown_rag]\n{'=' * 80}\n"
            f"--- SYSTEM ---\n{system_prompt}\n\n--- USER ---\n{query}\n"
            f"{'=' * 80}\nEND PROMPT TRACE\n{'=' * 80}\n"
        )
        print(trace, flush=True)
        logger.info("%s", trace.strip())

    uw_tokens = max(int(retriever_cfg.max_tokens), _UNDERWRITING_MIN_MAX_TOKENS)

    if provider == "azure":
        azure_cfg.validate()
        llm = AzureChatOpenAI(
            azure_endpoint=azure_cfg.endpoint,
            azure_deployment=azure_cfg.deployment_name,
            api_version=azure_cfg.api_version,
            api_key=azure_cfg.api_key,
            temperature=retriever_cfg.temperature,
            max_tokens=uw_tokens,
        )
    elif provider == "openai":
        openai_cfg.validate()
        llm = ChatOpenAI(
            model=openai_cfg.model_name,
            api_key=openai_cfg.api_key,
            temperature=retriever_cfg.temperature,
            max_tokens=uw_tokens,
        )
    else:
        ollama_cfg.validate()
        llm = ChatOllama(
            model=ollama_cfg.model_name,
            base_url=ollama_cfg.base_url,
            temperature=retriever_cfg.temperature,
            num_predict=uw_tokens,
            streaming=ollama_cfg.stream,
        )

    try:
        response = llm.invoke([("system", system_prompt), ("user", query.strip())])
    except Exception as exc:  # noqa: BLE001
        logger.exception("Underwriting Markdown LLM failed: %s", exc)
        if log_step is not None:
            log_step("llm_error", repr(exc))
        return (
            "## Summary\n\n"
            "The assistant could not reach the language model. Check provider settings "
            "and try again.\n"
        )

    text = str(getattr(response, "content", "") or "").strip()
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    if not text:
        if log_step is not None:
            log_step("llm_raw_response", "(empty)")
        return (
            "## Summary\n\n"
            "## Not covered\n\n"
            "The model returned an empty response. Try rephrasing the question or "
            "reducing prompt size.\n"
        )
    if log_step is not None:
        log_step("llm_raw_response", text)
    return text


def run_query(
    *,
    provider: str,
    query: str,
    store: Any = None,
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
    embeddings: Embeddings | None = None,
    embedding_shortlist: int = 0,
    selected_channel: str | None = None,
) -> FeatureAnswer:
    """
    Run underwriting: **channel catalogue JSON + user query** → parsed JSON envelope.

    The model must return JSON with ``response`` (markdown), ``confidence`` (0-1),
    and ``sources`` (path strings). The handler extracts those fields for the UI.

    ``embeddings`` / ``embedding_shortlist`` are ignored (retained for API compatibility).
    """
    del embeddings, embedding_shortlist, store
    request_id, request_log_path, log_step = _make_request_logger()

    _filter_token, catalogue_key, _channel_display = _normalize_channel_selection(selected_channel)
    catalogue_summary_json = load_channel_catalogue_json_text(catalogue_key)
    log_step(
        "request_input",
        (
            f"provider={provider}\n"
            f"selected_channel={selected_channel}\n"
            f"catalogue_key={catalogue_key}\n"
            f"query={query.strip()}"
        ),
    )

    if not catalogue_summary_json.strip() or catalogue_summary_json.strip() in ("{}", "null"):
        log_step("catalogue_check", "catalogue payload is empty")
        log_step("request_complete", f"request_id={request_id}\nlog_file={request_log_path}")
        return FeatureAnswer(
            content=(
                "## Summary\n\n## Not covered\n\n"
                "The channel catalogue JSON is missing or empty. "
                "Ensure `catelogue/catalogue_axis.json` (or the selected channel file) exists.\n"
            ),
            used_context="",
            source_local_path="",
        )
    raw_llm = _invoke_underwriting_markdown_llm(
        provider=provider,
        query=query,
        catalogue_summary_json=catalogue_summary_json,
        channel_display=_channel_display,
        retriever_cfg=retriever_cfg,
        azure_cfg=azure_cfg,
        openai_cfg=openai_cfg,
        ollama_cfg=ollama_cfg,
        log_step=log_step,
    )
    content = raw_llm.replace("\r\n", "\n").replace("\r", "\n")
    body, confidence, sources_list, envelope_ok = _parse_underwriting_llm_json(content)
    log_step(
        "parsed_llm_envelope",
        f"envelope_ok={envelope_ok}\nconfidence={confidence}\nsources_count={len(sources_list)}",
    )
    if envelope_ok:
        content = _strip_uw_opening_meta_preamble(body)
    else:
        confidence = None
        sources_list = []

    content = _LEGACY_SOURCES_FALLBACK.sub("", content).rstrip()

    payload = load_channel_catalogue_payload(catalogue_key)
    if not sources_list:
        sources_list = rank_source_paths_for_query(query=query, payload=payload, max_paths=12)
        log_step("fallback_sources", "\n".join(sources_list) if sources_list else "(none)")
    # Avoid duplicate citations in chat body; UI already renders source_paths separately.
    content = _TRAILING_SOURCES_USED.sub("", content).rstrip()
    content = _TRAILING_REFERENCES.sub("", content).rstrip()

    catalogue_preview = build_catalogue_sources_preview_text(payload, max_chars=12_000)
    if not catalogue_preview.strip():
        catalogue_preview = (
            catalogue_summary_json
            if len(catalogue_summary_json) < 12_000
            else catalogue_summary_json[:11_500] + "\n\n... [truncated for UI context preview]"
        )
    used = _compose_underwriting_used_context(
        confidence=confidence,
        sources=sources_list,
        catalogue_preview=catalogue_preview,
    )
    source_local = _first_existing_source_local_path(sources_list)
    log_step("final_answer_content", content)
    log_step(
        "final_sources",
        (
            f"source_local_path={source_local or '(none)'}\n"
            + ("\n".join(sources_list) if sources_list else "(no sources)")
        ),
    )
    log_step("request_complete", f"request_id={request_id}\nlog_file={request_log_path}")

    return FeatureAnswer(
        content=content,
        used_context=used,
        source_local_path=source_local,
        confidence=confidence,
        source_paths=tuple(sources_list),
    )
