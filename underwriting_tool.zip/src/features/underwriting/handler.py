"""Underwriting feature-specific retrieval flow."""

from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import urlparse

from langchain_core.embeddings import Embeddings
from langchain_openai import AzureChatOpenAI, ChatOpenAI

from src.config.settings import AzureOpenAIConfig, OpenAIConfig, RetrieverConfig
from src.features.base import FeatureAnswer
from src.llm.prompts import prompts_for_type
from src.llm.retriever import DocumentRetriever, OpenAIDocumentRetriever, RetrievalMatch, RetrievalResult
from src.services.document_store import Document, DocumentStore

MIN_CONFIDENT_SCORE = 0.40
MAX_SOURCE_PATH_DISPLAY = 70
UNDERWRITING_ABBREVIATION_GUIDE = "SA = Sum Assured"


def _resolve_local_source_path(url: str) -> Path | None:
    parsed = urlparse(url.strip())
    if parsed.scheme in {"http", "https"}:
        return None
    project_root = Path(__file__).resolve().parents[3]
    relative_path = parsed.path.strip().lstrip("/\\")
    if not relative_path:
        return None
    candidate = (project_root / relative_path).resolve()
    try:
        candidate.relative_to(project_root)
    except ValueError:
        return None
    if candidate.exists() and candidate.is_file():
        return candidate
    return None


def _compose_reply(result: RetrievalResult, store: DocumentStore) -> str:
    if not result.matches:
        lines = ["I could not find a direct underwriting match in the local .txt catalogue."]
        for doc in store.all()[:6]:
            lines.append(f"- **{doc.title}**: {doc.summary}")
        return "\n".join(lines)

    best = result.best
    if best is None or best.relevance_score < MIN_CONFIDENT_SCORE:
        return (
            "I am not fully confident about the exact underwriting requirement for this query. "
            "Please share if this is Savings or Protection and the sourcing channel (Axis/Agency/DSF)."
        )

    selected = result.matches[:2]
    understood = (result.query_understood_as or "").strip()
    if not understood:
        understood = "your underwriting requirement"

    lines: list[str] = []
    lines.append(f"I understand you wish to know about: **{understood}**.")
    lines.append("")

    for idx, match in enumerate(selected, start=1):
        doc = match.document
        ctype = doc.catalogue_domain.title() if doc.catalogue_domain else "Underwriting"
        channel = doc.underwriting_channel.strip() or "Not specified"
        answer_text = ""
        if match.matched_slides:
            answer_text = (match.matched_slides[0].note or match.matched_slides[0].title or "").strip()
        if not answer_text:
            answer_text = (match.reasoning or doc.summary).strip()

        lines.append(f"**Answer {idx}:** {answer_text}")
        lines.append(f"- Channel: {channel}")
        lines.append(f"- Catalogue type: {ctype}")
        lines.append("")

    return "\n".join(lines).strip()


def _shorten_source_path(path_text: str, max_chars: int = MAX_SOURCE_PATH_DISPLAY) -> str:
    """Shorten long source paths while keeping start and end visible."""
    value = path_text.strip()
    if len(value) <= max_chars:
        return value
    head = max_chars // 2 - 2
    tail = max_chars - head - 3
    return f"{value[:head]}...{value[-tail:]}"


def _build_dynamic_llm_reply(
    *,
    provider: str,
    query: str,
    result: RetrievalResult,
    store: DocumentStore,
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    selected_channel: str | None = None,
) -> str:
    """Generate a dynamic user-facing answer from query understanding and retrieval context."""
    if not result.matches:
        lines = ["I could not find a direct underwriting match in the local .txt catalogue."]
        for doc in store.all()[:6]:
            lines.append(f"- **{doc.title}**: {doc.summary}")
        return "\n".join(lines)

    best = result.best
    if best is None or best.relevance_score < MIN_CONFIDENT_SCORE:
        return (
            "I am not fully confident about the exact underwriting requirement for this query. "
            "Please share if this is Savings or Protection and the sourcing channel (Axis/Agency/DSF)."
        )

    selected = result.matches[:2]
    blocks: list[str] = []
    for idx, match in enumerate(selected, start=1):
        doc = match.document
        snippets: list[str] = []
        for slide in match.matched_slides[:2]:
            snippet = (slide.note or slide.title or "").strip()
            if snippet:
                snippets.append(snippet)
        if not snippets:
            fallback_snippet = (match.reasoning or doc.summary).strip()
            if fallback_snippet:
                snippets.append(fallback_snippet)
        joined_snippets = " | ".join(snippets)
        blocks.append(
            "\n".join(
                [
                    f"Result {idx}",
                    f"Title: {doc.title}",
                    f"Channel: {doc.underwriting_channel or 'Not specified'}",
                    f"Catalogue type: {doc.catalogue_domain or 'underwriting'}",
                    f"Reasoning: {match.reasoning or 'Not provided'}",
                    f"Evidence snippets: {joined_snippets or 'Not available'}",
                    f"Source path: {_shorten_source_path(doc.url)}",
                ]
            )
        )

    understood = (result.query_understood_as or "").strip() or "the underwriting requirement"
    prompt_bundle = prompts_for_type("underwriting")
    rendered_context = "\n\n".join(blocks)
    system_prompt = prompt_bundle.answer_synthesis_system_prompt.format(
        domain_context=prompt_bundle.domain_context,
        selected_channel=selected_channel or "All",
        abbreviation_guide=UNDERWRITING_ABBREVIATION_GUIDE,
        retrieved_content=rendered_context,
    )
    user_prompt = prompt_bundle.answer_synthesis_human_prompt.format(
        query=query,
        query_understood_as=understood,
        selected_channel=selected_channel or "All",
        abbreviation_guide=UNDERWRITING_ABBREVIATION_GUIDE,
        retrieved_context=rendered_context,
    )

    llm = (
        AzureChatOpenAI(
            azure_endpoint=azure_cfg.endpoint,
            azure_deployment=azure_cfg.deployment_name,
            api_version=azure_cfg.api_version,
            api_key=azure_cfg.api_key,
            temperature=retriever_cfg.temperature,
            max_tokens=retriever_cfg.max_tokens,
        )
        if provider == "azure"
        else ChatOpenAI(
            model=openai_cfg.model_name,
            api_key=openai_cfg.api_key,
            temperature=retriever_cfg.temperature,
            max_tokens=retriever_cfg.max_tokens,
        )
    )

    try:
        response = llm.invoke(
            [
                ("system", system_prompt),
                ("user", user_prompt),
            ]
        )
    except Exception:
        return _compose_reply(result, store)

    content = str(getattr(response, "content", "")).strip()
    if not content:
        return _compose_reply(result, store)
    return content


def _build_sources_section(result: RetrievalResult) -> str:
    """Build deterministic source lines outside LLM-generated content."""
    if not result.matches:
        return ""

    def _wrap_path(path: str) -> str:
        """Insert soft wrap opportunities for long paths in markdown."""
        return path.replace("\\", "\\\u200b").replace("/", "/\u200b")

    lines = ["Sources:"]
    for idx, match in enumerate(result.matches[:2], start=1):
        lines.append(f"- Source {idx}: {_wrap_path(match.document.url)}")
    return "\n".join(lines)


def _doc_matches_requested_channel(doc: Document, requested: str) -> bool:
    """Return True when document metadata matches the requested channel token."""
    ch = (doc.underwriting_channel or "").lower()
    if ch == requested:
        return True
    haystack = " ".join(doc.tags).lower() + " " + doc.id.lower()
    return requested in haystack


def _apply_channel_filter(query: str, result: RetrievalResult) -> RetrievalResult:
    """Prefer catalogue entries whose path/channel matches an explicit query channel."""
    if len(result.matches) <= 1:
        return result
    lowered = query.lower()
    requested: str | None = None
    if re.search(r"\bagency\b", lowered):
        requested = "agency"
    elif re.search(r"\bdsf\b", lowered):
        requested = "dsf"
    elif re.search(r"\baxis\b", lowered):
        requested = "axis"
    if not requested:
        return result

    filtered: list[RetrievalMatch] = [
        match for match in result.matches if _doc_matches_requested_channel(match.document, requested)
    ]
    if not filtered:
        return result

    return RetrievalResult(
        matches=filtered,
        query_understood_as=result.query_understood_as,
        raw_llm_response=result.raw_llm_response,
    )


def _compose_context(result: RetrievalResult) -> str:
    blocks: list[str] = []
    for idx, match in enumerate(result.matches, start=1):
        doc = match.document
        ctype = doc.catalogue_domain or "underwriting"
        ch = doc.underwriting_channel or "unspecified"
        blocks.append(
            f"Source {idx}: {match.document.title} | catalogue={ctype} | channel={ch}"
        )
        for slide in match.matched_slides:
            blocks.append(f"- Slide {slide.number}: {slide.title} | {slide.note}")
    return "\n".join(blocks).strip()


def run_query(
    *,
    provider: str,
    query: str,
    store: DocumentStore,
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    embeddings: Embeddings | None = None,
    embedding_shortlist: int = 0,
    selected_channel: str | None = None,
) -> FeatureAnswer:
    """Run underwriting retrieval and return UI-ready response."""
    working_store = store
    selected = (selected_channel or "").strip().lower()
    if selected:
        filtered_docs = [
            doc
            for doc in store.all()
            if (doc.underwriting_channel or "").strip().lower() == selected
        ]
        if filtered_docs:
            working_store = DocumentStore(filtered_docs)
        else:
            return FeatureAnswer(
                content=(
                    f"I could not find underwriting documents for channel '{selected_channel}'. "
                    "Please choose a different channel."
                ),
                used_context="",
                source_local_path="",
            )

    if provider == "azure":
        azure_cfg.validate()
        retriever = DocumentRetriever(
            store=working_store,
            azure_cfg=azure_cfg,
            ret_cfg=retriever_cfg,
            active_type="underwriting",
            selected_channel=selected_channel or "",
            abbreviation_guide=UNDERWRITING_ABBREVIATION_GUIDE,
        )
    else:
        openai_cfg.validate()
        retriever = OpenAIDocumentRetriever(
            model_name=openai_cfg.model_name,
            api_key=openai_cfg.api_key,
            store=working_store,
            ret_cfg=retriever_cfg,
            active_type="underwriting",
            selected_channel=selected_channel or "",
            abbreviation_guide=UNDERWRITING_ABBREVIATION_GUIDE,
        )

    effective_top_k = int(getattr(retriever_cfg, "top_k", 1) or 1)
    multi_intent = bool(re.search(r"\band\b|,|&", query.lower()))
    if multi_intent:
        retriever.ret_cfg.top_k = max(effective_top_k, 2)

    result = retriever.retrieve(
        query.strip(),
        embeddings=embeddings,
        embedding_shortlist=embedding_shortlist,
    )
    result = _apply_channel_filter(query, result)
    source_path = ""
    if result.best is not None:
        local_source = _resolve_local_source_path(result.best.document.url)
        if local_source is not None:
            source_path = str(local_source)
    llm_content = _build_dynamic_llm_reply(
        provider=provider,
        query=query,
        result=result,
        store=working_store,
        retriever_cfg=retriever_cfg,
        azure_cfg=azure_cfg,
        openai_cfg=openai_cfg,
        selected_channel=selected_channel,
    )
    sources_section = _build_sources_section(result)
    final_content = llm_content if not sources_section else f"{llm_content}\n\n{sources_section}"

    return FeatureAnswer(
        content=final_content,
        used_context=_compose_context(result),
        source_local_path=source_path,
    )

