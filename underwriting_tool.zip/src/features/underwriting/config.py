"""Configuration for underwriting feature."""

from __future__ import annotations

from pathlib import Path

from src.features.base import FeatureDefinition

UNDERWRITING_FEATURE = FeatureDefinition(
    key="underwriting",
    display_name="Underwriting",
    mode="catalogue",
    prompt_context=(
        "Domain focus: Insurance underwriting. Prefer policy rules, risk checks, "
        "eligibility criteria, underwriting guidelines, and exceptions."
    ),
    catalogue_paths=(Path("catelogue") / "underwriting.json",),
)

