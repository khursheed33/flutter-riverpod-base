"""Configuration for underwriting feature."""

from __future__ import annotations

from pathlib import Path

from src.features.base import FeatureDefinition

UNDERWRITING_FEATURE = FeatureDefinition(
    key="underwriting",
    display_name="Underwriting",
    mode="catalogue",
    prompt_context=(
        "Domain focus: Insurance underwriting. Prefer policy rules, risk checks, "
        "eligibility criteria, underwriting guidelines, and exceptions. "
        "The catalogue is local .txt slide extracts under the underwriting tree. "
        "Each entry may include catalogue type and underwriting channel (Axis, Agency, or DSF) "
        "when inferable from folder names—respect channel metadata when choosing documents."
    ),
    catalogue_paths=(Path("catelogue") / "underwriting",),
)

