"""Configuration for internet feature."""

from __future__ import annotations

import os

from src.features.base import FeatureDefinition


def _internet_websites() -> list[str]:
    """Load allowed internet websites from env or fallback defaults."""
    raw_sites = os.environ.get("INTERNET_WEBSITES", "").strip()
    if not raw_sites:
        return ["google.com"]
    return [site.strip().lower() for site in raw_sites.split(",") if site.strip()]


INTERNET_FEATURE = FeatureDefinition(
    key="internet",
    display_name="Internet",
    mode="internet",
    prompt_context=(
        "Domain focus: Web research assistant. Search the allowed websites, synthesize "
        "results, and answer with concise references."
    ),
    websites=_internet_websites(),
)

