"""LangGraph-based web search and answer synthesis."""

from __future__ import annotations

import json
import os
from dataclasses import dataclass
from typing import Any, TypedDict
from urllib import error as urlerror
from urllib.parse import urlparse
from urllib.request import Request, urlopen

from langchain_tavily import TavilySearch
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_ollama import ChatOllama
from langchain_openai import AzureChatOpenAI, ChatOpenAI
from langgraph.graph import END, START, StateGraph

from src.config.settings import AzureOpenAIConfig, OllamaConfig, OpenAIConfig, RetrieverConfig


@dataclass
class SearchReference:
    """One cited reference from web search."""

    title: str
    url: str
    snippet: str


@dataclass
class InternetSearchResult:
    """Final internet feature response."""

    answer: str
    query_understood_as: str
    references: list[SearchReference]


class _GraphState(TypedDict, total=False):
    query: str
    query_understood_as: str
    search_queries: list[dict[str, str]]
    web_results: list[dict[str, Any]]
    search_error: str
    answer: str


class InternetSearchAgent:
    """Agentic web search pipeline using Tavily + LangGraph."""

    def __init__(
        self,
        *,
        websites: list[str],
        provider: str,
        openai_cfg: OpenAIConfig,
        azure_cfg: AzureOpenAIConfig,
        ollama_cfg: OllamaConfig,
        ret_cfg: RetrieverConfig,
        max_results: int = 5,
    ) -> None:
        self.websites = self._normalize_websites(websites)
        self.max_results = max_results
        self._web_search_tool = self._build_search_tool()
        self._scoped_search_tool = self._build_search_tool(self._scoped_domains())
        self._llm = self._build_llm(provider, openai_cfg, azure_cfg, ollama_cfg, ret_cfg)
        self._graph = self._build_graph()

    @staticmethod
    def _normalize_site(site: str) -> str:
        """Normalize website input into bare domain form for Tavily filtering."""
        value = site.strip().lower()
        if not value:
            return ""
        if "://" not in value:
            value = f"https://{value}"
        parsed = urlparse(value)
        domain = parsed.netloc.strip().lower() or parsed.path.strip().lower()
        return domain.strip("/")

    @classmethod
    def _normalize_websites(cls, websites: list[str]) -> list[str]:
        """Normalize and de-duplicate configured websites while preserving order."""
        normalized: list[str] = []
        seen: set[str] = set()
        for site in websites:
            domain = cls._normalize_site(site)
            if not domain or domain in seen:
                continue
            seen.add(domain)
            normalized.append(domain)
        return normalized

    def run(self, query: str) -> InternetSearchResult:
        """Search allowed websites and return summarized answer with references."""
        state = self._graph.invoke({"query": query.strip()})
        raw_refs = state.get("web_results", [])
        refs = [
            SearchReference(
                title=str(item.get("title", "")).strip() or "Untitled result",
                url=str(item.get("url", "")).strip(),
                snippet=str(item.get("content", "")).strip(),
            )
            for item in raw_refs
            if str(item.get("url", "")).strip()
        ]
        return InternetSearchResult(
            answer=str(state.get("answer", "")).strip(),
            query_understood_as=str(state.get("query_understood_as", "")).strip() or query.strip(),
            references=refs,
        )

    def _build_llm(
        self,
        provider: str,
        openai_cfg: OpenAIConfig,
        azure_cfg: AzureOpenAIConfig,
        ollama_cfg: OllamaConfig,
        ret_cfg: RetrieverConfig,
    ) -> ChatOpenAI | AzureChatOpenAI | ChatOllama:
        if provider == "azure":
            azure_cfg.validate()
            return AzureChatOpenAI(
                azure_endpoint=azure_cfg.endpoint,
                azure_deployment=azure_cfg.deployment_name,
                api_version=azure_cfg.api_version,
                api_key=azure_cfg.api_key,
                temperature=ret_cfg.temperature,
                max_tokens=ret_cfg.max_tokens,
            )

        if provider == "openai":
            openai_cfg.validate()
            return ChatOpenAI(
                model=openai_cfg.model_name,
                api_key=openai_cfg.api_key,
                temperature=ret_cfg.temperature,
                max_tokens=ret_cfg.max_tokens,
            )

        ollama_cfg.validate()
        return ChatOllama(
            model=ollama_cfg.model_name,
            base_url=ollama_cfg.base_url,
            temperature=ret_cfg.temperature,
            num_predict=ret_cfg.max_tokens,
            streaming=ollama_cfg.stream or True,
        )

    def _build_graph(self):
        graph = StateGraph(_GraphState)
        graph.add_node("plan_search", self._plan_search)
        graph.add_node("search_web", self._search_web)
        graph.add_node("summarize", self._summarize)
        graph.add_edge(START, "plan_search")
        graph.add_edge("plan_search", "search_web")
        graph.add_edge("search_web", "summarize")
        graph.add_edge("summarize", END)
        return graph.compile()

    def _scoped_domains(self) -> list[str]:
        """Return non-Google domains to be searched in domain-scoped mode."""
        google_aliases = {"google.com", "www.google.com"}
        return [site for site in self.websites if site.lower() not in google_aliases]

    def _build_search_tool(self, include_domains: list[str] | None = None) -> TavilySearch:
        """Create Tavily tool with optional domain scope."""
        kwargs: dict[str, Any] = {
            "max_results": self.max_results,
            "include_raw_content": False,
            "include_answer": False,
        }
        if include_domains:
            kwargs["include_domains"] = include_domains
        return TavilySearch(**kwargs)

    def _direct_tavily_search(
        self,
        *,
        query: str,
        mode: str,
    ) -> tuple[list[dict[str, Any]], str]:
        """
        Execute a direct Tavily HTTP call as a fallback path.

        Returns a pair of (results, error_message). `error_message` is empty
        when the call succeeds.
        """
        api_key = os.environ.get("TAVILY_API_KEY", "").strip()
        if not api_key:
            return [], "TAVILY_API_KEY is not set."

        payload: dict[str, Any] = {
            "api_key": api_key,
            "query": query,
            "max_results": self.max_results,
            "include_answer": False,
            "include_raw_content": False,
        }
        if mode == "scoped":
            domains = self._scoped_domains()
            if domains:
                payload["include_domains"] = domains
        try:
            body = json.dumps(payload).encode("utf-8")
            request = Request(
                url="https://api.tavily.com/search",
                data=body,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urlopen(request, timeout=30) as response:
                data = json.loads(response.read().decode("utf-8"))
        except urlerror.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            return [], f"Direct Tavily HTTP {exc.code}: {detail[:300]}"
        except Exception as exc:  # noqa: BLE001
            return [], f"Direct Tavily request failed: {exc}"

        raw_results = data.get("results", [])
        if not isinstance(raw_results, list):
            return [], f"Direct Tavily returned invalid results type: {type(raw_results).__name__}"
        return [item for item in raw_results if isinstance(item, dict)], ""

    def _plan_search(self, state: _GraphState) -> _GraphState:
        """Build agentic search plan for scoped and broad web search."""
        query = str(state.get("query", "")).strip()
        if not query:
            raise ValueError("Query must not be empty.")

        scoped_domains = self._scoped_domains()
        has_google = any(site.lower() in {"google.com", "www.google.com"} for site in self.websites)
        search_queries: list[dict[str, str]] = []

        if scoped_domains:
            search_queries.append({"query": query, "mode": "scoped"})
        if has_google or not self.websites:
            search_queries.append({"query": query, "mode": "web"})

        if not search_queries:
            search_queries.append({"query": query, "mode": "web"})

        return {
            "query": query,
            "query_understood_as": query,
            "search_queries": search_queries,
        }

    def _search_web(self, state: _GraphState) -> _GraphState:
        query = str(state.get("query", "")).strip()
        if not query:
            raise ValueError("Query must not be empty.")

        results: list[dict[str, Any]] = []
        seen_urls: set[str] = set()
        errors: list[str] = []
        search_queries = state.get("search_queries", [])
        if not search_queries:
            search_queries = [{"query": query, "mode": "web"}]

        for search_item in search_queries:
            task_query = str(search_item.get("query", query)).strip()
            mode = str(search_item.get("mode", "web")).strip().lower()
            if not task_query:
                continue

            tool = self._scoped_search_tool if mode == "scoped" else self._web_search_tool
            try:
                raw_results = tool.invoke({"query": task_query})
            except Exception as exc:  # noqa: BLE001
                errors.append(f"{mode} search failed for '{task_query}': {exc}")
                continue

            # Backward/forward compatibility across langchain_tavily response shapes.
            if isinstance(raw_results, dict):
                candidate_results = raw_results.get("results", [])
            else:
                candidate_results = raw_results
            if not isinstance(candidate_results, list):
                errors.append(
                    f"{mode} search returned unsupported payload type: "
                    f"{type(raw_results).__name__}"
                )
                continue
            if not candidate_results:
                fallback_results, fallback_error = self._direct_tavily_search(
                    query=task_query,
                    mode=mode,
                )
                if fallback_results:
                    candidate_results = fallback_results
                elif fallback_error:
                    errors.append(fallback_error)
                else:
                    errors.append(f"{mode} search returned 0 results.")

            for item in candidate_results:
                if not isinstance(item, dict):
                    continue
                url = str(item.get("url", "")).strip()
                if not url or url in seen_urls:
                    continue
                seen_urls.add(url)
                results.append(item)
                if len(results) >= self.max_results:
                    break
            if len(results) >= self.max_results:
                break

        return {
            "query": query,
            "query_understood_as": str(state.get("query_understood_as", query)).strip() or query,
            "web_results": results,
            "search_error": " | ".join(errors[:3]),
        }

    def _summarize(self, state: _GraphState) -> _GraphState:
        query = str(state.get("query", "")).strip()
        results = state.get("web_results", [])
        if not results:
            search_error = str(state.get("search_error", "")).strip()
            if search_error:
                return {
                    "answer": (
                        "Web search failed before usable results were returned. "
                        f"Details: {search_error}"
                    ),
                }
            return {
                "answer": "I could not find useful web results for this query on the configured websites.",
            }

        context_lines: list[str] = []
        for idx, item in enumerate(results, start=1):
            title = str(item.get("title", "")).strip() or "Untitled"
            url = str(item.get("url", "")).strip()
            snippet = str(item.get("content", "")).strip()
            context_lines.append(
                f"[{idx}] Title: {title}\nURL: {url}\nSnippet: {snippet}"
            )

        prompt = (
            "You are an internet research assistant.\n"
            "Use only the provided search results to answer the user query.\n"
            "Provide a concise answer and do not fabricate facts."
        )
        response = self._llm.invoke(
            [
                SystemMessage(content=prompt),
                HumanMessage(
                    content=(
                        f"User query: {query}\n\n"
                        f"Search results:\n\n{chr(10).join(context_lines)}"
                    )
                ),
            ]
        )
        answer = getattr(response, "content", "")
        return {"answer": str(answer).strip()}

