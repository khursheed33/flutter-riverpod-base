"""Internet feature-specific query flow."""

from __future__ import annotations

from src.config.settings import AzureOpenAIConfig, OllamaConfig, OpenAIConfig, RetrieverConfig
from src.features.base import FeatureAnswer
from src.features.internet.search_agent import InternetSearchAgent


def run_query(
    *,
    provider: str,
    query: str,
    websites: list[str],
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
    max_results: int,
) -> FeatureAnswer:
    """Run internet search and return UI-ready response."""
    agent = InternetSearchAgent(
        websites=websites,
        provider=provider,
        openai_cfg=openai_cfg,
        azure_cfg=azure_cfg,
        ollama_cfg=ollama_cfg,
        ret_cfg=retriever_cfg,
        max_results=max_results,
    )
    result = agent.run(query.strip())
    lines = [result.answer]
    if result.references:
        lines.append("")
        for idx, ref in enumerate(result.references, start=1):
            label = ref.title or f"Source {idx}"
            lines.append(f"{idx}. [{label}]({ref.url})")
    used_context = "\n".join(
        [
            f"Source {idx}: {ref.title}\nURL: {ref.url}\n{ref.snippet}"
            for idx, ref in enumerate(result.references, start=1)
        ]
    )
    return FeatureAnswer(content="\n".join(lines).strip(), used_context=used_context)

