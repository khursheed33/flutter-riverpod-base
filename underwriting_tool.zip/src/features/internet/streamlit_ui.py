"""Internet-specific Streamlit UI helpers."""

from __future__ import annotations

CHAT_PLACEHOLDER = "Ask internet research questions..."
FEATURE_DESCRIPTION = (
    "Search configured websites and summarize web evidence with references."
)

