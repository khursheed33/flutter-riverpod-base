"""Shared feature definitions."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Literal

FeatureMode = Literal["catalogue", "internet"]


@dataclass(frozen=True)
class FeatureDefinition:
    """Runtime configuration for one active feature type."""

    key: str
    display_name: str
    mode: FeatureMode
    prompt_context: str
    catalogue_paths: tuple[Path, ...] = ()
    websites: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class FeatureAnswer:
    """Unified feature response contract for UI/CLI layers."""

    content: str
    used_context: str = ""
    source_local_path: str = ""
    confidence: float | None = None
    source_paths: tuple[str, ...] = ()

