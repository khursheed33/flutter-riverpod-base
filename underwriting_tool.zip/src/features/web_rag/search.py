"""Vector search and answer synthesis for web_rag feature."""

from __future__ import annotations

from typing import List
from urllib.parse import urlparse, urlunparse

from langchain_core.embeddings import Embeddings
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_ollama import ChatOllama, OllamaEmbeddings
from langchain_postgres import PGVector
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings, ChatOpenAI, OpenAIEmbeddings

from src.config.settings import AzureOpenAIConfig, OllamaConfig, OpenAIConfig, RetrieverConfig
from src.features.base import FeatureAnswer
from src.features.web_rag.db import WebRagDbConfig
from src.features.web_rag.ingestion import WEB_RAG_COLLECTION_NAME


def _canonical_reference_url(url: str) -> str:
    """
    Normalize URL for stable reference de-duplication.

    - lowercase scheme/host
    - drop query/fragment
    - strip trailing slash except root
    """
    value = url.strip()
    if not value:
        return ""
    parsed = urlparse(value if "://" in value else f"https://{value}")
    scheme = (parsed.scheme or "https").lower()
    netloc = parsed.netloc.lower()
    path = (parsed.path or "").rstrip("/")
    normalized_path = path if path else "/"
    return urlunparse((scheme, netloc, normalized_path, "", "", ""))


def _build_llm(
    provider: str,
    openai_cfg: OpenAIConfig,
    azure_cfg: AzureOpenAIConfig,
    ollama_cfg: OllamaConfig,
    ret_cfg: RetrieverConfig,
) -> BaseChatModel:
    if provider == "azure":
        azure_cfg.validate()
        return AzureChatOpenAI(
            azure_endpoint=azure_cfg.endpoint,
            azure_deployment=azure_cfg.deployment_name,
            api_version=azure_cfg.api_version,
            api_key=azure_cfg.api_key,
            temperature=ret_cfg.temperature,
            max_tokens=ret_cfg.max_tokens,
        )

    if provider == "openai":
        openai_cfg.validate()
        return ChatOpenAI(
            model=openai_cfg.model_name,
            api_key=openai_cfg.api_key,
            temperature=ret_cfg.temperature,
            max_tokens=ret_cfg.max_tokens,
        )
    ollama_cfg.validate()
    return ChatOllama(
        model=ollama_cfg.model_name,
        base_url=ollama_cfg.base_url,
        temperature=ret_cfg.temperature,
        num_predict=ret_cfg.max_tokens,
        streaming=ollama_cfg.stream,
    )


def _build_embeddings(
    *,
    provider: str,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
) -> Embeddings:
    if provider == "azure":
        azure_cfg.validate()
        deployment = azure_cfg.embedding_deployment_name.strip() or azure_cfg.deployment_name
        return AzureOpenAIEmbeddings(
            azure_endpoint=azure_cfg.endpoint.rstrip("/"),
            azure_deployment=deployment,
            openai_api_version=azure_cfg.api_version,
            openai_api_key=azure_cfg.api_key,
        )
    if provider == "openai":
        openai_cfg.validate()
        return OpenAIEmbeddings(
            model=openai_cfg.embedding_model_name,
            api_key=openai_cfg.api_key,
        )
    ollama_cfg.validate()
    return OllamaEmbeddings(
        model=ollama_cfg.embedding_model_name,
        base_url=ollama_cfg.base_url,
    )


def _build_vector_store(
    db_cfg: WebRagDbConfig,
    *,
    provider: str,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
) -> PGVector:
    embeddings = _build_embeddings(
        provider=provider,
        azure_cfg=azure_cfg,
        openai_cfg=openai_cfg,
        ollama_cfg=ollama_cfg,
    )
    connection = (
        f"postgresql+psycopg://{db_cfg.user}:{db_cfg.password}"
        f"@{db_cfg.host}:{db_cfg.port}/{db_cfg.dbname}"
    )
    return PGVector(
        embeddings=embeddings,
        collection_name=WEB_RAG_COLLECTION_NAME,
        connection=connection,
        use_jsonb=True,
    )


def _compose_answer(query: str, docs: List, llm: BaseChatModel) -> FeatureAnswer:
    if not docs:
        return FeatureAnswer(
            content=(
                "I could not find relevant indexed web content for this question. "
                "Try broadening the query or ensure the configured domains have been ingested."
            ),
            used_context="",
            source_local_path="",
        )

    context_lines: list[str] = []
    references: list[str] = []
    seen_references: set[str] = set()
    for idx, (doc, score) in enumerate(docs, start=1):
        url = str(getattr(doc, "metadata", {}).get("url", "")).strip()
        snippet = str(getattr(doc, "page_content", "")).strip()
        context_lines.append(
            f"[{idx}] URL: {url or 'Unknown'}\nScore: {score:.4f}\nSnippet: {snippet}"
        )
        canonical_url = _canonical_reference_url(url)
        if canonical_url and canonical_url not in seen_references:
            seen_references.add(canonical_url)
            references.append(canonical_url)

    system_prompt = (
        "You are a retrieval-augmented assistant. Use ONLY the provided indexed web "
        "snippets to answer the user question. Be concise, avoid speculation, and "
        "cite concrete pages when relevant."
    )
    response = llm.invoke(
        [
            SystemMessage(content=system_prompt),
            HumanMessage(
                content=(
                    f"User query: {query}\n\n"
                    f"Indexed web snippets:\n\n"
                    f"{chr(10).join(context_lines)}"
                )
            ),
        ]
    )
    answer_text = str(getattr(response, "content", "")).strip()

    ref_lines = [f"{idx}. {url}" for idx, url in enumerate(references, start=1)]
    full_answer = answer_text
    if ref_lines:
        full_answer = f"{answer_text}\n\n### References\n" + "\n".join(ref_lines)

    used_context = "\n\n".join(context_lines)
    return FeatureAnswer(content=full_answer, used_context=used_context, source_local_path="")


def search_web_rag(
    *,
    provider: str,
    query: str,
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
    db_cfg: WebRagDbConfig | None = None,
) -> FeatureAnswer:
    """Run similarity search over pgvector-backed chunks and synthesize an answer."""
    db_cfg = db_cfg or WebRagDbConfig()
    cleaned_query = query.strip()
    if not cleaned_query:
        return FeatureAnswer(
            content="No query provided. Web content was ingested, but search was skipped.",
            used_context="",
            source_local_path="",
        )
    store = _build_vector_store(
        db_cfg,
        provider=provider,
        azure_cfg=azure_cfg,
        openai_cfg=openai_cfg,
        ollama_cfg=ollama_cfg,
    )
    llm = _build_llm(provider, openai_cfg, azure_cfg, ollama_cfg, retriever_cfg)

    k = max(1, retriever_cfg.top_k)
    results = store.similarity_search_with_score(cleaned_query, k=k)
    return _compose_answer(cleaned_query, results, llm)

