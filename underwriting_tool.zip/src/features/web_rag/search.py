"""Vector search and answer synthesis for web_rag feature."""

from __future__ import annotations

from typing import List

from langchain_community.vectorstores.pgvector import PGVector
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_openai import AzureChatOpenAI, ChatOpenAI, OpenAIEmbeddings

from src.config.settings import AzureOpenAIConfig, OpenAIConfig, RetrieverConfig, openai_config
from src.features.base import FeatureAnswer
from src.features.web_rag.db import WebRagDbConfig


def _build_llm(
    provider: str,
    openai_cfg: OpenAIConfig,
    azure_cfg: AzureOpenAIConfig,
    ret_cfg: RetrieverConfig,
) -> ChatOpenAI | AzureChatOpenAI:
    if provider == "azure":
        azure_cfg.validate()
        return AzureChatOpenAI(
            azure_endpoint=azure_cfg.endpoint,
            azure_deployment=azure_cfg.deployment_name,
            api_version=azure_cfg.api_version,
            api_key=azure_cfg.api_key,
            temperature=ret_cfg.temperature,
            max_tokens=ret_cfg.max_tokens,
        )

    openai_cfg.validate()
    return ChatOpenAI(
        model=openai_cfg.model_name,
        api_key=openai_cfg.api_key,
        temperature=ret_cfg.temperature,
        max_tokens=ret_cfg.max_tokens,
    )


def _build_vector_store(db_cfg: WebRagDbConfig) -> PGVector:
    openai_config.validate()
    embeddings = OpenAIEmbeddings(
        model=openai_config.embedding_model_name,
        api_key=openai_config.api_key,
    )
    connection_string = (
        f"postgresql+psycopg://{db_cfg.user}:{db_cfg.password}"
        f"@{db_cfg.host}:{db_cfg.port}/{db_cfg.dbname}"
    )
    return PGVector(
        connection_string=connection_string,
        embedding_function=embeddings,
        collection_name="web_rag_embeddings",
    )


def _compose_answer(query: str, docs: List, llm: ChatOpenAI | AzureChatOpenAI) -> FeatureAnswer:
    if not docs:
        return FeatureAnswer(
            content=(
                "I could not find relevant indexed web content for this question. "
                "Try broadening the query or ensure the configured domains have been ingested."
            ),
            used_context="",
            source_local_path="",
        )

    context_lines: list[str] = []
    references: list[str] = []
    for idx, (doc, score) in enumerate(docs, start=1):
        url = str(getattr(doc, "metadata", {}).get("url", "")).strip()
        snippet = str(getattr(doc, "page_content", "")).strip()
        context_lines.append(
            f"[{idx}] URL: {url or 'Unknown'}\nScore: {score:.4f}\nSnippet: {snippet}"
        )
        if url:
            references.append(url)

    system_prompt = (
        "You are a retrieval-augmented assistant. Use ONLY the provided indexed web "
        "snippets to answer the user question. Be concise, avoid speculation, and "
        "cite concrete pages when relevant."
    )
    response = llm.invoke(
        [
            SystemMessage(content=system_prompt),
            HumanMessage(
                content=(
                    f"User query: {query}\n\n"
                    f"Indexed web snippets:\n\n"
                    f"{chr(10).join(context_lines)}"
                )
            ),
        ]
    )
    answer_text = str(getattr(response, "content", "")).strip()

    ref_lines = [f"{idx}. {url}" for idx, url in enumerate(references, start=1)]
    full_answer = answer_text
    if ref_lines:
        full_answer = f"{answer_text}\n\n### References\n" + "\n".join(ref_lines)

    used_context = "\n\n".join(context_lines)
    return FeatureAnswer(content=full_answer, used_context=used_context, source_local_path="")


def search_web_rag(
    *,
    provider: str,
    query: str,
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    db_cfg: WebRagDbConfig | None = None,
) -> FeatureAnswer:
    """Run similarity search over pgvector-backed chunks and synthesize an answer."""
    db_cfg = db_cfg or WebRagDbConfig()
    store = _build_vector_store(db_cfg)
    llm = _build_llm(provider, openai_cfg, azure_cfg, retriever_cfg)

    k = max(1, retriever_cfg.top_k)
    results = store.similarity_search_with_score(query.strip(), k=k)
    return _compose_answer(query.strip(), results, llm)

