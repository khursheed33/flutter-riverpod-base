"""Split underwriting PPT slides and digital transcript segments into text files."""

from __future__ import annotations

import json
import re
import shutil
from pathlib import Path
from typing import Iterable

from pptx import Presentation
from striprtf.striprtf import rtf_to_text


ROOT_DIR = Path(__file__).resolve().parents[3]
DOCS_DIR = ROOT_DIR / "docs"
UNDERWRITING_DIR = DOCS_DIR / "Underwriting"
DIGITAL_RTF_PATH = DOCS_DIR / "Digital" / "digital_tools_transcription.txt.rtf"
CATELOGUE_DIGITAL_DIR = ROOT_DIR / "catelogue" / "digital" / "segments"
CATELOGUE_UNDERWRITING_DIR = ROOT_DIR / "catelogue" / "underwriting"


def slugify(value: str) -> str:
    """Return a filename-safe slug."""
    normalized = re.sub(r"[^A-Za-z0-9]+", "_", value.strip())
    compact = re.sub(r"_+", "_", normalized).strip("_")
    return compact[:80] if compact else "untitled"


def parse_timestamp(raw: str) -> int:
    """Convert mm:ss or hh:mm:ss into total seconds."""
    parts = [int(part) for part in raw.split(":")]
    if len(parts) == 2:
        minutes, seconds = parts
        return minutes * 60 + seconds
    if len(parts) == 3:
        hours, minutes, seconds = parts
        return hours * 3600 + minutes * 60 + seconds
    raise ValueError(f"Invalid timestamp: {raw}")


def format_timestamp(total_seconds: int) -> str:
    """Format total seconds as HH-MM-SS for filenames."""
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    seconds = total_seconds % 60
    return f"{hours:02d}-{minutes:02d}-{seconds:02d}"


def extract_slide_text(slide) -> str:
    """Extract visible slide text and notes for a single slide."""
    chunks: list[str] = []
    for shape in slide.shapes:
        if not getattr(shape, "has_text_frame", False):
            continue
        value = shape.text.strip()
        if value:
            chunks.append(value)

    notes_slide = getattr(slide, "notes_slide", None)
    if notes_slide and notes_slide.notes_text_frame:
        notes = notes_slide.notes_text_frame.text.strip()
        if notes:
            chunks.append("Notes:\n" + notes)

    return "\n\n".join(chunks).strip()


def split_underwriting_ppts() -> list[Path]:
    """Create one text file per underwriting slide."""
    outputs: list[Path] = []
    ppt_paths = sorted(UNDERWRITING_DIR.rglob("*.pptx"))
    for ppt_path in ppt_paths:
        presentation = Presentation(str(ppt_path))
        deck_slug = slugify(ppt_path.stem)
        rel_under = ppt_path.parent.relative_to(UNDERWRITING_DIR)
        output_dir = CATELOGUE_UNDERWRITING_DIR / rel_under / f"{deck_slug}__slides_txt"
        output_dir.mkdir(parents=True, exist_ok=True)

        for idx, slide in enumerate(presentation.slides, start=1):
            slide_text = extract_slide_text(slide)
            if not slide_text:
                slide_text = "[No text detected on this slide.]"

            first_line = slide_text.splitlines()[0].strip()
            title_slug = slugify(first_line)[:60]
            file_name = f"{deck_slug}__slide_{idx:02d}__{title_slug}.txt"
            output_path = output_dir / file_name
            output_path.write_text(
                (
                    f"Deck: {ppt_path.name}\n"
                    f"Slide: {idx}\n"
                    f"Title Hint: {first_line}\n\n"
                    f"{slide_text}\n"
                ),
                encoding="utf-8",
            )
            outputs.append(output_path)
    return outputs


def iter_clean_lines(raw_text: str) -> Iterable[str]:
    """Yield cleaned non-empty transcript lines."""
    for line in raw_text.splitlines():
        clean = line.strip()
        if not clean:
            continue
        if clean == "---" or clean == "----":
            continue
        yield clean


def _merge_txt_tree(src_root: Path, dest_root: Path) -> int:
    """Move every ``.txt`` under *src_root* into *dest_root*, preserving relative paths."""
    moved = 0
    for path in sorted(src_root.rglob("*.txt")):
        if not path.is_file():
            continue
        rel = path.relative_to(src_root)
        dest = dest_root / rel
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(path), str(dest))
        moved += 1
    return moved


def migrate_legacy_catalogue_txt() -> dict[str, int]:
    """
    Move legacy catalogue trees from ``docs/`` into ``catelogue/`` with the same layout.

    Digital: ``docs/Digital/segments_txt/`` → ``catelogue/digital/segments_txt/`` (entire
    folder when possible, otherwise merge ``.txt`` files only).

    Underwriting: each ``*__slides_txt`` directory under ``docs/Underwriting/`` is moved
    to the same relative path under ``catelogue/underwriting/``.

    Returns counts of ``.txt`` files now under each destination root (after the move).
    """
    counts = {"digital": 0, "underwriting": 0}
    dest_digital_root = ROOT_DIR / "catelogue" / "digital"
    legacy_digital = DOCS_DIR / "Digital" / "segments_txt"

    if legacy_digital.is_dir():
        dest_digital_root.mkdir(parents=True, exist_ok=True)
        target_tree = dest_digital_root / legacy_digital.name
        if target_tree.exists():
            counts["digital"] += _merge_txt_tree(legacy_digital, target_tree)
            try:
                shutil.rmtree(legacy_digital, ignore_errors=True)
            except OSError:
                pass
        else:
            shutil.move(str(legacy_digital), str(target_tree))
            counts["digital"] += sum(1 for _ in target_tree.rglob("*.txt") if _.is_file())

    legacy_uw_root = DOCS_DIR / "Underwriting"
    if legacy_uw_root.is_dir():
        CATELOGUE_UNDERWRITING_DIR.mkdir(parents=True, exist_ok=True)
        for slides_dir in sorted(legacy_uw_root.rglob("*__slides_txt")):
            if not slides_dir.is_dir():
                continue
            rel = slides_dir.relative_to(legacy_uw_root)
            dest_dir = CATELOGUE_UNDERWRITING_DIR / rel
            dest_dir.parent.mkdir(parents=True, exist_ok=True)
            if dest_dir.exists():
                counts["underwriting"] += _merge_txt_tree(slides_dir, dest_dir)
                try:
                    shutil.rmtree(slides_dir, ignore_errors=True)
                except OSError:
                    pass
            else:
                shutil.move(str(slides_dir), str(dest_dir))
                counts["underwriting"] += sum(1 for _ in dest_dir.rglob("*.txt") if _.is_file())

    return counts


def split_digital_transcript() -> list[Path]:
    """Create one timestamped text file per digital transcript segment."""
    plain_text = rtf_to_text(DIGITAL_RTF_PATH.read_text(encoding="utf-8", errors="ignore"))
    lines = list(iter_clean_lines(plain_text))

    timestamp_pattern = re.compile(r"^\d{1,2}:\d{2}(?::\d{2})?$")
    sections: dict[str, list[tuple[int, str]]] = {}
    current_section = "digital_tools"
    current_timestamp: int | None = None

    section_header_pattern = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 -]{0,50}$")

    i = 0
    while i < len(lines):
        line = lines[i]
        if timestamp_pattern.match(line):
            current_timestamp = parse_timestamp(line)
            i += 1
            continue

        next_line = lines[i + 1] if i + 1 < len(lines) else ""
        is_header = (
            timestamp_pattern.match(next_line)
            and section_header_pattern.match(line)
            and len(line.split()) <= 8
            and not line.endswith(".")
        )
        if is_header:
            current_section = line
            sections.setdefault(current_section, [])
            current_timestamp = None
            i += 1
            continue

        if current_timestamp is not None:
            sections.setdefault(current_section, []).append((current_timestamp, line))
        i += 1

    output_paths: list[Path] = []
    output_base = CATELOGUE_DIGITAL_DIR
    output_base.mkdir(parents=True, exist_ok=True)

    for section, items in sections.items():
        if not items:
            continue
        section_slug = slugify(section)
        section_dir = output_base / section_slug
        section_dir.mkdir(parents=True, exist_ok=True)

        for idx, (start_seconds, text) in enumerate(items, start=1):
            if idx < len(items):
                end_seconds = items[idx][0]
            else:
                end_seconds = start_seconds

            start_label = format_timestamp(start_seconds)
            end_label = format_timestamp(end_seconds)
            title_slug = slugify(text)[:55]
            filename = (
                f"{section_slug}__segment_{idx:03d}__"
                f"{start_label}__to__{end_label}__{title_slug}.txt"
            )
            output_path = section_dir / filename
            output_path.write_text(
                (
                    f"Section: {section}\n"
                    f"Segment: {idx}\n"
                    f"Start Timestamp: {start_seconds} sec\n"
                    f"End Timestamp: {end_seconds} sec\n\n"
                    f"{text}\n"
                ),
                encoding="utf-8",
            )
            output_paths.append(output_path)

    return output_paths


def main() -> None:
    """Run both splitters and print a compact summary."""
    migrate_legacy_catalogue_txt()
    underwriting_outputs = split_underwriting_ppts()
    digital_outputs = split_digital_transcript()
    summary = {
        "underwriting_files_created": len(underwriting_outputs),
        "digital_files_created": len(digital_outputs),
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    import sys

    if "--migrate-only" in sys.argv:
        print(json.dumps(migrate_legacy_catalogue_txt(), indent=2))
    else:
        main()
