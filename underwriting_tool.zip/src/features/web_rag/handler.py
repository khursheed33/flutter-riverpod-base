"""Web RAG feature-specific flow: ingestion + vector search."""

from __future__ import annotations

from typing import Iterable

from src.config.settings import AzureOpenAIConfig, OpenAIConfig, RetrieverConfig
from src.features.base import FeatureAnswer
from src.features.web_rag.db import WebRagDbConfig
from src.features.web_rag.ingestion import ingest_urls
from src.features.web_rag.search import search_web_rag


def _normalize_websites(websites: Iterable[str]) -> list[str]:
    normalized: list[str] = []
    seen: set[str] = set()
    for site in websites:
        value = site.strip()
        if not value or value in seen:
            continue
        seen.add(value)
        normalized.append(value)
    return normalized


def run_query(
    *,
    provider: str,
    query: str,
    websites: list[str],
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
) -> FeatureAnswer:
    """
    Entry point for web_rag feature.

    Behaviour:
    - Use the configured domains (and explicit URLs) as ingestion sources.
    - Scrape and index pages into Postgres/pgvector when content has changed.
    - Run similarity search over the indexed chunks and synthesize an answer
      with clear references.
    """
    db_cfg = WebRagDbConfig()
    sources = _normalize_websites(websites)
    if sources:
        ingest_urls(sources, db_cfg=db_cfg)
    return search_web_rag(
        provider=provider,
        query=query,
        retriever_cfg=retriever_cfg,
        azure_cfg=azure_cfg,
        openai_cfg=openai_cfg,
        db_cfg=db_cfg,
    )

