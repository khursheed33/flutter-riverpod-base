"""Web RAG feature-specific flow: ingestion + vector search."""

from __future__ import annotations

from typing import Iterable

from src.config.settings import AzureOpenAIConfig, OllamaConfig, OpenAIConfig, RetrieverConfig
from src.features.base import FeatureAnswer
from src.features.web_rag.db import WebRagDbConfig
from src.features.web_rag.ingestion import IngestionStats, ingest_urls
from src.features.web_rag.search import search_web_rag


def _normalize_websites(websites: Iterable[str]) -> list[str]:
    normalized: list[str] = []
    seen: set[str] = set()
    for site in websites:
        value = site.strip()
        if not value or value in seen:
            continue
        seen.add(value)
        normalized.append(value)
    return normalized


def run_query(
    *,
    provider: str,
    query: str,
    websites: list[str],
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
    chunk_size: int | None = None,
    chunk_overlap: int | None = None,
) -> FeatureAnswer:
    """
    Entry point for web_rag feature.

    Behaviour:
    - If query is empty, ingest configured domains into Postgres/pgvector.
    - If query is non-empty, run similarity search over indexed chunks.
    - Use the selected provider settings for embeddings and chat.
    """
    db_cfg = WebRagDbConfig()
    sources = _normalize_websites(websites)
    stats = IngestionStats()
    cleaned_query = query.strip()
    should_ingest = cleaned_query == ""
    if should_ingest and sources:
        stats = ingest_urls(
            sources,
            provider=provider,
            openai_cfg=openai_cfg,
            azure_cfg=azure_cfg,
            ollama_cfg=ollama_cfg,
            db_cfg=db_cfg,
            chunk_size=chunk_size,
            chunk_overlap=chunk_overlap,
        )

    if not cleaned_query:
        return FeatureAnswer(
            content=(
                "Web RAG ingestion completed.\n\n"
                f"- Roots attempted: {stats.roots_attempted}\n"
                f"- Pages crawled: {stats.pages_crawled}\n"
                f"- Pages indexed/updated: {stats.pages_indexed}\n"
                f"- Chunks embedded: {stats.chunks_indexed}\n"
                f"- Unchanged pages skipped: {stats.unchanged_pages}"
            ),
            used_context="",
            source_local_path="",
        )

    return search_web_rag(
        provider=provider,
        query=cleaned_query,
        retriever_cfg=retriever_cfg,
        azure_cfg=azure_cfg,
        openai_cfg=openai_cfg,
        ollama_cfg=ollama_cfg,
        db_cfg=db_cfg,
    )

