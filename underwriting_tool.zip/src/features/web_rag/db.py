"""Lightweight Postgres/pgvector helpers for the web_rag feature.

All DB-related logic is deliberately scoped to this feature module so other
features remain decoupled.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

import psycopg


@dataclass(frozen=True)
class WebRagDbConfig:
    """Database connection settings for web_rag feature."""

    host: str = os.environ.get("WEB_RAG_PG_HOST", "localhost")
    port: int = int(os.environ.get("WEB_RAG_PG_PORT", "5433"))
    dbname: str = os.environ.get("WEB_RAG_PG_DB", "postgres")
    user: str = os.environ.get("WEB_RAG_PG_USER", "postgres")
    password: str = os.environ.get("WEB_RAG_PG_PASSWORD", "root")

    def dsn(self) -> str:
        return (
            f"host={self.host} port={self.port} dbname={self.dbname} "
            f"user={self.user} password={self.password}"
        )


def get_connection(cfg: WebRagDbConfig | None = None) -> psycopg.Connection:
    """Create a new psycopg connection for short-lived operations."""
    cfg = cfg or WebRagDbConfig()
    return psycopg.connect(cfg.dsn())


def ensure_schema(conn: psycopg.Connection) -> None:
    """Create minimal tables required for web_rag if they do not exist."""
    with conn.cursor() as cur:
        # Store raw page content and checksum per URL.
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS web_rag_pages (
                id SERIAL PRIMARY KEY,
                url TEXT UNIQUE NOT NULL,
                domain TEXT NOT NULL,
                checksum TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TIMESTAMPTZ DEFAULT NOW()
            );
            """
        )
        # Vector-backed chunks. The embedding column relies on the pgvector
        # extension being enabled in the target database.
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS web_rag_chunks (
                id SERIAL PRIMARY KEY,
                page_id INTEGER NOT NULL REFERENCES web_rag_pages(id) ON DELETE CASCADE,
                chunk_index INTEGER NOT NULL,
                content TEXT NOT NULL
            );
            """
        )
    conn.commit()

