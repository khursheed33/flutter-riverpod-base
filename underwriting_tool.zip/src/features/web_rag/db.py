"""Lightweight Postgres/pgvector helpers for the web_rag feature.

All DB-related logic is deliberately scoped to this feature module so other
features remain decoupled.
"""

from __future__ import annotations

import os
from dataclasses import dataclass

import psycopg


@dataclass(frozen=True)
class WebRagDbConfig:
    """Database connection settings for web_rag feature."""

    host: str = os.environ.get("WEB_RAG_PG_HOST", "localhost")
    port: int = int(os.environ.get("WEB_RAG_PG_PORT", "5433"))
    dbname: str = os.environ.get("WEB_RAG_PG_DB", "postgres")
    user: str = os.environ.get("WEB_RAG_PG_USER", "postgres")
    password: str = os.environ.get("WEB_RAG_PG_PASSWORD", "root")

    def dsn(self) -> str:
        return (
            f"host={self.host} port={self.port} dbname={self.dbname} "
            f"user={self.user} password={self.password}"
        )


def get_connection(cfg: WebRagDbConfig | None = None) -> psycopg.Connection:
    """Create a new psycopg connection for short-lived operations."""
    cfg = cfg or WebRagDbConfig()
    return psycopg.connect(cfg.dsn())


def ensure_schema(conn: psycopg.Connection) -> None:
    """Create minimal tables required for web_rag if they do not exist."""
    with conn.cursor() as cur:
        cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")
        # Store raw page content and metadata per URL.
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS web_rag_pages (
                id SERIAL PRIMARY KEY,
                url TEXT NOT NULL UNIQUE,
                domain TEXT NOT NULL DEFAULT '',
                title TEXT NOT NULL DEFAULT '',
                description TEXT NOT NULL DEFAULT '',
                keywords TEXT[] NOT NULL DEFAULT '{}',
                checksum TEXT NOT NULL,
                content TEXT NOT NULL,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            );
            """
        )

        # Extend existing installations with rich metadata columns.
        cur.execute(
            """
            ALTER TABLE web_rag_pages
            ADD COLUMN IF NOT EXISTS title TEXT NOT NULL DEFAULT '',
            ADD COLUMN IF NOT EXISTS description TEXT NOT NULL DEFAULT '',
            ADD COLUMN IF NOT EXISTS keywords TEXT[] NOT NULL DEFAULT '{}';
            """
        )
        cur.execute(
            """
            ALTER TABLE web_rag_pages
            ALTER COLUMN domain SET DEFAULT '';
            """
        )

        # Indexes for metadata filtering and title text search.
        cur.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_web_rag_pages_keywords
            ON web_rag_pages USING GIN (keywords);
            """
        )
        cur.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_web_rag_pages_title
            ON web_rag_pages USING GIN (to_tsvector('english', title));
            """
        )

        # web_rag search uses langchain_postgres tables for embeddings.
        # Remove legacy local chunk table if it exists from older versions.
        cur.execute(
            """
            DROP TABLE IF EXISTS web_rag_chunks CASCADE;
            """
        )
    conn.commit()

