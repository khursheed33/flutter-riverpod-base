"""Configuration for web RAG feature."""

from __future__ import annotations

import os

from src.features.base import FeatureDefinition


def _web_rag_websites() -> list[str]:
    """
    Load allowed websites for web_rag feature.

    We intentionally reuse INTERNET_WEBSITES so the same allowlist can power
    both the internet search feature and the web RAG crawler.
    """
    raw_sites = os.environ.get("INTERNET_WEBSITES", "").strip()
    if not raw_sites:
        return []
    return [site.strip().lower() for site in raw_sites.split(",") if site.strip()]


WEB_RAG_FEATURE = FeatureDefinition(
    key="web_rag",
    display_name="Web RAG",
    mode="internet",
    prompt_context=(
        "Domain focus: Retrieval‑augmented generation over pre‑crawled web content. "
        "Ingest configured domains into Postgres/pgvector, then answer using only "
        "those indexed pages with clear citations."
    ),
    websites=_web_rag_websites(),
)

