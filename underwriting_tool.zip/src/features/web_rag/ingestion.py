"""
Async BFS web crawler (Playwright) + pgvector ingestion.

Why Playwright instead of RecursiveUrlLoader:
- Executes JavaScript → sees nav menus, dropdowns, dynamically injected links
- Follows ALL anchor tags after rendering, not just static HTML hrefs
- Handles SPAs (React / Angular / Vue) correctly
- No server to run — just `pip install playwright && playwright install chromium`

Setup (one-time):
    pip install playwright beautifulsoup4 lxml python-dotenv \
                langchain-postgres langchain-openai langchain-ollama \
                langchain-community langchain-core langchain-text-splitters
    playwright install chromium
"""

from __future__ import annotations

import asyncio
import hashlib
import logging
import os
import re
from collections import Counter, deque
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from bs4 import BeautifulSoup
from dotenv import load_dotenv
from langchain_core.documents import Document
from langchain_core.embeddings import Embeddings
from langchain_ollama import OllamaEmbeddings
from langchain_openai import AzureOpenAIEmbeddings, OpenAIEmbeddings
from langchain_postgres import PGVector
from langchain_text_splitters import RecursiveCharacterTextSplitter
from playwright.async_api import Browser, BrowserContext, async_playwright

from src.config.settings import AzureOpenAIConfig, OllamaConfig, OpenAIConfig
from src.features.web_rag.db import WebRagDbConfig, ensure_schema, get_connection

# ---------------------------------------------------------------------------
# Bootstrap
# ---------------------------------------------------------------------------

load_dotenv()
logger = logging.getLogger(__name__)

WEB_RAG_COLLECTION_NAME = "web_rag_embeddings"

# Query parameters that explode crawl cardinality but rarely change page meaning.
_TRACKING_QUERY_KEYS = frozenset(
    {
        "utm_source",
        "utm_medium",
        "utm_campaign",
        "utm_term",
        "utm_content",
        "gclid",
        "fbclid",
        "ocpseqno",
        "source",
        "agentcode",
        "language",
        "categcd",
    }
)


class PlaywrightSessionLost(RuntimeError):
    """Raised when the Playwright driver/browser session is no longer usable."""


def _strip_tracking_query(parsed) -> str:
    """Return a cleaned query string with common tracking params removed."""
    pairs = [
        (k, v)
        for k, v in parse_qsl(parsed.query, keep_blank_values=True)
        if k.lower() not in _TRACKING_QUERY_KEYS
    ]
    return urlencode(pairs)

_STOP_WORDS: frozenset[str] = frozenset(
    {
        "a", "an", "and", "are", "as", "at", "be", "been", "but", "by",
        "do", "for", "from", "get", "had", "has", "have", "he", "her",
        "him", "his", "how", "i", "if", "in", "is", "it", "its", "just",
        "me", "more", "my", "no", "not", "of", "on", "or", "our", "out",
        "s", "she", "so", "that", "the", "their", "them", "then", "there",
        "they", "this", "to", "up", "us", "was", "we", "were", "what",
        "when", "where", "which", "who", "will", "with", "you", "your",
    }
)


def _status_file_path() -> Path:
    """Return the persistent ingestion status file path."""
    out_dir = Path(__file__).resolve().parents[3] / "docs" / "web"
    out_dir.mkdir(parents=True, exist_ok=True)
    return out_dir / "web_rag_ingestion_status.txt"


def _write_status(
    *,
    phase: str,
    roots: list[str],
    pages_crawled: int = 0,
    pages_indexed: int = 0,
    chunks_indexed: int = 0,
    unchanged_pages: int = 0,
    current_url: str = "",
    note: str = "",
) -> None:
    """Write human-readable ingestion progress so users can monitor long runs."""
    ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    lines = [
        f"updated_at_utc: {ts}",
        f"phase: {phase}",
        f"roots: {', '.join(roots) if roots else '-'}",
        f"pages_crawled: {pages_crawled}",
        f"pages_indexed: {pages_indexed}",
        f"chunks_indexed: {chunks_indexed}",
        f"unchanged_pages: {unchanged_pages}",
        f"current_url: {current_url or '-'}",
        f"note: {note or '-'}",
    ]
    _status_file_path().write_text("\n".join(lines) + "\n", encoding="utf-8")


def _ensure_windows_proactor_policy() -> None:
    """
    Ensure subprocess-capable asyncio policy on Windows.

    Playwright launches a driver process; on some Windows Python runtimes,
    Selector-based policies do not implement subprocess transports.
    """
    if os.name != "nt" or not hasattr(asyncio, "WindowsProactorEventLoopPolicy"):
        return
    current_policy = asyncio.get_event_loop_policy()
    if isinstance(current_policy, asyncio.WindowsProactorEventLoopPolicy):
        return
    asyncio.set_event_loop_policy(asyncio.WindowsProactorEventLoopPolicy())

# ---------------------------------------------------------------------------
# Env helpers
# ---------------------------------------------------------------------------

def _env_int(key: str, default: int) -> int:
    try:
        return int(os.environ.get(key, default))
    except (TypeError, ValueError):
        return default


def _env_bool(key: str, default: bool) -> bool:
    val = os.environ.get(key, "")
    if not val:
        return default
    return val.strip().lower() in {"1", "true", "yes", "on"}


def _env_float(key: str, default: float) -> float:
    try:
        return float(os.environ.get(key, default))
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class PageMeta:
    """All data extracted from a single crawled page."""
    url: str
    title: str
    description: str
    keywords: list[str]
    text: str


@dataclass(frozen=True)
class IngestionStats:
    roots_attempted: int = 0
    pages_crawled: int = 0
    pages_indexed: int = 0
    chunks_indexed: int = 0
    unchanged_pages: int = 0


# ---------------------------------------------------------------------------
# URL utilities
# ---------------------------------------------------------------------------

def _normalize_url(url: str) -> str:
    """Normalise URL: strip fragments, collapse slashes, lowercase scheme+host."""
    url = url.strip()
    if not url:
        return ""
    if "://" not in url:
        url = f"https://{url}"
    p = urlparse(url)
    path = re.sub(r"/+", "/", p.path).rstrip("/") or "/"
    cleaned_query = _strip_tracking_query(p)
    p = p._replace(
        fragment="",
        path=path,
        scheme=p.scheme.lower(),
        netloc=p.netloc.lower(),
        query=cleaned_query,
    )
    return urlunparse(p)


def _base_domain(url: str) -> str:
    """
    Registrable base domain — strips all subdomains.
    'docs.example.co.uk' → 'example.co.uk'
    'api.example.com'    → 'example.com'
    """
    host = urlparse(url).netloc.lower().split(":")[0] or url.lower()
    parts = host.split(".")
    double_tld = {"co.uk", "co.in", "com.au", "co.nz", "org.uk", "net.in"}
    if len(parts) >= 3 and ".".join(parts[-2:]) in double_tld:
        return ".".join(parts[-3:])
    return ".".join(parts[-2:]) if len(parts) >= 2 else host


def _in_scope(url: str, allowed_bases: set[str], allow_subdomains: bool) -> bool:
    host = urlparse(url).netloc.lower().split(":")[0]
    for ab in allowed_bases:
        if allow_subdomains:
            if host == ab or host.endswith(f".{ab}"):
                return True
        else:
            if host in {ab, f"www.{ab}"}:
                return True
    return False


_NON_TEXT_EXT = re.compile(
    r"\.(jpg|jpeg|png|gif|webp|svg|ico|bmp|pdf|mp4|webm|mp3|wav|ogg"
    r"|css|js|woff2?|ttf|eot|zip|rar|gz|tar|exe|dmg|apk)(\?.*)?$",
    re.I,
)


def _is_crawlable(url: str) -> bool:
    if not url.startswith("http"):
        return False
    lowered = url.lower()
    if lowered.startswith("javascript:") or lowered.startswith("mailto:") or lowered.startswith("tel:"):
        return False
    path = urlparse(url).path
    if _NON_TEXT_EXT.search(path):
        return False
    slug = re.sub(r"[\s()+\-]", "", path.strip("/"))
    if re.fullmatch(r"[0-9%]{7,}", slug):   # phone-number path
        return False
    return True


def _is_cdn_bot_wall(meta: PageMeta) -> bool:
    """
    Detect common CDN / WAF HTML shells served to automated clients.

    Real browsers may still see the full site while headless Chromium gets a
    short error page (Akamai Edge, etc.).
    """
    text = (meta.text or "").lower()
    title = (meta.title or "").lower()
    if "errors.edgesuite.net" in text:
        return True
    if "you don't have permission" in text and "on this server" in text:
        return True
    if "access denied" in title and "reference #" in text:
        return True
    if "request unsuccessful" in text and "incapsula" in text:
        return True
    return False


# ---------------------------------------------------------------------------
# HTML → PageMeta
# ---------------------------------------------------------------------------

def _extract_keywords_from_text(text: str, title: str = "", n: int = 10) -> list[str]:
    combined = f"{title} {text[:3000]}"
    tokens = re.findall(r"[a-zA-Z]{3,}", combined.lower())
    meaningful = [t for t in tokens if t not in _STOP_WORDS]
    return [w for w, _ in Counter(meaningful).most_common(n)]


def _html_to_page_meta(html: str, url: str) -> PageMeta:
    soup = BeautifulSoup(html, "lxml")

    # Title
    t = soup.find("title")
    title = t.get_text(strip=True) if t else ""

    # Meta description
    d = (soup.find("meta", attrs={"name": re.compile(r"^description$", re.I)})
         or soup.find("meta", attrs={"property": "og:description"}))
    description = (d.get("content", "") if d else "").strip()

    # Meta keywords
    k = soup.find("meta", attrs={"name": re.compile(r"^keywords$", re.I)})
    raw_kw = (k.get("content", "") if k else "").strip()
    keywords = [x.strip() for x in raw_kw.split(",") if x.strip()]

    # Clean text
    for tag in soup(["script", "style", "noscript", "svg"]):
        tag.decompose()
    text = re.sub(r"\n{3,}", "\n\n", soup.get_text(separator="\n", strip=True)).strip()

    # Fallback keywords from text
    if not keywords and text:
        keywords = _extract_keywords_from_text(text, title=title)

    # Fallback title from URL path
    if not title:
        path = urlparse(url).path.rstrip("/")
        title = path.split("/")[-1].replace("-", " ").replace("_", " ").title() if path else url

    return PageMeta(url=url, title=title, description=description,
                    keywords=keywords, text=text)


# ---------------------------------------------------------------------------
# Playwright BFS crawler
# ---------------------------------------------------------------------------

async def _fetch_page(
    context: BrowserContext, url: str, timeout_ms: int
) -> tuple[str, str, list[str]]:
    """
    Render one page and return (html, final_url, all_hrefs).
    Uses domcontentloaded + short networkidle wait so JS nav menus render.
    """
    page = None
    try:
        page = await context.new_page()
    except Exception as exc:
        message = str(exc).lower()
        if "connection closed" in message or "browser has been closed" in message:
            raise PlaywrightSessionLost(str(exc)) from exc
        raise
    try:
        await page.goto(url, wait_until="domcontentloaded", timeout=timeout_ms)

        # Let lazy JS finish (nav dropdowns, React hydration, etc.)
        try:
            await page.wait_for_load_state("networkidle", timeout=3000)
        except Exception:
            pass

        # Dismiss common cookie / popup overlays
        for sel in [
            "button:has-text('Accept')", "button:has-text('Accept All')",
            "button:has-text('OK')",     "button:has-text('Close')",
            "[aria-label='Close']",      "[id*='cookie'] button",
        ]:
            try:
                btn = page.locator(sel).first
                if await btn.is_visible(timeout=400):
                    await btn.click(timeout=400)
            except Exception:
                pass

        html = await page.content()
        final_url = page.url

        # Collect every href that the DOM exposes post-JS rendering
        hrefs: list[str] = await page.evaluate(
            "() => Array.from(document.querySelectorAll('a[href]'))"
            "      .map(a => a.href)"
            "      .filter(h => h.startsWith('http'))"
        )
        return html, final_url, hrefs

    except Exception as exc:
        message = str(exc).lower()
        if "connection closed" in message or "browser has been closed" in message:
            raise PlaywrightSessionLost(str(exc)) from exc
        logger.debug("Fetch failed %s: %s", url, exc)
        return "", url, []
    finally:
        if page is not None:
            try:
                await page.close()
            except Exception:
                pass


async def _crawl_async(
    roots: list[str],
    *,
    allow_subdomains: bool,
    max_pages: int,
    timeout_ms: int,
    crawl_delay_sec: float,
    max_concurrent: int,
) -> list[PageMeta]:
    allowed_bases = {_base_domain(r) for r in roots}
    visited: set[str] = set()
    queue: deque[str] = deque(_normalize_url(r) for r in roots)
    results: list[PageMeta] = []
    sem = asyncio.Semaphore(max_concurrent)

    async def process(url: str) -> tuple[PageMeta | None, list[str]]:
        async with sem:
            html, final_url, hrefs = await _fetch_page(context, url, timeout_ms)
            if not html:
                return None, []
            meta = _html_to_page_meta(html, final_url)
            if crawl_delay_sec > 0:
                await asyncio.sleep(crawl_delay_sec)
            return meta, hrefs

    headless = _env_bool("WEB_RAG_PLAYWRIGHT_HEADLESS", True)
    channel = os.environ.get("WEB_RAG_PLAYWRIGHT_CHANNEL", "").strip() or None
    locale = os.environ.get("WEB_RAG_PLAYWRIGHT_LOCALE", "en-IN").strip() or "en-IN"
    tz = os.environ.get("WEB_RAG_PLAYWRIGHT_TIMEZONE", "Asia/Kolkata").strip() or "Asia/Kolkata"
    launch_kw = {
        "headless": headless,
        "args": ["--disable-blink-features=AutomationControlled"],
    }
    if channel:
        launch_kw["channel"] = channel

    async with async_playwright() as pw:
        browser: Browser = await pw.chromium.launch(**launch_kw)
        context = await browser.new_context(
            user_agent=(
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/124.0.0.0 Safari/537.36"
            ),
            viewport={"width": 1920, "height": 1080},
            locale=locale,
            timezone_id=tz,
            ignore_https_errors=True,
            extra_http_headers={
                "Accept": (
                    "text/html,application/xhtml+xml,application/xml;q=0.9,"
                    "image/avif,image/webp,*/*;q=0.8"
                ),
                "Accept-Language": "en-IN,en;q=0.9",
                "Sec-Ch-Ua": '"Chromium";v="124", "Google Chrome";v="124", "Not-A.Brand";v="99"',
                "Sec-Ch-Ua-Mobile": "?0",
                "Sec-Ch-Ua-Platform": '"Windows"',
                "Upgrade-Insecure-Requests": "1",
            },
        )
        await context.add_init_script(
            "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"
        )

        try:
            session_lost = False
            while queue:
                if max_pages > 0 and len(results) >= max_pages:
                    logger.info("max_pages=%d reached — stopping.", max_pages)
                    break

                # Fill a batch up to max_concurrent
                batch: list[str] = []
                while queue and len(batch) < max_concurrent:
                    raw = queue.popleft()
                    norm = _normalize_url(raw)
                    if not norm or norm in visited:
                        continue
                    if not _is_crawlable(norm):
                        continue
                    if not _in_scope(norm, allowed_bases, allow_subdomains):
                        continue
                    visited.add(norm)
                    batch.append(norm)

                if not batch:
                    break

                try:
                    outcomes = await asyncio.gather(
                        *[process(u) for u in batch], return_exceptions=True
                    )
                except PlaywrightSessionLost as exc:
                    logger.error("Playwright session lost — stopping crawl: %s", exc)
                    session_lost = True
                    break

                for url, outcome in zip(batch, outcomes):
                    if isinstance(outcome, PlaywrightSessionLost):
                        logger.error("Playwright session lost on %s: %s", url, outcome)
                        queue.clear()
                        session_lost = True
                        break
                    if isinstance(outcome, Exception):
                        logger.warning("Error on %s: %s", url, outcome)
                        continue

                    meta, hrefs = outcome
                    if meta and meta.text.strip():
                        results.append(meta)
                        logger.info(
                            "[%d] %s | %r | links=%d",
                            len(results), url, meta.title[:60], len(hrefs),
                        )

                    for href in hrefs:
                        norm_href = _normalize_url(href)
                        if (norm_href and norm_href not in visited
                                and _is_crawlable(norm_href)
                                and _in_scope(norm_href, allowed_bases, allow_subdomains)):
                            queue.append(norm_href)
                if session_lost:
                    break

        finally:
            await context.close()
            await browser.close()

    logger.info("Crawl done — %d pages", len(results))
    return results


def crawl_urls(
    roots: list[str],
    *,
    allow_subdomains: bool,
    max_pages: int,
    timeout_ms: int,
    crawl_delay_sec: float,
    max_concurrent: int,
) -> list[PageMeta]:
    """Sync wrapper around the async BFS crawler."""
    _ensure_windows_proactor_policy()
    crawl_coro = _crawl_async(
        roots,
        allow_subdomains=allow_subdomains,
        max_pages=max_pages,
        timeout_ms=timeout_ms,
        crawl_delay_sec=crawl_delay_sec,
        max_concurrent=max_concurrent,
    )
    return asyncio.run(crawl_coro)


# ---------------------------------------------------------------------------
# Chunking
# ---------------------------------------------------------------------------

def _resolve_chunking(chunk_size: int | None, chunk_overlap: int | None) -> tuple[int, int]:
    size = int(chunk_size if chunk_size is not None
               else os.environ.get("WEB_RAG_CHUNK_SIZE", "1500"))
    overlap = int(chunk_overlap if chunk_overlap is not None
                  else os.environ.get("WEB_RAG_CHUNK_OVERLAP", "200"))
    size = max(1, size)
    overlap = max(0, min(overlap, size - 1))
    return size, overlap


def _split_text(text: str, *, chunk_size: int, chunk_overlap: int) -> list[str]:
    return RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap,
        separators=["\n\n", "\n", ".", "!", "?", " "],
    ).split_text(text)


def _build_chunk_documents(
    *,
    chunks: list[str],
    meta: PageMeta,
    page_id: int,
    checksum: str,
) -> list[Document]:
    """
    Each chunk carries rich metadata so every vector is self-describing:

    url          – exact source URL the chunk came from
    domain       – registrable base domain
    title        – page <title>
    description  – <meta name="description">
    keywords     – list[str] from <meta> or NLP extraction
    page_id      – postgres row id (for JOIN queries)
    chunk_index  – 0-based position within the page
    chunk_total  – total chunks for this page
    checksum     – SHA-256 of full page text
    """
    total = len(chunks)
    domain = _base_domain(meta.url)
    return [
        Document(
            page_content=chunk,
            metadata={
                "url": meta.url,
                "domain": domain,
                "title": meta.title,
                "description": meta.description,
                "keywords": meta.keywords,
                "page_id": page_id,
                "chunk_index": idx,
                "chunk_total": total,
                "checksum": checksum,
            },
        )
        for idx, chunk in enumerate(chunks)
    ]


# ---------------------------------------------------------------------------
# LangChain PGVector helpers (langchain_pg_collection / langchain_pg_embedding)
# ---------------------------------------------------------------------------


def _delete_vectors_for_url(cur, *, collection_name: str, url: str) -> None:
    """Remove all embeddings for a URL from langchain_pg_embedding."""
    try:
        cur.execute(
            """
            DELETE FROM langchain_pg_embedding
            WHERE collection_id = (
                SELECT uuid FROM langchain_pg_collection WHERE name = %s LIMIT 1
            )
            AND cmetadata->>'url' = %s
            """,
            (collection_name, url),
        )
    except Exception:
        # Tables may not exist until first PGVector write.
        pass


def _count_vectors_for_url(cur, *, collection_name: str, url: str) -> int:
    """Return how many embedding rows exist for this URL in the collection."""
    try:
        cur.execute(
            """
            SELECT COUNT(*)
            FROM langchain_pg_embedding e
            JOIN langchain_pg_collection c ON c.uuid = e.collection_id
            WHERE c.name = %s AND e.cmetadata->>'url' = %s
            """,
            (collection_name, url),
        )
        row = cur.fetchone()
        return int(row[0]) if row and row[0] is not None else 0
    except Exception:
        return 0


# ---------------------------------------------------------------------------
# Hashing
# ---------------------------------------------------------------------------

def _checksum(text: str) -> str:
    return hashlib.sha256(text.encode()).hexdigest()


def _vector_id(url: str, cs: str, idx: int) -> str:
    return hashlib.sha256(f"{url}|{cs}|{idx}".encode()).hexdigest()


# ---------------------------------------------------------------------------
# Debug dump
# ---------------------------------------------------------------------------

def _write_dump(roots: list[str], pages: list[PageMeta]) -> None:
    out_dir = Path(__file__).resolve().parents[3] / "docs" / "web"
    out_dir.mkdir(parents=True, exist_ok=True)

    if not pages:
        summary_path = out_dir / "web_rag_no_pages_crawled.txt"
        summary_path.write_text("No pages crawled.\n", encoding="utf-8")
        logger.info("Dump → %s  (0 pages)", summary_path)
        return

    for idx, pg in enumerate(pages, start=1):
        parsed = urlparse(pg.url)
        host = re.sub(r"[^a-z0-9]+", "_", parsed.netloc.lower()).strip("_") or "web"
        path_slug = re.sub(r"[^a-z0-9]+", "_", parsed.path.lower()).strip("_") or "home"
        url_hash = hashlib.sha1(pg.url.encode("utf-8")).hexdigest()[:10]
        file_name = f"{idx:04d}_{host}_{path_slug}_{url_hash}.txt"
        path = out_dir / file_name
        lines = [
            f"URL:         {pg.url}\n",
            f"TITLE:       {pg.title}\n",
            f"DESCRIPTION: {pg.description}\n",
            f"KEYWORDS:    {', '.join(pg.keywords)}\n",
            "CONTENT:\n",
            pg.text.strip() + "\n",
        ]
        path.write_text("".join(lines), encoding="utf-8")
        logger.info("Dump → %s", path)


# ---------------------------------------------------------------------------
# Vector store / embeddings
# ---------------------------------------------------------------------------

def _build_vector_store(db_cfg: WebRagDbConfig, embeddings: Embeddings) -> PGVector:
    conn_str = (
        f"postgresql+psycopg://{db_cfg.user}:{db_cfg.password}"
        f"@{db_cfg.host}:{db_cfg.port}/{db_cfg.dbname}"
    )
    return PGVector(embeddings=embeddings, collection_name=WEB_RAG_COLLECTION_NAME,
                    connection=conn_str, use_jsonb=True)


def _embedding_ingest_batch_size() -> int:
    """Max documents per add_documents call (embedding provider batch limits)."""
    return max(1, _env_int("WEB_RAG_EMBEDDING_BATCH_SIZE", 64))


def _vector_store_add_documents_batched(
    store: PGVector,
    documents: list[Document],
    ids: list[str],
) -> None:
    """Write many chunk vectors in batches to avoid huge single embed calls."""
    if len(documents) != len(ids):
        raise ValueError("documents and ids must have the same length")
    batch = _embedding_ingest_batch_size()
    for start in range(0, len(documents), batch):
        chunk_docs = documents[start : start + batch]
        chunk_ids = ids[start : start + batch]
        store.add_documents(documents=chunk_docs, ids=chunk_ids)


def _build_embeddings(
    *, provider: str,
    openai_cfg: OpenAIConfig,
    azure_cfg: AzureOpenAIConfig,
    ollama_cfg: OllamaConfig,
) -> Embeddings:
    if provider == "openai":
        openai_cfg.validate()
        return OpenAIEmbeddings(model=openai_cfg.embedding_model_name, api_key=openai_cfg.api_key)
    if provider == "azure":
        azure_cfg.validate()
        dep = azure_cfg.embedding_deployment_name.strip() or azure_cfg.deployment_name
        return AzureOpenAIEmbeddings(
            azure_endpoint=azure_cfg.endpoint.rstrip("/"),
            azure_deployment=dep,
            openai_api_version=azure_cfg.api_version,
            openai_api_key=azure_cfg.api_key,
        )
    ollama_cfg.validate()
    return OllamaEmbeddings(model=ollama_cfg.embedding_model_name, base_url=ollama_cfg.base_url)


# ---------------------------------------------------------------------------
# DB helpers
# ---------------------------------------------------------------------------

def _db_get_page(cur, url: str):
    """Return (id, checksum, content, title) for a URL, or None."""
    cur.execute(
        "SELECT id, checksum, content, title FROM web_rag_pages WHERE url = %s",
        (url,),
    )
    return cur.fetchone()


def _db_insert_page(cur, *, url, domain, title, description, keywords,
                    checksum, content) -> int:
    cur.execute(
        """
        INSERT INTO web_rag_pages
            (url, domain, title, description, keywords, checksum, content)
        VALUES (%s, %s, %s, %s, %s, %s, %s)
        RETURNING id
        """,
        (url, domain, title, description, keywords, checksum, content),
    )
    return cur.fetchone()[0]


def _db_update_page(cur, *, page_id, title, description, keywords, checksum, content):
    cur.execute(
        """
        UPDATE web_rag_pages
        SET title=%s, description=%s, keywords=%s, checksum=%s,
            content=%s, created_at=NOW()
        WHERE id=%s
        """,
        (title, description, keywords, checksum, content, page_id),
    )


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def ingest_urls(
    urls: Iterable[str],
    *,
    provider: str,
    openai_cfg: OpenAIConfig,
    azure_cfg: AzureOpenAIConfig,
    ollama_cfg: OllamaConfig,
    db_cfg: WebRagDbConfig | None = None,
    chunk_size: int | None = None,
    chunk_overlap: int | None = None,
) -> IngestionStats:
    """
    Crawl every reachable page from each root URL (via headless Chromium) and
    ingest text chunks with rich metadata into pgvector.

    .env tunables
    -------------
    WEB_RAG_MAX_PAGES        int    0 = unlimited         (default 0)
    WEB_RAG_TIMEOUT_MS       int    ms per page           (default 20000)
    WEB_RAG_CRAWL_DELAY_SEC  float  seconds between pages (default 0.3)
    WEB_RAG_MAX_CONCURRENT   int    parallel browser tabs (minimum 4)
    WEB_RAG_ALLOW_SUBDOMAINS bool   crawl subdomains too  (default true)
    WEB_RAG_CHUNK_SIZE       int    chars per chunk       (default 1500)
    WEB_RAG_CHUNK_OVERLAP    int    overlap chars         (default 200)
    WEB_RAG_EMBEDDING_BATCH_SIZE int max chunks per embed API call (default 64)

    Playwright (reduce CDN bot walls vs real browser)
    -------------------------------------------------
    WEB_RAG_PLAYWRIGHT_HEADLESS   0/false = visible browser (often bypasses WAF)
    WEB_RAG_PLAYWRIGHT_CHANNEL    e.g. chrome = use installed Google Chrome
    WEB_RAG_PLAYWRIGHT_LOCALE     default en-IN
    WEB_RAG_PLAYWRIGHT_TIMEZONE   default Asia/Kolkata
    """
    roots = [r for r in (_normalize_url(u) for u in urls) if r]
    if not roots:
        return IngestionStats()
    _write_status(
        phase="starting",
        roots=roots,
        note="Initializing ingestion run.",
    )

    db_cfg          = db_cfg or WebRagDbConfig()
    allow_subdomains = _env_bool("WEB_RAG_ALLOW_SUBDOMAINS", True)
    max_pages        = _env_int("WEB_RAG_MAX_PAGES", 0)
    timeout_ms       = _env_int("WEB_RAG_TIMEOUT_MS", 20_000)
    crawl_delay      = _env_float("WEB_RAG_CRAWL_DELAY_SEC", 0.3)
    max_concurrent   = max(4, _env_int("WEB_RAG_MAX_CONCURRENT", 4))
    chunk_size, chunk_overlap = _resolve_chunking(chunk_size, chunk_overlap)

    logger.info(
        "Config | subdomains=%s max_pages=%d timeout=%dms "
        "delay=%.1fs concurrent=%d chunk=%d/%d",
        allow_subdomains, max_pages, timeout_ms,
        crawl_delay, max_concurrent, chunk_size, chunk_overlap,
    )

    embeddings = _build_embeddings(
        provider=provider, openai_cfg=openai_cfg,
        azure_cfg=azure_cfg, ollama_cfg=ollama_cfg,
    )
    store = _build_vector_store(db_cfg, embeddings)

    # ── Crawl (BFS, Playwright) ───────────────────────────────────────────
    _write_status(
        phase="crawling",
        roots=roots,
        note="Crawling website pages via Playwright.",
    )
    pages = crawl_urls(
        roots,
        allow_subdomains=allow_subdomains,
        max_pages=max_pages,
        timeout_ms=timeout_ms,
        crawl_delay_sec=crawl_delay,
        max_concurrent=max_concurrent,
    )
    _write_dump(roots, pages)
    _write_status(
        phase="crawled",
        roots=roots,
        pages_crawled=len(pages),
        note="Crawl completed. Starting indexing.",
    )

    if not pages:
        _write_status(
            phase="completed",
            roots=roots,
            pages_crawled=0,
            note="No pages crawled. Nothing to index.",
        )
        return IngestionStats(roots_attempted=len(roots))

    # ── Index ─────────────────────────────────────────────────────────────
    pages_indexed = chunks_indexed = unchanged_pages = 0

    with get_connection(db_cfg) as conn:
        ensure_schema(conn)

        for meta in pages:
            url = meta.url
            _write_status(
                phase="indexing",
                roots=roots,
                pages_crawled=len(pages),
                pages_indexed=pages_indexed,
                chunks_indexed=chunks_indexed,
                unchanged_pages=unchanged_pages,
                current_url=url,
                note="Processing page for DB + vector updates.",
            )
            if not url or not meta.text.strip():
                continue

            cs = _checksum(meta.text)
            domain = _base_domain(url)
            chunks = _split_text(
                meta.text, chunk_size=chunk_size, chunk_overlap=chunk_overlap
            )
            vids: list[str] = []
            should_embed = False
            page_id: int | None = None
            blocked = _is_cdn_bot_wall(meta)

            with conn.cursor() as cur:
                row = _db_get_page(cur, url)

                if blocked:
                    if row is None:
                        page_id = _db_insert_page(
                            cur, url=url, domain=domain, title=meta.title,
                            description=meta.description, keywords=meta.keywords,
                            checksum=cs, content=meta.text,
                        )
                        _delete_vectors_for_url(
                            cur, collection_name=WEB_RAG_COLLECTION_NAME, url=url
                        )
                        logger.warning(
                            "CDN/WAF bot-wall HTML for new URL — audit row saved, "
                            "no vectors (try WEB_RAG_PLAYWRIGHT_HEADLESS=0 or "
                            "WEB_RAG_PLAYWRIGHT_CHANNEL=chrome): %s",
                            url,
                        )
                    else:
                        bid, prev_cs, prev_content, prev_title = row
                        page_id = bid
                        prev_meta = PageMeta(
                            url=url,
                            title=prev_title or "",
                            description="",
                            keywords=[],
                            text=prev_content or "",
                        )
                        if not _is_cdn_bot_wall(prev_meta):
                            logger.warning(
                                "CDN/WAF bot-wall on crawl; keeping prior usable "
                                "content and vectors unchanged: %s",
                                url,
                            )
                        else:
                            if prev_cs != cs:
                                _db_update_page(
                                    cur, page_id=bid, title=meta.title,
                                    description=meta.description,
                                    keywords=meta.keywords, checksum=cs,
                                    content=meta.text,
                                )
                            _delete_vectors_for_url(
                                cur, collection_name=WEB_RAG_COLLECTION_NAME,
                                url=url,
                            )
                            logger.info(
                                "CDN/WAF page refreshed in DB; vectors cleared: %s",
                                url,
                            )
                    conn.commit()
                    continue

                if row is None:
                    page_id = _db_insert_page(
                        cur, url=url, domain=domain, title=meta.title,
                        description=meta.description, keywords=meta.keywords,
                        checksum=cs, content=meta.text,
                    )
                    if chunks:
                        vids = [_vector_id(url, cs, i) for i in range(len(chunks))]
                        should_embed = True
                else:
                    bid, existing_cs, _prev_content, _prev_title = row
                    page_id = bid
                    if existing_cs != cs:
                        _delete_vectors_for_url(
                            cur, collection_name=WEB_RAG_COLLECTION_NAME, url=url
                        )
                        _db_update_page(
                            cur, page_id=bid, title=meta.title,
                            description=meta.description, keywords=meta.keywords,
                            checksum=cs, content=meta.text,
                        )
                        if chunks:
                            vids = [_vector_id(url, cs, i) for i in range(len(chunks))]
                            should_embed = True
                    else:
                        n_vec = _count_vectors_for_url(
                            cur, collection_name=WEB_RAG_COLLECTION_NAME, url=url
                        )
                        if n_vec != len(chunks):
                            if n_vec:
                                _delete_vectors_for_url(
                                    cur, collection_name=WEB_RAG_COLLECTION_NAME,
                                    url=url,
                                )
                            if chunks:
                                vids = [_vector_id(url, cs, i) for i in range(len(chunks))]
                                should_embed = True
                        else:
                            unchanged_pages += 1

                conn.commit()

            if not should_embed or page_id is None or not chunks:
                continue

            docs = _build_chunk_documents(
                chunks=chunks, meta=meta,
                page_id=page_id, checksum=cs,
            )
            try:
                _vector_store_add_documents_batched(store, docs, vids)
            except Exception as exc:
                msg = str(exc).lower()
                if "invalid_api_key" in msg or "incorrect api key" in msg:
                    raise EnvironmentError(
                        "Embedding auth failed (401). Check API key in .env."
                    ) from exc
                raise

            pages_indexed += 1
            chunks_indexed += len(chunks)
            logger.debug(
                "✓ %s | chunks=%d | title=%r | kw=%s",
                url, len(chunks), meta.title[:50], meta.keywords[:5],
            )
            _write_status(
                phase="indexing",
                roots=roots,
                pages_crawled=len(pages),
                pages_indexed=pages_indexed,
                chunks_indexed=chunks_indexed,
                unchanged_pages=unchanged_pages,
                current_url=url,
                note="Page indexed into vector store.",
            )

    _write_status(
        phase="completed",
        roots=roots,
        pages_crawled=len(pages),
        pages_indexed=pages_indexed,
        chunks_indexed=chunks_indexed,
        unchanged_pages=unchanged_pages,
        note=f"Completed. Status file: {_status_file_path()}",
    )
    return IngestionStats(
        roots_attempted=len(roots),
        pages_crawled=len(pages),
        pages_indexed=pages_indexed,
        chunks_indexed=chunks_indexed,
        unchanged_pages=unchanged_pages,
    )