"""URL scraping and chunking pipeline for web_rag feature."""

from __future__ import annotations

import hashlib
from typing import Iterable, List, Tuple
from urllib.parse import urlparse

from langchain_community.document_loaders import WebBaseLoader
from langchain_core.documents import Document
from langchain_openai import OpenAIEmbeddings
from langchain_text_splitters import RecursiveCharacterTextSplitter

from src.config.settings import openai_config
from src.features.web_rag.db import WebRagDbConfig, ensure_schema, get_connection


def _normalize_url(url: str) -> str:
    value = url.strip()
    if not value:
        return ""
    if "://" not in value:
        value = f"https://{value}"
    return value


def _extract_domain(url: str) -> str:
    parsed = urlparse(url)
    host = parsed.netloc or parsed.path
    return host.lower()


def _checksum_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _load_urls(urls: Iterable[str]) -> List[Tuple[str, str]]:
    """Fetch HTML content for each URL and return list of (url, text)."""
    normalized = [_normalize_url(u) for u in urls]
    normalized = [u for u in normalized if u]
    if not normalized:
        return []
    loader = WebBaseLoader(normalized)
    docs = loader.load()
    out: List[Tuple[str, str]] = []
    for doc in docs:
        page_url = str(doc.metadata.get("source") or "").strip() or _normalize_url(
            doc.metadata.get("url", "")
        )
        if not page_url:
            continue
        out.append((page_url, doc.page_content))
    return out


def _split_text(text: str) -> List[str]:
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=1500,
        chunk_overlap=200,
        separators=["\n\n", "\n", ".", "!", "?", " "],
    )
    return splitter.split_text(text)


def ingest_urls(urls: Iterable[str], *, db_cfg: WebRagDbConfig | None = None) -> None:
    """
    Ingest configured URLs into Postgres and prepare chunks for embedding.

    - Fetch page content.
    - Compute checksum per URL and upsert into web_rag_pages.
    - Store text chunks in web_rag_chunks keyed by page.
    - Create embeddings for each chunk and persist to pgvector-backed table
      via LangChain PGVector.
    """
    db_cfg = db_cfg or WebRagDbConfig()
    url_text_pairs = _load_urls(urls)
    if not url_text_pairs:
        return

    # Prepare embeddings client once for all chunks.
    openai_config.validate()
    embeddings = OpenAIEmbeddings(
        model=openai_config.embedding_model_name,
        api_key=openai_config.api_key,
    )

    # Import lazily to keep dependency surface local to this feature.
    from langchain_community.vectorstores.pgvector import PGVector

    connection_string = (
        f"postgresql+psycopg://{db_cfg.user}:{db_cfg.password}"
        f"@{db_cfg.host}:{db_cfg.port}/{db_cfg.dbname}"
    )

    def _ingest_with_connection() -> None:
        with get_connection(db_cfg) as conn:
            ensure_schema(conn)
            for url, text in url_text_pairs:
                clean_url = _normalize_url(url)
                if not clean_url or not text.strip():
                    continue
                domain = _extract_domain(clean_url)
                checksum = _checksum_text(text)

                with conn.cursor() as cur:
                    cur.execute(
                        """
                        SELECT id, checksum
                        FROM web_rag_pages
                        WHERE url = %s
                        """,
                        (clean_url,),
                    )
                    row = cur.fetchone()
                    page_id: int | None = None
                    if row is None:
                        cur.execute(
                            """
                            INSERT INTO web_rag_pages (url, domain, checksum, content)
                            VALUES (%s, %s, %s, %s)
                            RETURNING id
                            """,
                            (clean_url, domain, checksum, text),
                        )
                        (page_id,) = cur.fetchone()
                    else:
                        page_id, existing_checksum = row
                        if existing_checksum == checksum:
                            # Content unchanged; skip re-chunking and re-embedding.
                            continue
                        cur.execute(
                            """
                            UPDATE web_rag_pages
                            SET checksum = %s, content = %s, created_at = NOW()
                            WHERE id = %s
                            """,
                            (checksum, text, page_id),
                        )
                        # Remove previous chunks; embeddings tied to metadata will be
                        # superseded when we re-add chunks below.
                        cur.execute("DELETE FROM web_rag_chunks WHERE page_id = %s", (page_id,))

                    chunks = _split_text(text)
                    if not chunks:
                        continue

                    for idx, chunk in enumerate(chunks):
                        cur.execute(
                            """
                            INSERT INTO web_rag_chunks (page_id, chunk_index, content)
                            VALUES (%s, %s, %s)
                            """,
                            (page_id, idx, chunk),
                        )
                    conn.commit()

                    # Persist embeddings for these chunks into pgvector table via LangChain.
                    metadata = [
                        {
                            "url": clean_url,
                            "domain": domain,
                            "page_id": page_id,
                            "chunk_index": idx,
                            "checksum": checksum,
                        }
                        for idx in range(len(chunks))
                    ]
                    docs = [
                        Document(page_content=content, metadata=meta)
                        for content, meta in zip(chunks, metadata, strict=True)
                    ]

                    PGVector.from_documents(
                        documents=docs,
                        embedding=embeddings,
                        collection_name="web_rag_embeddings",
                        connection_string=connection_string,
                    )

    try:
        _ingest_with_connection()
    except Exception as exc:
        if "connection is closed" not in str(exc).lower():
            raise
        # Retry once with a fresh connection if server dropped it unexpectedly.
        _ingest_with_connection()

