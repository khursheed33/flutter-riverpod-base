"""Web RAG-specific Streamlit UI helpers."""

from __future__ import annotations

CHAT_PLACEHOLDER = "Ask questions over ingested web content..."
FEATURE_DESCRIPTION = (
    "Crawl configured websites into Postgres/pgvector, then answer questions over the "
    "indexed pages with summarized responses and URL references. Use the Re-ingest "
    "button to refresh the index before asking questions."
)

