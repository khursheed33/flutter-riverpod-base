"""Prompt templates and domain context by active business type."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Final

TYPE_PROMPT_CONTEXT: Final[dict[str, str]] = {
    "underwriting": (
        "Domain focus: Insurance underwriting. Prefer policy rules, risk checks, "
        "eligibility criteria, underwriting guidelines, and exceptions."
    ),
    "digital": (
        "Domain focus: Digital channels and journeys. Prefer app/web flows, "
        "digital campaigns, customer experience, funnel metrics, and platform features."
    ),
}


DOC_SELECTION_SYSTEM_PROMPT_TEMPLATE: Final[str] = """\
You are a document-retrieval assistant.

{domain_context}

Your task in this stage is ONLY to choose the best document(s) by using
document-level metadata (title, type, summary, tags). Do not reason about
individual slides yet.

## Document Catalogue
{catalogue}

## Instructions
1. Carefully read the user's query.
2. Compare it against EVERY document in the catalogue.
3. Select the {top_k} most relevant document(s).
4. Respond ONLY with valid JSON (no markdown fences, no extra text).
5. If the catalogue has only one document, return it even for weak matches
   (with a lower relevance score) instead of an empty list.

## Response format
{{
  "results": [
    {{
      "rank": 1,
      "id": "<document id>",
      "relevance_score": <float 0.0–1.0>,
      "reasoning": "<one sentence explaining why this document fits>"
    }}
  ],
  "query_understood_as": "<brief restatement of the user's intent>"
}}

If no document is relevant and there are multiple choices, return an empty results list.
"""

SLIDE_SELECTION_SYSTEM_PROMPT_TEMPLATE: Final[str] = """\
You are a slide-selection assistant for a single document.

{domain_context}

## Selected document
ID: {doc_id}
Title: {doc_title}
Type: {doc_type}
Summary: {doc_summary}

## Candidate slides (subset, 1-based index)
{slides_catalogue}

## Instructions
1. From these candidate slides, select at most {top_slides} best slides for the query.
2. Return concise notes that summarize what each selected slide contributes.
3. If none of these slides are relevant, return an empty list.
4. Respond ONLY with valid JSON (no markdown fences, no extra text).

## Response format
{{
  "reasoning": "<one sentence summary scoped to this document>",
  "slides": [
    {{
      "number": <int>,
      "title": "<slide title>",
      "note": "<short summary for user>"
    }}
  ]
}}
"""

HUMAN_PROMPT_TEMPLATE: Final[str] = "{query}"


@dataclass(frozen=True)
class PromptBundle:
    """Resolved prompts and context for an active type."""

    domain_context: str
    doc_selection_system_prompt: str
    slide_selection_system_prompt: str
    human_prompt: str


def prompt_context_for_type(active_type: str) -> str:
    """Return prompt context for the active type, with safe fallback."""
    return TYPE_PROMPT_CONTEXT.get(active_type, TYPE_PROMPT_CONTEXT["underwriting"])


def prompts_for_type(active_type: str) -> PromptBundle:
    """Return all prompt templates resolved for the active type."""
    domain_context = prompt_context_for_type(active_type)
    return PromptBundle(
        domain_context=domain_context,
        doc_selection_system_prompt=DOC_SELECTION_SYSTEM_PROMPT_TEMPLATE,
        slide_selection_system_prompt=SLIDE_SELECTION_SYSTEM_PROMPT_TEMPLATE,
        human_prompt=HUMAN_PROMPT_TEMPLATE,
    )
