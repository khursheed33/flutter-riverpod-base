"""Shared chat-model and embedding factories for all providers."""

from __future__ import annotations

from langchain_core.embeddings import Embeddings
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_ollama import ChatOllama, OllamaEmbeddings
from langchain_openai import (
    AzureChatOpenAI,
    AzureOpenAIEmbeddings,
    ChatOpenAI,
    OpenAIEmbeddings,
)

from src.config.settings import AzureOpenAIConfig, OllamaConfig, OpenAIConfig, RetrieverConfig


def build_chat_model(
    *,
    provider: str,
    retriever_cfg: RetrieverConfig,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
) -> BaseChatModel:
    """Create a provider-specific chat model instance."""
    if provider == "azure":
        azure_cfg.validate()
        return AzureChatOpenAI(
            azure_endpoint=azure_cfg.endpoint,
            azure_deployment=azure_cfg.deployment_name,
            api_version=azure_cfg.api_version,
            api_key=azure_cfg.api_key,
            temperature=retriever_cfg.temperature,
            max_tokens=retriever_cfg.max_tokens,
        )
    if provider == "openai":
        openai_cfg.validate()
        return ChatOpenAI(
            model=openai_cfg.model_name,
            api_key=openai_cfg.api_key,
            temperature=retriever_cfg.temperature,
            max_tokens=retriever_cfg.max_tokens,
        )
    if provider == "ollama":
        ollama_cfg.validate()
        return ChatOllama(
            model=ollama_cfg.model_name,
            base_url=ollama_cfg.base_url,
            temperature=retriever_cfg.temperature,
            num_predict=retriever_cfg.max_tokens,
            streaming=ollama_cfg.stream or True,
        )
    raise ValueError(f"Unsupported provider: {provider}")


def build_embeddings(
    *,
    provider: str,
    azure_cfg: AzureOpenAIConfig,
    openai_cfg: OpenAIConfig,
    ollama_cfg: OllamaConfig,
) -> Embeddings:
    """Create a provider-specific embeddings client."""
    if provider == "azure":
        azure_cfg.validate()
        deployment = azure_cfg.embedding_deployment_name.strip() or azure_cfg.deployment_name
        return AzureOpenAIEmbeddings(
            azure_endpoint=azure_cfg.endpoint.rstrip("/"),
            azure_deployment=deployment,
            openai_api_version=azure_cfg.api_version,
            openai_api_key=azure_cfg.api_key,
        )
    if provider == "openai":
        openai_cfg.validate()
        return OpenAIEmbeddings(
            model=openai_cfg.embedding_model_name,
            api_key=openai_cfg.api_key,
        )
    if provider == "ollama":
        ollama_cfg.validate()
        return OllamaEmbeddings(
            model=ollama_cfg.embedding_model_name,
            base_url=ollama_cfg.base_url,
        )
    raise ValueError(f"Unsupported provider: {provider}")
