"""
retriever.py – LLM-powered document retriever.

The LLM reads the full document catalogue (ids + summaries) and selects
the best match(es) for a natural-language query.  It returns structured JSON
so results are easy to parse downstream.

Architecture
────────────
  Query
    │
    ▼
  PromptTemplate  ──►  AzureChatOpenAI  ──►  JsonOutputParser
    │                                               │
    │  (catalogue injected at build time)           ▼
    │                                        RetrievalResult
    │                                               │
    └───────────────────────────────────────────── ▼
                                            Document objects + URLs
"""
from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional

import numpy as np
from langchain_core.embeddings import Embeddings
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import AzureChatOpenAI, ChatOpenAI

from src.config.settings import AzureOpenAIConfig, RetrieverConfig, azure_config, retriever_config
from src.llm.prompts import prompts_for_type
from src.services.document_store import Document, DocumentStore

logger = logging.getLogger(__name__)


def _embedding_shortlist_store(
    store: DocumentStore,
    embeddings: Embeddings,
    query: str,
    top_m: int,
) -> DocumentStore:
    """
    Return a store containing the *top_m* documents by cosine similarity
    between the query embedding and each document's ``embedding_source_text``.
    """
    docs = store.all()
    if top_m <= 0 or len(docs) <= top_m:
        return store
    texts = [d.embedding_source_text() for d in docs]
    q_vec = np.asarray(embeddings.embed_query(query), dtype=float)
    doc_matrix = np.asarray(embeddings.embed_documents(texts), dtype=float)
    q_norm = q_vec / (np.linalg.norm(q_vec) + 1e-12)
    d_norm = doc_matrix / (np.linalg.norm(doc_matrix, axis=1, keepdims=True) + 1e-12)
    sims = d_norm @ q_norm
    order = np.argsort(-sims)[:top_m]
    picked = [docs[int(i)] for i in order]
    return DocumentStore(picked)


# ─── Result dataclasses ───────────────────────────────────────────────────────


@dataclass
class SlideMatch:
    """A specific slide the LLM tied to the user's query (when applicable)."""

    number: int
    title: str = ""
    note: str = ""


class RetrievalMatch:
    """A single matched document with metadata."""

    def __init__(
        self,
        document: Document,
        rank: int,
        relevance_score: float,
        reasoning: str,
        matched_slides: Optional[List[SlideMatch]] = None,
    ) -> None:
        self.document = document
        self.rank = rank
        self.relevance_score = relevance_score
        self.reasoning = reasoning
        self.matched_slides: List[SlideMatch] = matched_slides or []

    def __repr__(self) -> str:
        return (
            f"RetrievalMatch(rank={self.rank}, id={self.document.id!r}, "
            f"score={self.relevance_score:.2f}, slides={len(self.matched_slides)})"
        )


class RetrievalResult:
    """Full result returned to the caller."""

    def __init__(
        self,
        matches: List[RetrievalMatch],
        query_understood_as: str,
        raw_llm_response: dict,
    ) -> None:
        self.matches = matches
        self.query_understood_as = query_understood_as
        self.raw_llm_response = raw_llm_response

    @property
    def best(self) -> Optional[RetrievalMatch]:
        return self.matches[0] if self.matches else None

    def __repr__(self) -> str:
        return f"RetrievalResult(matches={len(self.matches)}, best={self.best})"


# ─── Retriever ────────────────────────────────────────────────────────────────

class DocumentRetriever:
    """
    LangChain-based retriever that uses a chat model to pick the right document.

    Parameters
    ----------
    store          : DocumentStore – the catalogue to search over
    azure_cfg      : AzureOpenAIConfig – connection settings (defaults to env vars)
    ret_cfg        : RetrieverConfig   – behaviour settings (defaults to env vars)
    """

    def __init__(
        self,
        store: Optional[DocumentStore] = None,
        azure_cfg: AzureOpenAIConfig = azure_config,
        ret_cfg: RetrieverConfig = retriever_config,
        active_type: str = "underwriting",
    ) -> None:
        azure_cfg.validate()

        self.store = store or DocumentStore()
        self.ret_cfg = ret_cfg
        self.active_type = active_type
        self._prompt_bundle = prompts_for_type(self.active_type)

        # ── Build the LLM ─────────────────────────────────────────────────────
        self._llm = AzureChatOpenAI(
            azure_endpoint=azure_cfg.endpoint,
            azure_deployment=azure_cfg.deployment_name,
            api_version=azure_cfg.api_version,
            api_key=azure_cfg.api_key,
            temperature=ret_cfg.temperature,
            max_tokens=ret_cfg.max_tokens,
        )
        self._build_chains()

    # ── Public API ────────────────────────────────────────────────────────────

    def retrieve(
        self,
        query: str,
        *,
        embeddings: Optional[Embeddings] = None,
        embedding_shortlist: int = 0,
    ) -> RetrievalResult:
        """
        Find the best document(s) for *query*.

        Parameters
        ----------
        query : natural-language question or description of what you need
        embeddings : optional embeddings client; if set with *embedding_shortlist*
            greater than zero and more documents than that exist, only the top
            similar documents are shown to the chat model (smaller prompts).
        embedding_shortlist : max documents to pass to the LLM after embedding rank

        Returns
        -------
        RetrievalResult with ranked matches and the URL(s) ready to use
        """
        if not query.strip():
            raise ValueError("Query must not be empty.")

        logger.debug("Invoking LLM chain for query: %r", query)

        catalogue_store = self.store
        if embeddings is not None and embedding_shortlist > 0:
            catalogue_store = _embedding_shortlist_store(
                self.store, embeddings, query, embedding_shortlist
            )

        raw: dict = self._doc_chain.invoke(
            {
                "domain_context": self._prompt_bundle.domain_context,
                "catalogue": self._doc_catalogue_text(catalogue_store),
                "top_k": self.ret_cfg.top_k,
                "query": query,
            }
        )
        raw = self._ensure_non_empty_doc_results(
            raw=raw,
            query=query,
            store=catalogue_store,
            embeddings=embeddings,
        )
        matches = self._parse_matches(raw, query=query, embeddings=embeddings)
        return RetrievalResult(
            matches=matches,
            query_understood_as=raw.get("query_understood_as", ""),
            raw_llm_response=raw,
        )

    def retrieve_url(self, query: str, **kwargs: Any) -> Optional[str]:
        """Convenience wrapper – returns only the top-ranked document URL."""
        result = self.retrieve(query, **kwargs)
        return result.best.document.url if result.best else None

    # ── Internals ─────────────────────────────────────────────────────────────

    def _parse_matches(
        self,
        raw: dict,
        *,
        query: str,
        embeddings: Optional[Embeddings],
    ) -> List[RetrievalMatch]:
        matches: List[RetrievalMatch] = []
        for item in raw.get("results", []):
            doc_id = item.get("id", "")
            doc = self.store.get_by_id(doc_id)
            if doc is None:
                logger.warning("LLM returned unknown document id %r – skipping.", doc_id)
                continue
            slide_matches = self._select_slides_for_document(
                query=query,
                doc=doc,
                embeddings=embeddings,
            )
            reasoning = str(item.get("reasoning", "")).strip()
            if slide_matches:
                slide_reason = self._summarize_doc_with_selected_slides(
                    query=query,
                    doc=doc,
                    selected_slides=slide_matches,
                )
                if slide_reason:
                    reasoning = slide_reason
            matches.append(
                RetrievalMatch(
                    document=doc,
                    rank=item.get("rank", len(matches) + 1),
                    relevance_score=float(item.get("relevance_score", 0.0)),
                    reasoning=reasoning,
                    matched_slides=slide_matches,
                )
            )
        return matches

    def _build_chains(self) -> None:
        """Build prompt -> LLM -> JSON parser chains for both retrieval stages."""
        self._parser = JsonOutputParser()
        self._doc_prompt = ChatPromptTemplate.from_messages(
            [
                ("system", self._prompt_bundle.doc_selection_system_prompt),
                ("human", self._prompt_bundle.human_prompt),
            ]
        )
        self._slide_prompt = ChatPromptTemplate.from_messages(
            [
                ("system", self._prompt_bundle.slide_selection_system_prompt),
                ("human", self._prompt_bundle.human_prompt),
            ]
        )
        self._doc_chain = self._doc_prompt | self._llm | self._parser
        self._slide_chain = self._slide_prompt | self._llm | self._parser

    def _ensure_non_empty_doc_results(
        self,
        *,
        raw: dict,
        query: str,
        store: DocumentStore,
        embeddings: Optional[Embeddings],
    ) -> dict:
        """
        Ensure retrieval has at least one candidate when a sensible fallback exists.

        This handles edge cases where stage-1 returns no results even though the
        catalogue is small or contains one obvious candidate.
        """
        results = raw.get("results", [])
        if results:
            return raw
        docs = store.all()
        if not docs:
            return raw

        fallback_doc: Optional[Document] = None
        score = 0.35
        why = "Best available document by semantic fallback."

        if len(docs) == 1:
            fallback_doc = docs[0]
            score = 0.5
            why = "Only document in catalogue; selected as best available source."
        elif embeddings is not None:
            ranked = _embedding_shortlist_store(store, embeddings, query, 1).all()
            if ranked:
                fallback_doc = ranked[0]
                score = 0.45
                why = "No direct stage-1 match; selected top semantic candidate."

        if fallback_doc is None:
            return raw

        out = dict(raw)
        out["results"] = [
            {
                "rank": 1,
                "id": fallback_doc.id,
                "relevance_score": score,
                "reasoning": why,
            }
        ]
        if not out.get("query_understood_as"):
            out["query_understood_as"] = query
        return out

    def _doc_catalogue_text(self, store: DocumentStore) -> str:
        """Return compact document-only catalogue text (without full slide dumps)."""
        parts: List[str] = []
        for idx, doc in enumerate(store.all(), start=1):
            tag_line = f"\n  Tags: {', '.join(doc.tags)}" if doc.tags else ""
            topics_line = ""
            if doc.slides:
                topic_titles = [s.title.strip() for s in doc.slides if s.title.strip()]
                # Keep only a small sample so prompt stays compact.
                sampled = topic_titles[:12]
                if sampled:
                    topics_line = "\n  Key slide topics: " + "; ".join(sampled)
            parts.append(
                f"[{idx}] ID: {doc.id}\n"
                f"  Title: {doc.title}\n"
                f"  Type: {doc.doc_type.upper()}\n"
                f"  Summary: {doc.summary}{tag_line}{topics_line}"
            )
        return "\n\n".join(parts)

    def _select_slides_for_document(
        self,
        *,
        query: str,
        doc: Document,
        embeddings: Optional[Embeddings],
    ) -> List[SlideMatch]:
        if not doc.slides:
            return []
        candidates = self._candidate_slides(query=query, doc=doc, embeddings=embeddings)
        if not candidates:
            return []
        raw = self._slide_chain.invoke(
            {
                "domain_context": self._prompt_bundle.domain_context,
                "doc_id": doc.id,
                "doc_title": doc.title,
                "doc_type": doc.doc_type.upper(),
                "doc_summary": doc.summary,
                "slides_catalogue": self._slides_catalogue_text(candidates),
                "top_slides": min(5, len(candidates)),
                "query": query,
            }
        )
        return self._parse_slide_matches(doc, raw.get("slides"))

    def _candidate_slides(
        self,
        *,
        query: str,
        doc: Document,
        embeddings: Optional[Embeddings],
        max_candidates: int = 12,
    ) -> List[Dict[str, Any]]:
        if embeddings is not None:
            return self._candidate_slides_embeddings(
                query=query, doc=doc, embeddings=embeddings, max_candidates=max_candidates
            )
        return self._candidate_slides_keyword(
            query=query, doc=doc, max_candidates=max_candidates
        )

    def _candidate_slides_embeddings(
        self,
        *,
        query: str,
        doc: Document,
        embeddings: Embeddings,
        max_candidates: int,
    ) -> List[Dict[str, Any]]:
        texts = [
            f"Slide {s.number}: {s.title}\n{s.summary}".strip()
            for s in doc.slides
        ]
        if not texts:
            return []
        q_vec = np.asarray(embeddings.embed_query(query), dtype=float)
        s_matrix = np.asarray(embeddings.embed_documents(texts), dtype=float)
        q_norm = q_vec / (np.linalg.norm(q_vec) + 1e-12)
        s_norm = s_matrix / (np.linalg.norm(s_matrix, axis=1, keepdims=True) + 1e-12)
        sims = s_norm @ q_norm
        order = np.argsort(-sims)[:max_candidates]
        return [
            {
                "number": doc.slides[int(i)].number,
                "title": doc.slides[int(i)].title,
                "summary": doc.slides[int(i)].summary,
            }
            for i in order
        ]

    def _candidate_slides_keyword(
        self,
        *,
        query: str,
        doc: Document,
        max_candidates: int,
    ) -> List[Dict[str, Any]]:
        q_tokens = {
            t for t in "".join(ch.lower() if ch.isalnum() else " " for ch in query).split()
            if len(t) > 2
        }
        scored: List[tuple[int, Dict[str, Any]]] = []
        for slide in doc.slides:
            text = f"{slide.title} {slide.summary}".lower()
            s_tokens = {
                t for t in "".join(ch if ch.isalnum() else " " for ch in text).split()
                if len(t) > 2
            }
            overlap = len(q_tokens.intersection(s_tokens))
            scored.append(
                (
                    overlap,
                    {
                        "number": slide.number,
                        "title": slide.title,
                        "summary": slide.summary,
                    },
                )
            )
        scored.sort(key=lambda x: x[0], reverse=True)
        return [item for _, item in scored[:max_candidates]]

    def _slides_catalogue_text(self, slides: List[Dict[str, Any]]) -> str:
        chunks: List[str] = []
        for s in slides:
            chunks.append(
                f"Slide {s['number']}: {s.get('title', '')}\n"
                f"  Summary: {s.get('summary', '')}"
            )
        return "\n\n".join(chunks)

    def _summarize_doc_with_selected_slides(
        self,
        *,
        query: str,
        doc: Document,
        selected_slides: List[SlideMatch],
    ) -> str:
        if not selected_slides:
            return ""
        chosen = []
        by_num = {s.number: s for s in doc.slides}
        for s in selected_slides:
            src = by_num.get(s.number)
            chosen.append(
                {
                    "number": s.number,
                    "title": s.title or (src.title if src else ""),
                    "summary": src.summary if src else s.note,
                }
            )
        raw = self._slide_chain.invoke(
            {
                "domain_context": self._prompt_bundle.domain_context,
                "doc_id": doc.id,
                "doc_title": doc.title,
                "doc_type": doc.doc_type.upper(),
                "doc_summary": doc.summary,
                "slides_catalogue": self._slides_catalogue_text(chosen),
                "top_slides": len(chosen),
                "query": query,
            }
        )
        return str(raw.get("reasoning", "")).strip()

    def _parse_slide_matches(
        self, doc: Document, raw_slides: Optional[List[Dict[str, Any]]]
    ) -> List[SlideMatch]:
        """Normalize LLM slide hints; align titles with the catalogue when possible."""
        if not raw_slides:
            return []
        by_number = {s.number: s for s in doc.slides}
        out: List[SlideMatch] = []
        for raw in raw_slides:
            if not isinstance(raw, dict):
                continue
            try:
                num = int(raw.get("number", 0))
            except (TypeError, ValueError):
                continue
            if num < 1:
                continue
            note = str(raw.get("note", "")).strip()
            llm_title = str(raw.get("title", "")).strip()
            if num in by_number:
                catalog = by_number[num]
                title = catalog.title or llm_title
            else:
                title = llm_title
            out.append(SlideMatch(number=num, title=title, note=note))
        return out


class OpenAIDocumentRetriever(DocumentRetriever):
    """
    Retriever backed by OpenAI Chat Completions (non-Azure).

    It keeps the same prompt, parsing, and slide extraction logic as
    ``DocumentRetriever`` but swaps the underlying chat model.
    """

    def __init__(
        self,
        model_name: str,
        api_key: str,
        store: Optional[DocumentStore] = None,
        ret_cfg: RetrieverConfig = retriever_config,
        active_type: str = "underwriting",
    ) -> None:
        if not api_key:
            raise EnvironmentError("OpenAI API key is required for OpenAI retriever.")

        self.store = store or DocumentStore()
        self.ret_cfg = ret_cfg
        self.active_type = active_type
        self._prompt_bundle = prompts_for_type(self.active_type)

        self._llm = ChatOpenAI(
            model=model_name,
            api_key=api_key,
            temperature=ret_cfg.temperature,
            max_tokens=ret_cfg.max_tokens,
        )
        self._build_chains()

